/*!
	@file
	@author		Eric.Liu
	@date		09/2011
	@blog		http://egamesir.com
*/
/*
	This file is part of MyGUI.

	MyGUI is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	MyGUI is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with MyGUI.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef __MYGUI_RESOURCE_GDI_FONT_H__
#define __MYGUI_RESOURCE_GDI_FONT_H__

#include "MyGUI_Prerequest.h"
#include "MyGUI_ITexture.h"
#include "MyGUI_IFont.h"
#include <windows.h>

namespace MyGUI
{

	class MYGUI_EXPORT ResourceGdiFont :
		public IFont
	{
		MYGUI_RTTI_DERIVED( ResourceGdiFont )

	public:

		ResourceGdiFont();
		virtual ~ResourceGdiFont();

		virtual void deserialization(xml::ElementPtr _node, Version _version);

		virtual GlyphInfo* getGlyphInfo(Char _id);

		virtual ITexture* getTextureFont();

		virtual int getDefaultHeight();

	private:
		bool init();

		bool loadCharactor(Char _id);

	private:
		int mHeightPix;
		int mAntialias;
		int mSpaceWidth;
		int mTabWidth;
		int mDistance;
		int mOffsetHeight;
		int mTexOffsetX;
		int mTexOffsetY;
		int mTexMemOffset;
		int mCursorWidth;
		long mAscent;
		bool mBold;
		bool mItalic;
		bool mTexFull;
		float mFontSize;
		uint mFontResolution;

		HDC mMemDC;
		HFONT mFont;
		std::string mSource;
		std::map<Char, GlyphInfo*> mGlyphInfo;

		MyGUI::ITexture* mTexture;
	};

} // namespace MyGUI

#endif // __MYGUI_RESOURCE_GDI_FONT_H__
