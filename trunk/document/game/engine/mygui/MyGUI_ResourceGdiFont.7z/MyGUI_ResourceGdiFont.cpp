/*!
	@file
	@author		Eric.Liu
	@date		09/2011
	@blog		http://egamesir.com
*/
/*
	This file is part of MyGUI.

	MyGUI is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	MyGUI is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with MyGUI.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "MyGUI_Precompiled.h"
#include "MyGUI_ResourceGdiFont.h"
#include "MyGUI_DataManager.h"
#include "MyGUI_RenderManager.h"

namespace MyGUI
{

	const uint32	FONT_MASK_SELECT = 0xFF888888;
	const uint32	FONT_MASK_SELECT_DEACTIVE = 0xFF606060;
	const uint32	FONT_MASK_SPACE = 0x00;
	const uint32	FONT_MASK_CHAR = 0xFFFFFFFF;
	const uint8		FONT_ERR_CHAR = 0x2A;
	const int MIN_FONT_TEXTURE_WIDTH = 128;

	const unsigned char gAlphaLevel[65] = 
	{
		  0,  4,  8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48,
		 52, 56, 60, 64, 68, 72, 76, 80, 84, 88, 92, 96,100,
		104,108,112,116,120,124,128,132,136,140,144,148,152,
		156,160,164,168,172,176,180,184,188,192,196,200,204,
		208,212,216,220,224,228,232,236,240,244,248,252,255
	};

	void utf2str( const char * utf, std::string & str )
	{
		int len = ::MultiByteToWideChar( CP_UTF8, 0, utf, -1, 0, 0 );
		if ( len <= 1 )
		{
			str.clear();
			return;
		}
		std::wstring ws( len - 1, 0 );
		::MultiByteToWideChar( CP_UTF8, 0, utf, -1, &ws[ 0 ], len );
		const wchar_t * wcp = ws.c_str();
		len = ::WideCharToMultiByte( CP_ACP, 0, wcp, -1, 0, 0, 0, 0 );
		str.resize( len - 1, 0 );
		len = ::WideCharToMultiByte( CP_ACP, 0, wcp, -1, &str[ 0 ], len, 0, 0 );
	}

	ResourceGdiFont::ResourceGdiFont() :
		mHeightPix(0),
		mTexOffsetX(0),
		mTexOffsetY(0),
		mTexMemOffset(0),
		mFontSize(19),
		mFontResolution(50),
		mSpaceWidth(1),
		mCursorWidth(1),
		mTabWidth(4),
		mDistance(0),
		mOffsetHeight(0),
		mAntialias(0),
		mItalic(false),
		mBold(false),
		mTexFull(false),
		mMemDC(nullptr),
		mFont(nullptr),
		mTexture(nullptr)
	{
	}

	ResourceGdiFont::~ResourceGdiFont()
	{
		std::map<Char,GlyphInfo*>::iterator it;
		for (it=mGlyphInfo.begin();it!=mGlyphInfo.end();)
		{
			delete it->second;
			it = mGlyphInfo.erase(it);
		}

		if (mMemDC)
		{
			::DeleteDC(mMemDC);
			mMemDC = nullptr;
		}

		if (mFont)
		{
			::DeleteObject(mFont);
			mFont = nullptr;
		}

		if (mTexture != nullptr)
		{
			RenderManager::getInstance().destroyTexture(mTexture);
			mTexture = nullptr;
		}
	}

	GlyphInfo* ResourceGdiFont::getGlyphInfo(Char _id)
	{
		if (!mGlyphInfo[_id])
		{
			if (mTexFull)
			{
				return mGlyphInfo[FONT_ERR_CHAR];
			}

			if (!loadCharactor(_id))
				return mGlyphInfo[FONT_ERR_CHAR];
		}

		return mGlyphInfo[_id];
	}

	void ResourceGdiFont::deserialization(xml::ElementPtr _node, Version _version)
	{
		Base::deserialization(_node, _version);

		bool bAntialias=false;
		xml::ElementEnumerator node = _node->getElementEnumerator();
		while (node.next())
		{
			MyGUI::UString us;
			if (node->getName() == "Property")
			{
				const std::string& key = node->findAttribute("key");
				const std::string& value = node->findAttribute("value");
				std::string valueAsiic;
				utf2str(value.c_str(), valueAsiic);
				if (key == "Source") mSource = valueAsiic;
				else if (key == "Size") mFontSize = utility::parseFloat(value);
				else if (key == "Resolution") mFontResolution = utility::parseUInt(value);
				else if (key == "Antialias") bAntialias = utility::parseBool(value);
				else if (key == "SpaceWidth") mSpaceWidth = utility::parseInt(value);
				else if (key == "TabWidth") mTabWidth = utility::parseInt(value);
				else if (key == "CursorWidth") mCursorWidth = utility::parseInt(value);
				else if (key == "Distance") mDistance = utility::parseInt(value);
				else if (key == "OffsetHeight") mOffsetHeight = utility::parseInt(value);
			}
		}

		mAntialias = bAntialias ? GGO_GRAY8_BITMAP : GGO_BITMAP;
		mHeightPix = (int)mFontSize;

		init();
	}

	bool ResourceGdiFont::init()
	{
		bool rgbaMode = MyGUI::RenderManager::getInstance().isFormatSupported(PixelFormat::R8G8B8A8, TextureUsage::Static | TextureUsage::Write);
		if (!rgbaMode)
			return false;

		HDC hDC = ::GetDC(NULL);
		mMemDC = ::CreateCompatibleDC(hDC);
		if (!mMemDC)
			return false;
		::ReleaseDC(NULL,hDC);

		::SetMapMode(mMemDC, MM_TEXT);
		::SetTextColor(mMemDC,RGB(255,255,255));
		::SetBkColor(mMemDC,RGB(0,0,0));

		mFont = ::CreateFont(
			(int)-mFontSize,
			0,
			0,
			0,
			(mBold) ? FW_BOLD : FW_NORMAL,
			mItalic,
			FALSE,
			FALSE,
			DEFAULT_CHARSET,
			OUT_DEFAULT_PRECIS,
			CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY,
			FF_DONTCARE | DEFAULT_PITCH,
			mSource.c_str());
		if (!mFont)
			return false;
		::SelectObject(mMemDC, mFont);

		TEXTMETRIC tm;
		::GetTextMetrics(mMemDC, &tm);
		mAscent = tm.tmAscent;

		mTexture = RenderManager::getInstance().createTexture(MyGUI::utility::toString((size_t)this, "_GdiFont"));
		mTexture->createManual(MIN_FONT_TEXTURE_WIDTH, MIN_FONT_TEXTURE_WIDTH,
			TextureUsage::Static | TextureUsage::Write, PixelFormat::R8G8B8A8);

		loadCharactor(FONT_ERR_CHAR);

		return true;
	}

	bool ResourceGdiFont::loadCharactor(Char _id)
	{
		if (!mTexture)
			return false;
		if (mTexMemOffset>MIN_FONT_TEXTURE_WIDTH*MIN_FONT_TEXTURE_WIDTH*sizeof(uint32))
			return false;

		int charw=0,loaded=0;
		switch(_id)
		{
		case FontCodeType::Selected:
			{
				uint32* lpDst = (uint32*)mTexture->lock(TextureUsage::Write);
				lpDst += mTexOffsetX+mTexOffsetY*MIN_FONT_TEXTURE_WIDTH;
				for (uint32 y = 0; y < mFontSize; ++y)
				{
					for (uint32 x = 0; x < 1; ++x)
					{
						for(uint32 k = 0; k < 8; ++k)
						{
							uint32 i = 8 * x + k;
							if (i >= 1)
							{
								x+=7;
								break;
							}
							lpDst[i] = FONT_MASK_SELECT;
						}
					}
					lpDst += MIN_FONT_TEXTURE_WIDTH;
				}
				mTexture->unlock();
				charw=1;
				loaded=1;
				mTexMemOffset += 1*(int)mFontSize*sizeof(uint32);
			}
			break;
		case FontCodeType::SelectedBack:
			{
				uint32* lpDst = (uint32*)mTexture->lock(TextureUsage::Write);
				lpDst += mTexOffsetX+mTexOffsetY*MIN_FONT_TEXTURE_WIDTH;
				for (uint32 y = 0; y < mFontSize; ++y)
				{
					for (uint32 x = 0; x < 1; ++x)
					{
						for(uint32 k = 0; k < 8; ++k)
						{
							uint32 i = 8 * x + k;
							if (i >= 1)
							{
								x+=7;
								break;
							}
							lpDst[i] = FONT_MASK_SELECT_DEACTIVE;
						}
					}
					lpDst += MIN_FONT_TEXTURE_WIDTH;
				}
				mTexture->unlock();
				charw=1;
				loaded=1;
				mTexMemOffset += 1*(int)mFontSize*sizeof(uint32);
			}
			break;
		case FontCodeType::Cursor:
			{
				uint32* lpDst = (uint32*)mTexture->lock(TextureUsage::Write);
				lpDst += mTexOffsetX+mTexOffsetY*MIN_FONT_TEXTURE_WIDTH;
				for (uint32 y = 0; y < mFontSize; ++y)
				{
					for (uint32 x = 0; x < mCursorWidth; ++x)
					{
						for(uint32 k = 0; k < 8; ++k)
						{
							uint32 i = 8 * x + k;
							if (i >= mCursorWidth)
							{
								x+=7;
								break;
							}
							lpDst[i] = FONT_MASK_CHAR;
						}
					}
					lpDst += MIN_FONT_TEXTURE_WIDTH;
				}
				mTexture->unlock();
				charw=mCursorWidth;
				loaded=1;
				mTexMemOffset += mCursorWidth*(int)mFontSize*sizeof(uint32);
			}
			break;
		case FontCodeType::Tab:
			break;
		default:
			{
				if (_id < 0xFFFF && !mGlyphInfo[_id])
				{
					MAT2 mat2 = {{0,1},{0,0},{0,0},{0,1}};
					GLYPHMETRICS gm;
					uint32 nLen = ::GetGlyphOutlineW(mMemDC, _id, mAntialias, &gm, 0, NULL, &mat2);
					if((signed)nLen > 0)
					{
						uint8* lpBuf = new uint8[nLen];

						if (nLen == ::GetGlyphOutlineW(mMemDC, _id, mAntialias, &gm, nLen, lpBuf, &mat2))
						{
							uint8* lpSrc = lpBuf;
							uint32* lpDst = (uint32*)mTexture->lock(TextureUsage::Write);
							lpDst += mTexOffsetX+mTexOffsetY*MIN_FONT_TEXTURE_WIDTH +
								gm.gmptGlyphOrigin.x+(mAscent-gm.gmptGlyphOrigin.y)*MIN_FONT_TEXTURE_WIDTH;
							if (GGO_BITMAP == mAntialias)
							{
								LONG nSrcPitch = (gm.gmBlackBoxX / 32 + (gm.gmBlackBoxX % 32 == 0 ? 0 : 1)) * 4;
								LONG nDstPitch = MIN_FONT_TEXTURE_WIDTH;
								for (uint32 y = 0; y < gm.gmBlackBoxY; ++y)
								{
									for (uint32 x = 0; x < gm.gmBlackBoxX; ++x)
									{
										for(uint32 k = 0; k < 8; ++k)
										{
											uint32 i = 8 * x + k;
											if (i >= gm.gmBlackBoxX)
											{
												x+=7;
												break;
											}
											lpDst[i] = ((lpSrc[x] >> (7 - k)) & 1) ? FONT_MASK_CHAR : 0x0;
										}
									}
									lpSrc += nSrcPitch;
									lpDst += nDstPitch;
								}
							}
							else
							{
								LONG nSrcPitch = (gm.gmBlackBoxX / 4 + (gm.gmBlackBoxX % 4 == 0 ? 0 : 1)) * 4;
								LONG nDstPitch = MIN_FONT_TEXTURE_WIDTH;
								for (uint32 y = 0; y < gm.gmBlackBoxY; ++y)
								{
									for (uint32 x = 0; x < gm.gmBlackBoxX; ++x)
									{
										lpDst[x] = ((uint32)gAlphaLevel[lpSrc[x]]<<24) + ((uint32)0xFF<<16) +
											((uint32)0xFF<<8) + ((uint32)0xFF);
									}
									lpSrc += nSrcPitch;
									lpDst += nDstPitch;
								}
							}
							mTexture->unlock();
						}
						delete lpBuf;
					}
					charw=gm.gmCellIncX;
					loaded=1;
					mTexMemOffset += nLen;
				}
				break;
			}
		}

		if (0==loaded)
			return false;

		GlyphInfo* _info = new GlyphInfo;
		_info->codePoint = _id;
		_info->uvRect.left = (float)(mTexOffsetX) / (float)MIN_FONT_TEXTURE_WIDTH;
		_info->uvRect.top = (float)(mTexOffsetY+mOffsetHeight) / (float)MIN_FONT_TEXTURE_WIDTH;
		_info->uvRect.right = (float)(mTexOffsetX+charw) / (float)MIN_FONT_TEXTURE_WIDTH;
		_info->uvRect.bottom = (float)(mTexOffsetY+mFontSize+mOffsetHeight) / (float)MIN_FONT_TEXTURE_WIDTH;
		_info->width = charw;
		mGlyphInfo[_id] = _info;

		mTexOffsetX += charw;
		if (mTexOffsetX>MIN_FONT_TEXTURE_WIDTH-mFontSize)
		{
			mTexOffsetX = 0;
			mTexOffsetY += (int)mFontSize;
			if (mTexOffsetY>MIN_FONT_TEXTURE_WIDTH-mFontSize)
			{
				mTexOffsetY = 0;
				mTexFull=true;
			}
		}

		return true;
	}

	ITexture* ResourceGdiFont::getTextureFont()
	{
		return mTexture;
	}

	int ResourceGdiFont::getDefaultHeight()
	{
		return mHeightPix;
	}

} // namespace MyGUI
