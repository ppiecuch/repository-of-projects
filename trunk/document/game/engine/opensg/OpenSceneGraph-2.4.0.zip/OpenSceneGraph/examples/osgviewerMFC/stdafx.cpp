// stdafx.cpp : source file that includes just the standard includes
// MFC_OSG_MDI.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


