//----------------------------------------------------------------------------------
// File:   Arena.h
// Author: Mathias Schott
// Email:  sdkfeedback@nvidia.com
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
//
//----------------------------------------------------------------------------------

#pragma once
#include "Utility.h"
#include "EffectVariable.h"
#include "Geometry.h"

#include "SDKmisc.h"
#include "SDKmesh_old.h"

#include "Scene.h"
#include "LightningRenderer.h"

namespace LightningDemo
{
	namespace Effect = Utility::Effect;
	namespace Geometry = Utility::Geometry;

class Arena
{
public:
	Arena(ID3D10Device* device,DXGI_SAMPLE_DESC back_buffer_sample_desc);
	~Arena();

	void Matrices(const D3DXMATRIX& view, const D3DXMATRIX& projection);
	void Time(float time, float delta_time);
	void RenderTargetResize(unsigned width, unsigned height, ID3D10RenderTargetView* render_target_view, ID3D10DepthStencilView* depth_stencil_view);

	void Render();

	struct ArenaSettings
	{
		ArenaSettings():
			Fence(true),
			InterCoil(true),
			CoilHelix(true),
			Chain(true),
			Scene(true),
			Glow(true),
			Lines(false),
			AnimationSpeed(15)
		{
		}

		bool	Fence;
		bool	InterCoil;
		bool	CoilHelix;
		bool	Chain;
		bool	Scene;
		bool	Lines;

		float   AnimationSpeed;
		bool	Glow;
		D3DXVECTOR3	BlurSigma;

		LightningAppearance Beam;

	} Settings;



private:

	void ReadSeeds(const wchar_t* file);
	void CreateLightning();

	DXGI_SAMPLE_DESC m_back_buffer_sample_desc;
	
	ID3D10Device*		m_device;

	LightningRenderer	m_lightning_renderer;

	PathLightning*		m_inter_coil_lightning;
	PathLightning*		m_fence_lightning;
	PathLightning*		m_coil_helix_lightning;

	ChainLightning*		m_chain_lightning;


	LightningAppearance m_red_beam;
	LightningAppearance m_blue_beam;
	LightningAppearance m_blue_cyan_beam;
	
	Scene			m_scene;

	float m_time;


};


}
	