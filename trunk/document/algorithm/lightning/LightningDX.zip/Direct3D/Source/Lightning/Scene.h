//----------------------------------------------------------------------------------
// File:   Scene.h
// Author: Mathias Schott
// Email:  sdkfeedback@nvidia.com
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
//
//----------------------------------------------------------------------------------

#pragma once
#include "Utility.h"
#include "EffectVariable.h"
#include "Geometry.h"

#include "SDKmisc.h"
#include "SDKmesh_old.h"
#include <nvutmesh.h>
namespace LightningDemo
{
	namespace Effect = Utility::Effect;
	namespace Geometry = Utility::Geometry;

class Scene
{
		enum { NumTargets = 4 };
public:
	
	Scene(ID3D10Device* device);
	~Scene();
	
	void Time(float time);
	void Matrices(const D3DXMATRIX& world,const D3DXMATRIX& view,const D3DXMATRIX& projection);

	void Render() ;
	D3DXVECTOR4 TargetPosition( int which);

private:
	void ShaderMatrices(const D3DXMATRIX& world,const D3DXMATRIX& view,const D3DXMATRIX& projection);
	void RenderTarget(const D3DXMATRIX& transform);

	mutable ID3D10Device*		m_device;
	mutable ID3D10Effect*		m_effect;

	mutable ID3D10EffectTechnique*	m_tech_scene;
	
	mutable Effect::FloatVariable m_time;

	mutable Effect::MatrixVariable m_world;

	mutable Effect::MatrixVariable m_view;
	mutable Effect::MatrixVariable m_projection;

	mutable Effect::MatrixVariable m_world_view;
	mutable Effect::MatrixVariable m_world_view_projection;

	mutable Effect::ShaderResourceVariable m_tex_diffuse;

	struct SceneVertex
	{
		D3DXVECTOR3	Position;
		D3DXVECTOR3	Normal;
		D3DXVECTOR2 TexCoord0;
			static std::vector<D3D10_INPUT_ELEMENT_DESC> GetLayout()
		{
			std::vector<D3D10_INPUT_ELEMENT_DESC> r;

			r.push_back
			(
				Utility::InputElementDesc
				(
					"Position",
					0,
					DXGI_FORMAT_R32G32B32_FLOAT,
					0,
					0, 
					D3D10_INPUT_PER_VERTEX_DATA, 
					0 
				)
			);
			r.push_back
			(
				Utility::InputElementDesc
				(
					"Normal",
					0,
					DXGI_FORMAT_R32G32B32_FLOAT,
					0,
					12, 
					D3D10_INPUT_PER_VERTEX_DATA, 
					0 
				)
			);
			r.push_back
			(
				Utility::InputElementDesc
				(
					"TexCoord",
					0,
					DXGI_FORMAT_R32G32_FLOAT,
					0,
					12 + 12, 
					D3D10_INPUT_PER_VERTEX_DATA, 
					0 
				)
			);
			return r;
		}
		
	};

	D3DXVECTOR4			m_target_positions[NumTargets];
	D3DXMATRIX			m_target_transforms[NumTargets];
	
	NVUTMesh			m_scene_mesh;
	NVUTMesh			m_target_mesh;

	ID3D10InputLayout*	m_scene_layout;

};


}