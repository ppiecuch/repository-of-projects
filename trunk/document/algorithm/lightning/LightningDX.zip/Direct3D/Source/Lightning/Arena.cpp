//----------------------------------------------------------------------------------
// File:   Arena.cpp
// Author: Mathias Schott
// Email:  sdkfeedback@nvidia.com
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
//
//----------------------------------------------------------------------------------

#include "DXUT.h"
#include "Arena.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include <vector>
#include <map>


namespace LightningDemo
{


Arena::Arena(ID3D10Device* device,DXGI_SAMPLE_DESC back_buffer_sample_desc):
	m_device(device),
	m_lightning_renderer(device,back_buffer_sample_desc),
	m_scene(device),
	m_back_buffer_sample_desc(back_buffer_sample_desc)

{
	m_device->AddRef();

	CreateLightning();
}

void Arena::CreateLightning()
{
	LightningStructure inter_coil_structure;
	{
		
		inter_coil_structure.ZigZagFraction = D3DXVECTOR2(0.45f, 0.55f);

		inter_coil_structure.ZigZagDeviationRight = D3DXVECTOR2(-5.0f,5.0f);		
		inter_coil_structure.ZigZagDeviationUp = D3DXVECTOR2(-5.0f,5.0f);

		inter_coil_structure.ZigZagDeviationDecay = 0.5f;
		
		
		inter_coil_structure.ForkFraction = D3DXVECTOR2(0.45f, 0.55f);

		inter_coil_structure.ForkZigZagDeviationRight = D3DXVECTOR2(-1.0f,1.0f);
		inter_coil_structure.ForkZigZagDeviationUp = D3DXVECTOR2(-1.0f,1.0f);
		inter_coil_structure.ForkZigZagDeviationDecay = 0.5f;
		
		
		inter_coil_structure.ForkDeviationRight = D3DXVECTOR2(-1.0f,1.0f);
		inter_coil_structure.ForkDeviationUp = D3DXVECTOR2(-1.0f,1.0f);
		inter_coil_structure.ForkDeviationForward = D3DXVECTOR2(0.0f,1.0f);
		inter_coil_structure.ForkDeviationDecay = 0.5f;
		
		inter_coil_structure.ForkLength = D3DXVECTOR2(1.0f,2.0f);
		inter_coil_structure.ForkLengthDecay = 0.01f;
	}

	LightningStructure fence_structure;
	{
		
		fence_structure.ZigZagFraction = D3DXVECTOR2(0.45f, 0.55f);

		fence_structure.ZigZagDeviationRight = D3DXVECTOR2(-1.0f,1.0f);		
		fence_structure.ZigZagDeviationUp = D3DXVECTOR2(-1.0f,1.0f);

		fence_structure.ZigZagDeviationDecay = 0.5f;
		
		
		fence_structure.ForkFraction = D3DXVECTOR2(0.45f, 0.55f);

		fence_structure.ForkZigZagDeviationRight = D3DXVECTOR2(-1.0f,1.0f);
		fence_structure.ForkZigZagDeviationUp = D3DXVECTOR2(-1.0f,1.0f);
		fence_structure.ForkZigZagDeviationDecay = 0.5f;
		
		
		fence_structure.ForkDeviationRight = D3DXVECTOR2(-1.0f,1.0f);
		fence_structure.ForkDeviationUp = D3DXVECTOR2(-1.0f,1.0f);
		fence_structure.ForkDeviationForward = D3DXVECTOR2(-1.0f,1.0f);
		fence_structure.ForkDeviationDecay = 0.5f;
		
		fence_structure.ForkLength = D3DXVECTOR2(1.0f,2.0f);
		fence_structure.ForkLengthDecay = 0.01f;
	}
	LightningStructure coil_helix_structure;
	{
		
		coil_helix_structure.ZigZagFraction = D3DXVECTOR2(0.45f, 0.55f);

		coil_helix_structure.ZigZagDeviationRight = D3DXVECTOR2(-5.0f,5.0f);		
		coil_helix_structure.ZigZagDeviationUp = D3DXVECTOR2(-5.0f,5.0f);

		coil_helix_structure.ZigZagDeviationDecay = 0.5f;
		
		
		coil_helix_structure.ForkFraction = D3DXVECTOR2(0.45f, 0.55f);

		coil_helix_structure.ForkZigZagDeviationRight = D3DXVECTOR2(-1.0f,1.0f);
		coil_helix_structure.ForkZigZagDeviationUp = D3DXVECTOR2(-1.0f,1.0f);
		coil_helix_structure.ForkZigZagDeviationDecay = 0.5f;
		
		
		coil_helix_structure.ForkDeviationRight = D3DXVECTOR2(-1.0f,1.0f);
		coil_helix_structure.ForkDeviationUp = D3DXVECTOR2(-1.0f,1.0f);
		coil_helix_structure.ForkDeviationForward = D3DXVECTOR2(0.0f,1.0f);
		coil_helix_structure.ForkDeviationDecay = 0.5f;
		
		coil_helix_structure.ForkLength = D3DXVECTOR2(1.0f,2.0f);
		coil_helix_structure.ForkLengthDecay = 0.01f;
	}

	LightningStructure chain_structure;
	{
		
		chain_structure.ZigZagFraction = D3DXVECTOR2(0.45f, 0.55f);

		chain_structure.ZigZagDeviationRight = D3DXVECTOR2(-5.0f,5.0f);		
		chain_structure.ZigZagDeviationUp = D3DXVECTOR2(-5.0f,5.0f);

		chain_structure.ZigZagDeviationDecay = 0.5f;
		
		
		chain_structure.ForkFraction = D3DXVECTOR2(0.45f, 0.55f);

		chain_structure.ForkZigZagDeviationRight = D3DXVECTOR2(-1.0f,1.0f);
		chain_structure.ForkZigZagDeviationUp = D3DXVECTOR2(-1.0f,1.0f);
		chain_structure.ForkZigZagDeviationDecay = 0.5f;
		
		
		chain_structure.ForkDeviationRight = D3DXVECTOR2(-1.0f,1.0f);
		chain_structure.ForkDeviationUp = D3DXVECTOR2(-1.0f,1.0f);
		chain_structure.ForkDeviationForward = D3DXVECTOR2(0.0f,1.0f);
		chain_structure.ForkDeviationDecay = 0.5f;
		
		chain_structure.ForkLength = D3DXVECTOR2(1.0f,2.0f);
		chain_structure.ForkLengthDecay = 0.01f;
	}

	{
		m_blue_beam.BoltWidth = D3DXVECTOR2(0.125f,0.5f);
		m_blue_beam.ColorInside = D3DXVECTOR3(1,1,1);
		m_blue_beam.ColorOutside = D3DXVECTOR3(0,0,1);
		m_blue_beam.ColorFallOffExponent = 2.0f;
	}

	{
		m_blue_cyan_beam.BoltWidth = D3DXVECTOR2(0.25f,0.5f);
		m_blue_cyan_beam.ColorInside = D3DXVECTOR3(0,1,1);
		m_blue_cyan_beam.ColorOutside = D3DXVECTOR3(0,0,1);
		m_blue_cyan_beam.ColorFallOffExponent = 5.0f;
	}

	{
		m_red_beam.BoltWidth = D3DXVECTOR2(0.5f,0.5f);
		m_red_beam.ColorInside =  D3DXVECTOR3(1,1,1);
		m_red_beam.ColorOutside = D3DXVECTOR3(1,0,0);
		m_red_beam.ColorFallOffExponent = 5.0f;
	}

	{
		ReadSeeds(L"Lightning\\seeds.ASE");
		m_inter_coil_lightning->Structure = inter_coil_structure;
		m_fence_lightning->Structure = fence_structure;
		m_coil_helix_lightning->Structure = coil_helix_structure;

		m_chain_lightning->Structure = chain_structure;
	}

}
Arena::~Arena()
{
	m_lightning_renderer.DestroyLightning(m_fence_lightning);
	m_lightning_renderer.DestroyLightning(m_inter_coil_lightning);
	m_lightning_renderer.DestroyLightning(m_coil_helix_lightning);
	m_lightning_renderer.DestroyLightning(m_chain_lightning);

	m_device->Release();
}



void Arena::Matrices(const D3DXMATRIX& view, const D3DXMATRIX& projection)
{
	D3DXMATRIX world;
	D3DXMatrixIdentity(&world);

	m_scene.Matrices(world, view, projection);
	m_lightning_renderer.SetMatrices(world, view, projection);
}

void Arena::Time(float time, float delta_time)
{
	m_time = time;
	m_scene.Time(time);
	m_lightning_renderer.SetTime(time);
}

void Arena::RenderTargetResize(unsigned width, unsigned height, ID3D10RenderTargetView* render_target_view, ID3D10DepthStencilView* depth_stencil_view)
{
	m_lightning_renderer.OnRenderTargetResize(width, height, render_target_view, depth_stencil_view);
}

void Arena::Render()
{
	if(Settings.Scene)
		m_scene.Render();

	bool do_lightning = Settings.Fence ||Settings.InterCoil || Settings.CoilHelix|| Settings.Chain;

	if(do_lightning)
	{
		m_lightning_renderer.Begin();

			if(Settings.Fence)
				m_lightning_renderer.Render(m_fence_lightning,m_red_beam,1.0f,Settings.AnimationSpeed, Settings.Lines);

			if(Settings.InterCoil)
				m_lightning_renderer.Render(m_inter_coil_lightning,m_blue_beam,1.0f,Settings.AnimationSpeed, Settings.Lines);
			
			if(Settings.CoilHelix)
				m_lightning_renderer.Render(m_coil_helix_lightning,m_blue_cyan_beam,1.0f,Settings.AnimationSpeed, Settings.Lines);

			m_chain_lightning->Properties.ChainSource = D3DXVECTOR3(0,25,31);
			m_chain_lightning->Properties.NumTargets = 4;
			
			for( int i = 0; i < m_chain_lightning->Properties.NumTargets; ++i)
				m_chain_lightning->Properties.ChainTargetPositions[i] = m_scene.TargetPosition(i);
		
			if(Settings.Chain)
				m_lightning_renderer.Render(m_chain_lightning, Settings.Beam,1.0f,Settings.AnimationSpeed, Settings.Lines);

		m_lightning_renderer.End(Settings.Glow, Settings.BlurSigma);
	}
}

struct SeedRecord
{
	SeedRecord():
		Closed(false)
	{
	}
	std::string Name;

	std::vector<D3DXVECTOR3> Vertices;
	std::vector<D3DXVECTOR3> InterpolatedVertices;

	bool Closed;
};

void Arena::ReadSeeds(const wchar_t* filename)
{

	HRESULT hr;
	WCHAR path[MAX_PATH];
    V(DXUTFindDXSDKMediaFileCch( path, MAX_PATH, filename ) );

	std::ifstream file(path);

	D3DXVECTOR3 up(0,1,0);

	std::map<std::string, SeedRecord > seeds;
	std::string cur_seed;

	while(file)
	{
		char line_buffer[512] = {0};
		file.getline(line_buffer,512);

		std::stringstream line;

		line << line_buffer;

		std::string cur_command;

		line >> cur_command;

		if ("*NODE_NAME" == cur_command)
		{
			std::string name;
			line >> name;
			name.erase(name.size()-1,1);
			name.erase(0,1);

			cur_seed = name;
			seeds[cur_seed].Name = name;
			
		}
		else if("*SHAPE_CLOSED" == cur_command)
		{
			seeds[cur_seed].Closed = true;
		}
		else if ("*SHAPE_VERTEX_KNOT" == cur_command )
		{
			D3DXVECTOR3 vertex;

			int dummy;
			line >> dummy >> vertex.x >> vertex.z >> vertex.y;
			seeds[cur_seed].Vertices.push_back(vertex);
			seeds[cur_seed].InterpolatedVertices.push_back(vertex);
		}
		else if ("*SHAPE_VERTEX_INTERP" == cur_command )
		{
			D3DXVECTOR3 vertex;

			int dummy;
			line >> dummy >> vertex.x >> vertex.z >> vertex.y;
			seeds[cur_seed].InterpolatedVertices.push_back(vertex);
		}
	}

	std::vector<LightningPathSegment> the_seeds;

	std::vector<LightningPathSegment> fence_seeds;
	std::vector<LightningPathSegment> inter_coil_seeds;

	std::vector<LightningPathSegment> coil_helix_seeds;

	for(std::map<std::string, SeedRecord>::iterator it = seeds.begin(); it != seeds.end(); ++it)
	{
		std::vector<LightningPathSegment>* the_seeds = 0;
		std::vector<D3DXVECTOR3>* seeds = &(it->second.Vertices);

		if(it->first.find("CoilConnector") != std::string::npos && it->second.InterpolatedVertices.size() > 1)
		{
			seeds = &(it->second.InterpolatedVertices);
			the_seeds = &inter_coil_seeds;
		}
		else if(it->first.find("Fence") != std::string::npos)
		{
			the_seeds = &fence_seeds;
		}
		else if(it->first.find("TeslaCoilHelix") != std::string::npos)
		{
			the_seeds = &coil_helix_seeds;
		}
		else
		{
			continue;
		}

		// We duplicate the seed lines for the beams between the tesla coils in order to make the beam thicker
		
		int replicates = 1;
		float jitter = 0.0f;

		if(it->first.find("CoilConnector") != std::string::npos)
		{
			jitter = 1.0f;
			replicates  = 10;
		}

		for(int j = 0; j < replicates; ++j)
		{
			if(seeds->size() > 1)
			{
				for(size_t i = 0; i <seeds->size()-1; ++i)
				{
					the_seeds->push_back
					(
						LightningPathSegment 
						(
							(*seeds)[i] ,
							(*seeds)[i+1],
							up
						)
					);
				}
			
				if(it->second.Closed)
				{
					the_seeds->push_back
					(
						LightningPathSegment 
						(
							(*seeds)[seeds->size()-1],
							(*seeds)[0] ,
							up
						)
					);
				}
			}
		}

		for(size_t i = 0; i < the_seeds->size(); ++i)
		{
			the_seeds->at(i).Start += jitter * D3DXVECTOR3(Utility::Random(-1,1),Utility::Random(-1,1),Utility::Random(-1,1));
			the_seeds->at(i).End += jitter * D3DXVECTOR3(Utility::Random(-1,1),Utility::Random(-1,1),Utility::Random(-1,1));
		}
	}
	
	m_fence_lightning =   m_lightning_renderer.CreatePathLightning(fence_seeds,0x00,5);
	m_inter_coil_lightning =  m_lightning_renderer.CreatePathLightning(inter_coil_seeds,0x08,5);
	m_coil_helix_lightning =  m_lightning_renderer.CreatePathLightning(coil_helix_seeds,0x03,5);
	
	m_chain_lightning = m_lightning_renderer.CreateChainLightning(0x0C,5);
}

}