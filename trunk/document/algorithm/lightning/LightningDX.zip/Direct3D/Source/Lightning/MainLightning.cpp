//----------------------------------------------------------------------------------
// File:   MainLightning.cpp
// Author: Mathias Schott
// Email:  sdkfeedback@nvidia.com
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
//
//----------------------------------------------------------------------------------
#include "DXUT.h"
#include "DXUTgui.h"
#include "DXUTmisc.h"
#include "DXUTCamera.h"
#include "DXUTSettingsDlg.h"
#include "DXUTShapes.h"

#include "SDKmisc.h"
#include "SDKmesh.h"
#include "resource.h"


#include "Utility.h"
using namespace Utility;



#include "Scene.h"
#include "Arena.h"

using namespace LightningDemo;

#define MAX_SPRITES 500




//--------------------------------------------------------------------------------------
// Global variables
//--------------------------------------------------------------------------------------
CModelViewerCamera      g_Camera;               // A model viewing camera
CDXUTDialogResourceManager g_DialogResourceManager; // manager for shared resources of dialogs
CD3DSettingsDlg         g_SettingsDlg;          // Device settings dialog
CDXUTDialog             g_HUD;                  // dialog for standard controls
CDXUTDialog             g_SampleUI;             // dialog for sample specific controls


// Direct3D 10 resources
ID3DX10Font*            g_pFont = NULL;       
ID3DX10Sprite*          g_pSprite = NULL;     
ID3D10Texture2D*		g_pResolvedBuffer = NULL;

Arena*	g_arena = 0;
LightningAppearance g_beam_parameters;

bool	g_render_hud = true;
bool	g_render_scene =  true;

int		g_Frame = 0;

bool	g_screen_capture = false;
bool	g_single_frame = false;

D3DXVECTOR3 g_colors[] = 
{
	D3DXVECTOR3(1.0f,0.0f,0.0f),
	D3DXVECTOR3(0.0f,1.0f,0.0f),
	D3DXVECTOR3(0.0f,0.0f,1.0f),
	D3DXVECTOR3(0.0f,1.0f,1.0f),
	D3DXVECTOR3(1.0f,0.0f,1.0f),
	D3DXVECTOR3(1.0f,1.0f,0.0f),
	D3DXVECTOR3(0.0f,0.0f,0.0f),
	D3DXVECTOR3(1.0f,1.0f,1.0f),

	0.5f * D3DXVECTOR3(1.0f,0.0f,0.0f),
	0.5f * D3DXVECTOR3(0.0f,1.0f,0.0f),
	0.5f * D3DXVECTOR3(0.0f,0.0f,1.0f),
	0.5f * D3DXVECTOR3(0.0f,1.0f,1.0f),
	0.5f * D3DXVECTOR3(1.0f,0.0f,1.0f),
	0.5f * D3DXVECTOR3(1.0f,1.0f,0.0f),
	0.5f * D3DXVECTOR3(1.0f,1.0f,1.0f),
};

const int num_colors = sizeof(g_colors) / sizeof(g_colors[0]);


//--------------------------------------------------------------------------------------
// UI control IDs
//--------------------------------------------------------------------------------------
#define IDC_TOGGLEFULLSCREEN    1
#define IDC_TOGGLEREF           2
#define IDC_CHANGEDEVICE        3
#define IDC_SHOW_TEXT			4

#define IDC_BOLT_WIDTH			5
#define IDC_BOLT_WIDTH_FALLOFF	6
#define IDC_COLOR_EXPONENT		7
#define IDC_ENABLE_FENCE		8
#define IDC_ENABLE_INTER_COIL	9
#define IDC_ENABLE_COIL_HELIX	10
#define IDC_ENABLE_CHAIN		11
#define IDC_ANIMATION_SPEED		12
#define IDC_COLOR				13
#define IDC_ENABLE_SCENE		14
#define IDC_ENABLE_GLOW			15
#define IDC_ENABLE_LINES		16
#define IDC_BLUR_SIGMA_R		17
#define IDC_BLUR_SIGMA_G		18
#define IDC_BLUR_SIGMA_B		19

//--------------------------------------------------------------------------------------
// Forward declarations 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext );
void    CALLBACK OnKeyboard( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext );
void    CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext );
void    CALLBACK OnFrameMove( double fTime, float fElapsedTime, void* pUserContext );
bool    CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, void* pUserContext );

bool    CALLBACK IsD3D10DeviceAcceptable( UINT Adapter, UINT Output, D3D10_DRIVER_TYPE DeviceType, DXGI_FORMAT BackBufferFormat, bool bWindowed, void* pUserContext );
HRESULT CALLBACK OnD3D10CreateDevice( ID3D10Device* pd3dDevice, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
HRESULT CALLBACK OnD3D10ResizedSwapChain( ID3D10Device* pd3dDevice, IDXGISwapChain *pSwapChain, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
void    CALLBACK OnD3D10FrameRender( ID3D10Device* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext );
void    CALLBACK OnD3D10ReleasingSwapChain( void* pUserContext );
void    CALLBACK OnD3D10DestroyDevice( void* pUserContext );

void    InitApp();
void    RenderText();


//--------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//--------------------------------------------------------------------------------------
int WINAPI wWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set DXUT callbacks
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackKeyboard( OnKeyboard );
    DXUTSetCallbackFrameMove( OnFrameMove );
    DXUTSetCallbackDeviceChanging( ModifyDeviceSettings );

    DXUTSetCallbackD3D10DeviceAcceptable( IsD3D10DeviceAcceptable );
    DXUTSetCallbackD3D10DeviceCreated( OnD3D10CreateDevice );
    DXUTSetCallbackD3D10SwapChainResized( OnD3D10ResizedSwapChain );
    DXUTSetCallbackD3D10SwapChainReleasing( OnD3D10ReleasingSwapChain );
    DXUTSetCallbackD3D10DeviceDestroyed( OnD3D10DestroyDevice );
    DXUTSetCallbackD3D10FrameRender( OnD3D10FrameRender );

	HRESULT hr;
	V_RETURN(DXUTSetMediaSearchPath(L"..\\Source\\Lightning"));
	
    InitApp();
    
	DXUTInit( true, true, NULL ); // Parse the command line, show msgboxes on error, no extra command line params
    DXUTSetCursorSettings( true, true );
    
	DXUTCreateWindow( L"Lightning" );
	DXUTCreateDevice( true, 800, 600 );
	
    DXUTMainLoop(); // Enter into the DXUT render loop

    return DXUTGetExitCode();
}


//--------------------------------------------------------------------------------------
// Initialize the app 
//--------------------------------------------------------------------------------------
void InitApp()
{
    g_SettingsDlg.Init( &g_DialogResourceManager );
    g_HUD.Init( &g_DialogResourceManager );
    g_SampleUI.Init( &g_DialogResourceManager );
	
    g_HUD.SetCallback( OnGUIEvent ); int iY = 10; 
    g_HUD.AddButton( IDC_TOGGLEFULLSCREEN, L"Toggle full screen", 35, iY, 125, 22 );
    g_HUD.AddButton( IDC_TOGGLEREF, L"Toggle REF (F3)", 35, iY += 24, 125, 22, VK_F3 );
    g_HUD.AddButton( IDC_CHANGEDEVICE, L"Change device (F2)", 35, iY += 24, 125, 22, VK_F2 );

	
	
    g_SampleUI.SetCallback( OnGUIEvent ); iY = 10; 
	g_SampleUI.AddCheckBox(IDC_SHOW_TEXT,L"Show text", 0, iY+=24, 125 ,22, true,0,false,0);
	

	int split = 75;
	iY +=24;
	
	g_SampleUI.AddCheckBox(IDC_ENABLE_SCENE,L"draw scene", 0, iY, 100 ,22, true,0,false,0);
	iY+=24;

	g_SampleUI.AddStatic(0,L"anim speed",0,iY,split,22);
	g_SampleUI.AddSlider(IDC_ANIMATION_SPEED,split,iY,200-split,22,0,100,15);

	iY+=24;
	g_SampleUI.AddStatic(0,L"width",0,iY,split,22);
	g_SampleUI.AddSlider(IDC_BOLT_WIDTH,split,iY,200-split,22,0,500,50);

	iY+=24;
	g_SampleUI.AddStatic(0,L"width falloff ",0,iY,split,22);
	g_SampleUI.AddSlider(IDC_BOLT_WIDTH_FALLOFF,split,iY,200-split,22,0,100,50);

	iY+=24;
	g_SampleUI.AddStatic(0,L"color ",0,iY,split,22);
	g_SampleUI.AddSlider(IDC_COLOR,split,iY,200-split,22,0,num_colors,5);

	iY+=24;
	g_SampleUI.AddStatic(0,L"color exponent",0,iY,split,22);
	g_SampleUI.AddSlider(IDC_COLOR_EXPONENT,split,iY,200-split,22,1,50,5);



	iY +=24;
	g_SampleUI.AddCheckBox(IDC_ENABLE_CHAIN,L"chain", 0, iY, 100 ,22, true,0,false,0);
	g_SampleUI.AddCheckBox(IDC_ENABLE_FENCE,L"fence", 100, iY, 100 ,22, true,0,false,0);

	iY +=24;
	g_SampleUI.AddCheckBox(IDC_ENABLE_COIL_HELIX,L"coil", 0, iY, 100 ,22, true,0,false,0);
	g_SampleUI.AddCheckBox(IDC_ENABLE_INTER_COIL,L"connector", 100, iY, 100 ,22, true,0,false,0);

	iY +=24;
	g_SampleUI.AddCheckBox(IDC_ENABLE_GLOW,L"glow", 0, iY, 100 ,22, true,0,false,0);
	g_SampleUI.AddCheckBox(IDC_ENABLE_LINES,L"show lines", 100, iY, 100 ,22, false,0,false,0);


	iY +=24;
	g_SampleUI.AddStatic(0,L"glow sigma r",0,iY,split,22);
	g_SampleUI.AddSlider(IDC_BLUR_SIGMA_R,split,iY,200-split,22,0,200,50);

	iY +=24;
	g_SampleUI.AddStatic(0,L"glow sigma g",0,iY,split,22);
	g_SampleUI.AddSlider(IDC_BLUR_SIGMA_G,split,iY,200-split,22,0,200,80);

	iY +=24;
	g_SampleUI.AddStatic(0,L"glow sigma b",0,iY,split,22);
	g_SampleUI.AddSlider(IDC_BLUR_SIGMA_B,split,iY,200-split,22,0,200,90);



}


//--------------------------------------------------------------------------------------
// Render the help and statistics text. This function uses the ID3DXFont interface for 
// efficient text rendering.
//--------------------------------------------------------------------------------------
void RenderText()
{
    CDXUTTextHelper txtHelper(g_pFont, g_pSprite, 15 );

    txtHelper.Begin();
    txtHelper.SetInsertionPos( 5, 5 );
    txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 0.0f, 1.0f ) );
    txtHelper.DrawTextLine( DXUTGetFrameStats( true ) );  // Do not show FPS.  Change to true to show FPS
    txtHelper.DrawTextLine( DXUTGetDeviceStats() );
    txtHelper.End();
}


//--------------------------------------------------------------------------------------
// Reject any D3D10 devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsD3D10DeviceAcceptable( UINT Adapter, UINT Output, D3D10_DRIVER_TYPE DeviceType, DXGI_FORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
    return true;
}


//--------------------------------------------------------------------------------------
// Create any D3D10 resources that aren't dependant on the back buffer
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnD3D10CreateDevice( ID3D10Device* pd3dDevice, const DXGI_SURFACE_DESC *pBackBufferSurfaceDesc, void* pUserContext )
{
    HRESULT hr;

	// with that call, the HUD font don't show properly in refrast
    V_RETURN( D3DX10CreateSprite( pd3dDevice, MAX_SPRITES, &g_pSprite ) );
   
	V_RETURN( g_DialogResourceManager.OnD3D10CreateDevice( pd3dDevice ) );
    V_RETURN( g_SettingsDlg.OnD3D10CreateDevice( pd3dDevice ) );
    V_RETURN( D3DX10CreateFont( pd3dDevice, 15, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Arial", &g_pFont ) );

    // Setup the camera's view parameters
	D3DXVECTOR3 vecEye(44.5418f, 53.0726f, -42.1582f);
	D3DXVECTOR3 vecAt (0.0f, 0.0f, -0.0f);

	g_Camera.SetViewParams( &vecEye, &vecAt );

	
	unsigned int num_quality_levels = 0;
	pd3dDevice->CheckMultisampleQualityLevels(LightningRenderer::BackBufferFormat, pBackBufferSurfaceDesc->SampleDesc.Count,&num_quality_levels);

	if(0 == num_quality_levels)
	{
		MessageBox(DXUTGetHWND(),L"The device does not support MSAA for surfaces required for ofsceen processing with the specified sample count. This application will now exit",L"Error", MB_OK | MB_ICONERROR);
		PostQuitMessage(0);
		return E_FAIL;
	}

	g_arena = new Arena(pd3dDevice,pBackBufferSurfaceDesc->SampleDesc);

    return S_OK;
}


//--------------------------------------------------------------------------------------
// Create any D3D10 resources that depend on the back buffer
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnD3D10ResizedSwapChain( ID3D10Device* pd3dDevice, IDXGISwapChain *pSwapChain, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    HRESULT hr;

    V_RETURN( g_DialogResourceManager.OnD3D10ResizedSwapChain( pd3dDevice, pBackBufferSurfaceDesc ) );
    V_RETURN( g_SettingsDlg.OnD3D10ResizedSwapChain( pd3dDevice, pBackBufferSurfaceDesc ) );

    // Setup the camera's projection parameters
    float fAspectRatio = pBackBufferSurfaceDesc->Width / (FLOAT)pBackBufferSurfaceDesc->Height;
    g_Camera.SetProjParams( 0.33f *  D3DX_PI, fAspectRatio, 0.1f, 1000.0f );
    g_Camera.SetWindow( pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height );
    g_Camera.SetButtonMasks( MOUSE_LEFT_BUTTON, MOUSE_WHEEL, MOUSE_MIDDLE_BUTTON );

    g_HUD.SetLocation( pBackBufferSurfaceDesc->Width-170, 25 );
    g_HUD.SetSize( 170, 170 - 25 );
    
	g_SampleUI.SetLocation( pBackBufferSurfaceDesc->Width-225, 100 );
    g_SampleUI.SetSize( 200, 75 );

	if(0 != g_arena)
		g_arena->RenderTargetResize(pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height,  DXUTGetD3D10RenderTargetView(), DXUTGetD3D10DepthStencilView());

	SAFE_RELEASE(g_pResolvedBuffer);

	
	D3D10_TEXTURE2D_DESC tex_desc = Texture2DDesc
	(
		pBackBufferSurfaceDesc->Width, 
		pBackBufferSurfaceDesc->Height, 
		1,
		1,
		pBackBufferSurfaceDesc->Format,
		Utility::SampleDesc(1,0),
		D3D10_USAGE_DEFAULT,
		D3D10_BIND_RENDER_TARGET | D3D10_BIND_SHADER_RESOURCE,
		0,
		0
	);


	V(pd3dDevice->CreateTexture2D(& tex_desc,0,&g_pResolvedBuffer));
	
	
	return S_OK;
}


//--------------------------------------------------------------------------------------
// Render the scene using the D3D10 device
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10FrameRender( ID3D10Device* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	float ClearColor[4] = { 0.0f, 0.0f, 0.3f, 1.0f };


    ID3D10RenderTargetView* pRTV = DXUTGetD3D10RenderTargetView();
    pd3dDevice->ClearRenderTargetView( pRTV, ClearColor );

    // Clear the depth stencil
    ID3D10DepthStencilView* pDSV = DXUTGetD3D10DepthStencilView();
    pd3dDevice->ClearDepthStencilView( pDSV, D3D10_CLEAR_DEPTH, 1.0, 0 );

    // If the settings dialog is being shown, then render it instead of rendering the app's scene
    if( g_SettingsDlg.IsActive() )
    {
        g_SettingsDlg.OnRender( fElapsedTime );
        return;
    }
	
	float  t = float(fTime);
	float dt = float(fElapsedTime);
		
	D3DXMATRIX view = *g_Camera.GetWorldMatrix() * *g_Camera.GetViewMatrix();
	D3DXMATRIX world;
	D3DXMatrixIdentity(&world);


	g_beam_parameters.BoltWidth = D3DXVECTOR2
	(
		0.5f  * (50 + g_SampleUI.GetSlider(IDC_BOLT_WIDTH)->GetValue()) / 100.0f ,
		0.5f  * (50 + g_SampleUI.GetSlider(IDC_BOLT_WIDTH_FALLOFF)->GetValue()) / 100.0f 
	); 
	g_beam_parameters.ColorInside =  D3DXVECTOR3(1,1,1);
	g_beam_parameters.ColorOutside = g_colors[g_SampleUI.GetSlider(IDC_COLOR)->GetValue()];
	
	g_beam_parameters.ColorFallOffExponent = float(g_SampleUI.GetSlider(IDC_COLOR_EXPONENT)->GetValue());



	g_arena->Settings.Scene =  g_SampleUI.GetCheckBox(IDC_ENABLE_SCENE)->GetChecked();
	g_arena->Settings.Chain =  g_SampleUI.GetCheckBox(IDC_ENABLE_CHAIN)->GetChecked();
	g_arena->Settings.Fence =  g_SampleUI.GetCheckBox(IDC_ENABLE_FENCE)->GetChecked();
	g_arena->Settings.CoilHelix =  g_SampleUI.GetCheckBox(IDC_ENABLE_COIL_HELIX)->GetChecked();
	g_arena->Settings.InterCoil =  g_SampleUI.GetCheckBox(IDC_ENABLE_INTER_COIL)->GetChecked();

	
	g_arena->Settings.BlurSigma = D3DXVECTOR3
	(
		g_SampleUI.GetSlider(IDC_BLUR_SIGMA_R)->GetValue() / 100.0f ,
		g_SampleUI.GetSlider(IDC_BLUR_SIGMA_G)->GetValue() / 100.0f ,
		g_SampleUI.GetSlider(IDC_BLUR_SIGMA_B)->GetValue() / 100.0f 
	); 


	
	g_arena->Settings.Beam = g_beam_parameters;
	g_arena->Settings.AnimationSpeed =  float(g_SampleUI.GetSlider(IDC_ANIMATION_SPEED)->GetValue());
	
	g_arena->Settings.Glow =  g_SampleUI.GetCheckBox(IDC_ENABLE_GLOW)->GetChecked();
	g_arena->Settings.Lines =  g_SampleUI.GetCheckBox(IDC_ENABLE_LINES)->GetChecked();
	
	g_arena->Matrices(view, *g_Camera.GetProjMatrix());
	g_arena->Time(t,dt);
	g_arena->Render();

	if(g_screen_capture || g_single_frame)
	{
		IDXGISwapChain* pSwapChain = DXUTGetDXGISwapChain();

		ID3D10Texture2D* pRT;

		pSwapChain->GetBuffer(0, __uuidof(pRT), reinterpret_cast<void**>(&pRT));

		DXUTGetD3D10Device()->ResolveSubresource(g_pResolvedBuffer,0,pRT,0,DXUTGetDXGIBackBufferSurfaceDesc()->Format);
		WCHAR filename[MAX_PATH];

		if(g_single_frame)
		{
			D3DX10SaveTextureToFile(g_pResolvedBuffer, D3DX10_IFF_PNG, L"last_frame.png");
			g_single_frame = false;
			MessageBox(DXUTGetHWND(),L"Frame saved",L"Hint",MB_OK);
		}
		else
		{
			StringCchPrintf(filename, MAX_PATH, L"screenshot%.5d.bmp",g_Frame); 
			D3DX10SaveTextureToFile(g_pResolvedBuffer, D3DX10_IFF_BMP, filename);
		}

		pRT->Release();
		
		++g_Frame;

	}
	if( g_SampleUI.GetCheckBox(IDC_SHOW_TEXT)->GetChecked())
	{
		RenderText();
	}

	if(g_render_hud)
	{
		g_HUD.OnRender( fElapsedTime ); 
		g_SampleUI.OnRender( fElapsedTime );
	}
}


//--------------------------------------------------------------------------------------
// Release D3D10 resources created in OnD3D10ResizedSwapChain 
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10ReleasingSwapChain( void* pUserContext )
{
    g_DialogResourceManager.OnD3D10ReleasingSwapChain();
}


//--------------------------------------------------------------------------------------
// Release D3D10 resources created in OnD3D10CreateDevice 
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10DestroyDevice( void* pUserContext )
{
	
	delete g_arena;


    g_DialogResourceManager.OnD3D10DestroyDevice();
    g_SettingsDlg.OnD3D10DestroyDevice();
    SAFE_RELEASE( g_pFont );
    SAFE_RELEASE( g_pSprite );

	SAFE_RELEASE(g_pResolvedBuffer);
	D3DX10UnsetAllDeviceObjects(DXUTGetD3D10Device());

}


//--------------------------------------------------------------------------------------
// Called right before creating a D3D9 or D3D10 device, allowing the app to modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, void* pUserContext )
{
    // For the first device created if its a REF device, optionally display a warning dialog box
    static bool s_bFirstTime = true;
    if( s_bFirstTime )
    {
        s_bFirstTime = false;
        if( (DXUT_D3D9_DEVICE == pDeviceSettings->ver && pDeviceSettings->d3d9.DeviceType == D3DDEVTYPE_REF) ||
            (DXUT_D3D10_DEVICE == pDeviceSettings->ver && pDeviceSettings->d3d10.DriverType == D3D10_DRIVER_TYPE_REFERENCE) )
            DXUTDisplaySwitchingToREFWarning( pDeviceSettings->ver );
    }

	//pDeviceSettings->d3d10.sd.SampleDesc.Count = 1;
	//pDeviceSettings->d3d10.sd.SampleDesc.Quality = 0;

    return true;
}


//--------------------------------------------------------------------------------------
// Handle updates to the scene.  This is called regardless of which D3D API is used
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( double fTime, float fElapsedTime, void* pUserContext )
{
    // Update the camera's position based on user input 
    g_Camera.FrameMove( fElapsedTime );


}


//--------------------------------------------------------------------------------------
// Handle messages to the application
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext )
{
    // Pass messages to dialog resource manager calls so GUI state is updated correctly
    *pbNoFurtherProcessing = g_DialogResourceManager.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;

    // Pass messages to settings dialog if its active
    if( g_SettingsDlg.IsActive() )
    {
        g_SettingsDlg.MsgProc( hWnd, uMsg, wParam, lParam );
        return 0;
    }

    // Give the dialogs a chance to handle the message first

	if(g_render_hud)
	{
		*pbNoFurtherProcessing = g_HUD.MsgProc( hWnd, uMsg, wParam, lParam );
		if( *pbNoFurtherProcessing )
			return 0;
		*pbNoFurtherProcessing = g_SampleUI.MsgProc( hWnd, uMsg, wParam, lParam );
		if( *pbNoFurtherProcessing )
			return 0;

	}
    // Pass all remaining windows messages to camera so it can respond to user input
    g_Camera.HandleMessages( hWnd, uMsg, wParam, lParam );

    return 0;
}


//--------------------------------------------------------------------------------------
// Handle key presses
//--------------------------------------------------------------------------------------
void CALLBACK OnKeyboard( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext )
{

	if(bKeyDown)
	{
		switch(nChar)
		{
			case VK_SPACE: 
				g_render_hud = ! g_render_hud;
				break;
	
			case 'C' :
				g_screen_capture =  !g_screen_capture;
				break;
			case 'F' :
				g_single_frame = true;
				break;
		}
	}
	else
	{
	}
}


//--------------------------------------------------------------------------------------
// Handles the GUI events
//--------------------------------------------------------------------------------------
void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext )
{
    switch( nControlID )
    {
        case IDC_TOGGLEFULLSCREEN: DXUTToggleFullScreen(); break;
        case IDC_TOGGLEREF:        DXUTToggleREF(); break;
        case IDC_CHANGEDEVICE:     g_SettingsDlg.SetActive( !g_SettingsDlg.IsActive() ); break;
    }
}


