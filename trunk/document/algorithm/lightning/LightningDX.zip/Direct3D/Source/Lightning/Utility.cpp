//----------------------------------------------------------------------------------
// File: Utility.cpp
// Author: Mathias Schott
// Email:  sdkfeedback@nvidia.com
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
//
//----------------------------------------------------------------------------------

#include "DXUT.h"
#include "DXUTgui.h"
#include "DXUTmisc.h"
#include "DXUTCamera.h"
#include "DXUTSettingsDlg.h"
#include "DXUTShapes.h"

#include "SDKmisc.h"
#include "SDKmesh.h"

#include "utility.h"

#pragma warning (disable:4996)
namespace Utility
{
	using namespace std;

	void	DebugPrint(const char* format, ...)
	{
		va_list args;
		size_t     len;
		char    *buffer;

		// retrieve the variable arguments
		va_start( args, format );
	    
		len = _vscprintf( format, args ) // _vscprintf doesn't count
									+ 1; // terminating '\0'
	    
		buffer = (char*)malloc( len * sizeof(char) );

		vsnprintf( buffer,len, format, args ); // C4996
		// Note: vsprintf is deprecated; consider using vsprintf_s instead
		OutputDebugStringA(buffer);
		free( buffer );
	}

	float Random(float lower, float upper)
	{
		return lower  + (upper - lower) * std::rand() / RAND_MAX;
	}

	std::wstring LocateFile(const wchar_t* name)
	{
		WCHAR str[MAX_PATH];
		if( SUCCEEDED( DXUTFindDXSDKMediaFileCch( str, 
												MAX_PATH,
												name
												)
											)
											)
			return str;
		else
			return L"";
	}

ID3D10Effect* LoadEffect(ID3D10Device* device, const wchar_t* filename)
{ 
	HRESULT hr;
	ID3D10Effect* effect;
	WCHAR str[MAX_PATH];
    V(DXUTFindDXSDKMediaFileCch( str, MAX_PATH, filename ) );

	ID3D10Blob* errors = 0;
    hr = D3DX10CreateEffectFromFile
	( 
		str, 
		NULL,
		NULL,
		"fx_4_0",
#ifdef _DEBUG
		D3D10_SHADER_DEBUG |
#endif
		D3D10_SHADER_ENABLE_BACKWARDS_COMPATIBILITY, 
		0, 
		device, 
		NULL, 
		NULL, 
		&effect, 
		&errors,
		NULL
	) ;

	if( FAILED( hr ) )
    {
		if(0 != errors)
			MessageBoxA
			(
				0, 
				(LPCSTR)errors->GetBufferPointer(), 
				"Error", 
				MB_OK 
			);
		else
			MessageBoxA
			(
				0, 
				"error from D3DX10CreateEffectFromFile == 0" , 
				"Error", 
				MB_OK 
			);
		SAFE_RELEASE(errors);
		exit(0);
	}
	else if( 0 != errors)
	{
       OutputDebugStringA((LPCSTR)errors->GetBufferPointer());
       SAFE_RELEASE(errors);
	}
	V(hr);
	return effect;
}

namespace Effect
{
	UINT NumPasses(ID3D10EffectTechnique* technique)
	{
		D3D10_TECHNIQUE_DESC td;
		technique->GetDesc(&td);
		return td.Passes;
	}
}
}


