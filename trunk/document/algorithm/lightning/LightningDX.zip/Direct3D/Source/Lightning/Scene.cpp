//----------------------------------------------------------------------------------
// File:   Scene.cpp
// Author: Mathias Schott
// Email:  sdkfeedback@nvidia.com
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
//
//----------------------------------------------------------------------------------

#include "DXUT.h"
#include "Scene.h"


namespace LightningDemo
{

Scene::Scene(ID3D10Device* device):
	m_device(device),
	m_effect(Utility::LoadEffect(device,L"Scene.fx")),

	m_tech_scene(m_effect->GetTechniqueByName("RenderScene")),

	m_world(m_effect,"world"),
	m_view(m_effect,"view"),
	m_projection(m_effect,"projection"),

	m_world_view(m_effect,"world_view"),
	m_world_view_projection(m_effect,"world_view_projection"),

	m_time(m_effect,"time"),
	m_tex_diffuse(m_effect,"tex_diffuse")

{
	m_device->AddRef();

	m_scene_layout = Geometry::CreateInputLayout(m_device, SceneVertex::GetLayout(),m_tech_scene);
	HRESULT hr;
	V( m_scene_mesh.Create( m_device, L"Lightning\\scene.x",  &SceneVertex::GetLayout()[0], UINT(SceneVertex::GetLayout().size()) ,true) );
	V( m_target_mesh.Create( m_device, L"Lightning\\chain_target.x",  &SceneVertex::GetLayout()[0], UINT(SceneVertex::GetLayout().size()) ,true) );
}


Scene::~Scene()
{
	m_scene_mesh.Destroy();
	m_scene_layout->Release();

	m_effect->Release();
	m_device->Release();
}

void Scene::Time(float time)
{
	m_time = time;

	float s[NumTargets] = {1.00f, -0.5f, 0.5f, 2.0f};
	float r[NumTargets] = {7.0f, 9.0f, 11.0f, 13.0f};
	float d[NumTargets] = {5.0f, 10.0f, 15.0f, 20.0f};


	for(int i = 0 ; i < NumTargets; ++i)
	{
		float angle = s[i] * m_time;

		m_target_positions[i] =  D3DXVECTOR4( r[i] * sin(angle),d[i], r[i] * cos(angle),1);

		D3DXMATRIX rotation;
		D3DXMatrixRotationY(&rotation,angle);

		D3DXMATRIX translation;
		D3DXMatrixTranslation(&translation,0,d[i],r[i]);

		D3DXMATRIX tumble;

		float t_a = 10 * m_time;
		D3DXVECTOR3 axis(sin(t_a), cos(t_a), -sin(t_a));
		D3DXMatrixRotationAxis(&tumble,&axis, angle);

		m_target_transforms[i] = tumble * translation * rotation  ;

	}

}

D3DXVECTOR4 Scene::TargetPosition( int which)
{
	if(which < NumTargets)
	{
		return m_target_positions[which];
	}
	else
	{
		return D3DXVECTOR4(0,0,0,1);
	}
}
void Scene::Matrices(const D3DXMATRIX& world,const D3DXMATRIX& view,const D3DXMATRIX& projection)
{
	ShaderMatrices(world, view,projection);
}

void Scene::ShaderMatrices(const D3DXMATRIX& world,const D3DXMATRIX& view,const D3DXMATRIX& projection)
{
	m_world = world;
	m_projection = projection;
	m_view = view;

	m_world_view = world * view;
	m_world_view_projection = world * view * projection;

}

void Scene::RenderTarget(const D3DXMATRIX& transform)
{
	ShaderMatrices(transform,m_view, m_projection);
	m_target_mesh.Render( m_device, m_tech_scene, m_tex_diffuse );
}

void Scene::Render()  
{	
	m_device->IASetInputLayout(m_scene_layout);
	m_device->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	m_scene_mesh.Render( m_device, m_tech_scene, m_tex_diffuse );
	
	for(int i = 0; i < NumTargets; ++i)
		RenderTarget(m_target_transforms[i]);

}

}