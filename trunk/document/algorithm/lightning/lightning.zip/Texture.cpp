//-------------------------------------------------------------------
//	File:		Texture.cpp
//	Created:	05/26/99 2:37:AM
//	Author:		Aaron Hilton & Joseph Wasson
//	Comments:	Create and manage OpenGL textures.
//-------------------------------------------------------------------
#include "stdafx.h"
#include "Texture.h"
#include "ijl.h"

CTexture::CTexture()
{
	m_nID=0;
}

CTexture::~CTexture()
{
	Toast();
}

// Create is protected, since you're supposed to use the LoadBLAH() methods now.
bool CTexture::Create(char* szFileName)
{
	Toast();

	// Copy and terminate the filename.
	UInt32 nszLen = strlen(szFileName);
	memcpy(m_szName, szFileName, nszLen);
	m_szName[nszLen]='\0';

	// Generate texture id.
	glGenTextures(1, &m_nID);
	m_nID++; // Use an offset of +1 to differentiate from non-initialized state.

	glBindTexture(GL_TEXTURE_2D, m_nID-1);
	glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
	return true;
}

void CTexture::Toast()
{
	if( m_nID )
	{
		m_nID--;
		glDeleteTextures(1, &m_nID);
		m_nID=0;
	}
}

void CTexture::Use()
{
	glBindTexture(GL_TEXTURE_2D, m_nID-1);
}

bool CTexture::LoadBMP(char* szFileName)
{
	// Create the texture binding, and prepare additional info.
    Create(szFileName);

	HANDLE hFileHandle;
	BITMAPINFO *pBitmapInfo = NULL;
	unsigned long lInfoSize = 0;
	unsigned long lBitSize = 0;
	BYTE *pBitmapData;

	// Open the Bitmap file
	hFileHandle = CreateFile(szFileName,GENERIC_READ,FILE_SHARE_READ,
		NULL,OPEN_EXISTING,FILE_FLAG_SEQUENTIAL_SCAN,NULL);

	// Check for open failure (most likely file does not exist).
	if(hFileHandle == INVALID_HANDLE_VALUE)
		return false;

	// File is Open. Read in bitmap header information
	BITMAPFILEHEADER	bitmapHeader;
	DWORD dwBytes;
	ReadFile(hFileHandle,&bitmapHeader,sizeof(BITMAPFILEHEADER),
		&dwBytes,NULL);

	__try {
		if(dwBytes != sizeof(BITMAPFILEHEADER))
			return false;

		// Check format of bitmap file
		if(bitmapHeader.bfType != 'MB')
			return false;

		// Read in bitmap information structure
		lInfoSize = bitmapHeader.bfOffBits - sizeof(BITMAPFILEHEADER);
		pBitmapInfo = (BITMAPINFO *) new BYTE[lInfoSize];

		ReadFile(hFileHandle,pBitmapInfo,lInfoSize,&dwBytes,NULL);

		if(dwBytes != lInfoSize)
			return false;


		m_nWidth = pBitmapInfo->bmiHeader.biWidth;
		m_nHeight = pBitmapInfo->bmiHeader.biHeight;
		lBitSize = pBitmapInfo->bmiHeader.biSizeImage;

		if(lBitSize == 0)
			lBitSize = (m_nWidth *
               pBitmapInfo->bmiHeader.biBitCount + 7) / 8 *
  			  abs(m_nHeight);

		// Allocate space for the actual bitmap
		pBitmapData = new BYTE[lBitSize];

		// Read in the bitmap bits
		ReadFile(hFileHandle,pBitmapData,lBitSize,&dwBytes,NULL);

		if(lBitSize != dwBytes)
			{
			if(pBitmapData)
				delete [] (BYTE *) pBitmapData;
			pBitmapData = NULL;

			return false;
			}
		}
	__finally // Fail or success, close file and free working memory
		{
		CloseHandle(hFileHandle);

		if(pBitmapInfo != NULL)
			delete [] (BYTE *)pBitmapInfo;
		}


	// This is specific to the binary format of the data read in.
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
    glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
    glPixelStorei(GL_UNPACK_SKIP_ROWS, 0);
    glPixelStorei(GL_UNPACK_SKIP_PIXELS, 0);

//    glTexImage2D(GL_TEXTURE_2D, 0, 3, m_nWidth, m_nHeight, 0,
//                 GL_BGR_EXT, GL_UNSIGNED_BYTE, pBitmapData);
    gluBuild2DMipmaps(GL_TEXTURE_2D, 3, m_nWidth, m_nHeight, GL_BGR_EXT, GL_UNSIGNED_BYTE, pBitmapData);

	if(pBitmapData)
		delete [] (BYTE *) pBitmapData;

	return true;
}

// Note: This routine has a couple of bugs in it concerning Alpha, but it works for 3 channel images.
// Thanks goes to Joseph Wasson (tyrant@oz.net) for writing this code! :)
bool CTexture::LoadJPG (char* szFileName, bool asAlpha)
{
	// Create the texture binding, and prepare additional info.
    Create(szFileName);

    DWORD width = 0, height = 0, channels = 0;
    int RetVal;
    JPEG_CORE_PROPERTIES image;
    ZeroMemory( &image, sizeof( JPEG_CORE_PROPERTIES ) );
    if( ijlInit( &image ) != IJL_OK )
    {
        return false;
    }
    image.JPGFile = szFileName;
    if ((RetVal = ijlRead(&image,IJL_JFILE_READPARAMS)) == IJL_OK)
    {
        m_nHeight = image.JPGHeight;
        m_nWidth = image.JPGWidth;
        channels = asAlpha ? 1 : 3;

        BYTE *img = new BYTE[m_nHeight * m_nWidth * channels];
        if (img)
        {
            image.DIBBytes = img;
            image.DIBColor = asAlpha ? IJL_G : IJL_RGB;
            image.DIBHeight = m_nHeight;
            image.DIBWidth = m_nWidth;
            //image.DIBColor = IJL_YCBCR;
            image.DIBChannels = channels;


            if ((RetVal = ijlRead(&image,IJL_JFILE_READWHOLEIMAGE)) == IJL_OK)
            {
                gluBuild2DMipmaps(GL_TEXTURE_2D, channels, m_nWidth, m_nHeight, asAlpha ? GL_ALPHA : GL_RGB, GL_UNSIGNED_BYTE, img);
                //glTexImage2D (GL_TEXTURE_2D, 0, channels, image.DIBWidth, image.DIBHeight, 0, asAlpha ? GL_ALPHA : GL_RGB, GL_UNSIGNED_BYTE, img);
            }
        }

        delete img;
    }
    ijlFree(&image);
    if (RetVal)
    {
        unsigned char img[] = {0, 255, 255, 0};
        m_nWidth = 2;
        m_nHeight = 2;
        gluBuild2DMipmaps(GL_TEXTURE_2D, 1, m_nWidth, m_nHeight, GL_LUMINANCE, GL_UNSIGNED_BYTE, img);
        //glTexImage2D (GL_TEXTURE_2D, 0, 1, 2, 2, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, img);
    }
        
    return RetVal ? false : true;
}


//-------------------------------------------------------------------
//	History:
//	$Log:$
//-------------------------------------------------------------------
