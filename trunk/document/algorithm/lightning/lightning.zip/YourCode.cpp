//-------------------------------------------------------------------
//	File:		YourCode.cpp
//	Comments:	Write your visual effect here.
//-------------------------------------------------------------------
#include "stdafx.h"
#include "Texture.h"

//----------------------------------------
// Usefull debugger thingy.
void DebugOut(const char *szFormat, ...);
//----------------------------------------

// Change your App Name.
char szAppName[] = "Lightning";

// Timer info.  Very useful for keeping animated stuff in sync on different computers.
extern float fTime, fDeltaTime;

// Current window dimensions.
extern GLsizei g_w, g_h;

// Use the demonstration texture.
CTexture gTexExample;

static void  initLighting( void )
{
    GLfloat	   light_position[] = { 0.0, 0.0, 0.0, 0.0 };
    GLfloat	   light_diffuse[] = { 1.0, 1.0, 1.0, 0.0 };
    GLfloat	   light_specular[] = { 1.0, 1.0, 1.0, 0.0 };
    GLfloat	   lmodel_ambient[] = { 10.0, 10.0, 10.0, 0.0 };
    GLfloat	   mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat	   mat_shininess[] = { 50.0 };
    static float   litazim = 0.0;
    static float   litinclin = 0.0;
 
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

				  /* correct position for coordinate system where z axis faces viewer,
    x axis points right, y axis points up */

//    light_position[1] = (GLfloat)litx;
//    light_position[2] = (GLfloat)litz;
//    light_position[3] = (GLfloat)-lity;
    light_position[1] = 100.0;
    light_position[2] = 100.0;
    light_position[3] = 100.0;

    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
//    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);  /* OFF for now */
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);
//      glLightModeli(GL_LIGHT_MODEL_TWO_SIDE,GL_TRUE);
    glColorMaterial(GL_FRONT_AND_BACK, GL_DIFFUSE);
    

    glEnable(GL_LIGHT0);		/* but wait on GL_LIGHTING */

	//glEnable(GL_CULL_FACE);
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);

//	init_terrain(64,20);
//	glEnable(GL_NORMALIZE);

}					/* end of initLighting */

// Startup Stuff.
bool Init()	// Called right after the window is created, and OpenGL is initialized.
{
	initLighting();
	glEnable(GL_NORMALIZE);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);
    glClearColor(0.0, 0.0, 0.0, 0.0);	
	// Set up the projection matrix.
	glMatrixMode(GL_PROJECTION);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

  float fRatio=(float)g_w/(float)g_h;
  gluPerspective(80.0f,fRatio,1,150.0f);
	// If everything went well, then return true.
	// Returning false will cause the program to quit right away.
	return true;
}

void Shutdown() // Called right after the window is destroyed.
{
}

void draw_lightning(float x, float y, float z, 
			   float sx, float sy, float sz,
			   int dist,float xyinc, float zinc,
			   float w);
float frand(void);

// Draw all the scene related stuff.
void Render()
{
	static int flash=0;
	static GLfloat x,y,z;
	static GLint lightlist;
	glClear( GL_COLOR_BUFFER_BIT );

	glPushMatrix();
	glEnable(GL_LIGHTING);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glColor4f(2.0,20,3.0,1.0);
	glRotatef(90,0.f,1.0,0.f);
	glRotatef(-90,1.f,0.f,0.f);
//	glRotatef(90,0.f,0.f,1.f);
	if (flash>0) {
		flash--;
		glCallList(lightlist);
		if (!flash) glDeleteLists(lightlist,1);
	}
	if ((!flash && !(rand()%100))) {
		lightlist=glGenLists(1);
		glNewList(lightlist,GL_COMPILE);
		x=0.0+frand()*100+100.0;
		y=0.0+frand()*100-100.0;
		z=100.0;
		draw_lightning(x,y,z,frand()*0.2-0.1,frand()*0.2-0.1,frand()*0.2-0.1,100,3.0+frand()*3.0,2.0,1.0);
		if (!(rand()%4)) {
			x=0.0+frand()*100-100.0;
			y=0.0+frand()*200-100.0;
			z=100.0;
			draw_lightning(x,y,z,frand()*0.2-0.1,frand()*0.2-0.1,frand()*0.2-0.1,100,2.0,2.0,1.0);
		}
		flash=10;
		glEndList();
		glCallList(lightlist);
	}
	glPopMatrix();
}

void draw_lightning(float x, float y, float z, 
			   float sx, float sy, float sz,
			   int dist,float xyinc, float zinc,
			   float w)
{
	while (dist-- > 0) {
		GLfloat bx,by,bz;
		bx=x;bz=z;by=y;
		x=x+(frand()-sx)*xyinc-xyinc*0.5;
		y=y+(frand()-sy)*xyinc-xyinc*0.5;
//		y=y+zinc;
		z=z-zinc;
		glBegin(GL_QUADS);
		glColor4f(2.0,20,3.0,0.0);
		glVertex3f(bx+2*w,by,bz);
		glColor4f(2.0,20,3.0,1.0);
		glVertex3f(bx,by,bz);
		glVertex3f(x,y,z);
		glColor4f(2.0,20,3.0,0.0);
		glVertex3f(x+2*w,y,z);

		glColor4f(2.0,20,3.0,1.0);
		glVertex3f(bx,by,bz);
		glColor4f(2.0,20,3.0,0.0);
		glVertex3f(bx-2*w,by,bz);
		glVertex3f(x-2*w,y,z);
		glColor4f(2.0,20,3.0,1.0);
		glVertex3f(x,y,z);

		glColor4f(2.0,20,3.0,0.0);
		glVertex3f(bx,by+2*w,bz);
		glColor4f(2.0,20,3.0,1.0);
		glVertex3f(bx,by,bz);
		glVertex3f(x,y,z);
		glColor4f(2.0,20,3.0,0.0);
		glVertex3f(x,y+2*w,z);

		glColor4f(2.0,20,3.0,1.0);
		glVertex3f(bx,by,bz);
		glColor4f(2.0,20,3.0,0.0);
		glVertex3f(bx,by-2*w,bz);
		glVertex3f(x,y-2*w,z);
		glColor4f(2.0,20,3.0,1.0);
		glVertex3f(x,y,z);
		glEnd();

		if (!(rand()%20) && dist>5) {
			if (rand()%2) draw_lightning(x,y,z,sx-0.20,sy-0.20,sz-0.10,
				rand()%dist,xyinc,zinc,w*(frand()*0.25+0.25));
			else draw_lightning(x,y,z,sx+0.20,sy+0.20,sz+0.10,
				rand()%dist,xyinc,zinc,w*(frand()*0.25+0.25));
		}
	}
}

float frand(void)
{
	short i=0x7fff;
	float r;
	r=(float)rand()/(float)(i);
	return (r);
}
