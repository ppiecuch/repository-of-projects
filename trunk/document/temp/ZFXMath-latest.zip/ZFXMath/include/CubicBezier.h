/// \file
///
/// \if DE
/// @brief TCubicBezier
///
/// TCubicBezier: n-dimensionale kubische Bezier-Kurve
/// \else
/// @brief TCubicBezier
///
/// TCubicBezier: n-dimensional Cubic Bezier-Curve
/// \endif


#ifndef _ZFXMATH_INCLUDE_CUBICBEZIER_H_
#define _ZFXMATH_INCLUDE_CUBICBEZIER_H_

namespace ZFXMath
{
	/// \if DE
	/// @brief n-dimensionale kubische Bezier-Kurve
	///
	/// \param PrecisionType Genauigkeit der Funktionsauswertung (z.B. float)
	/// \param FuncValueType Typ der Funktion (z.B. TVector3D<float>)
	/// \else
	/// @brief n-dimensional Cubic Bezier-Curve
	///
	/// \param PrecisionType precision of function evaluation (e.g. float)
	/// \param FuncValueType Type of function (e.g. TVector3D<float>)
	/// \endif
	template<class PrecisionType, class FuncValueType>
	class TCubicBezier
	{

	public:

		TCubicBezier() {};

		/// \if DE
		/// @brief Konstruktor mit allen vier Kontrollpunkten
		/// \else
		/// @brief Constructor with all four control points
		/// \endif
		TCubicBezier(	const FuncValueType& cP0,
						const FuncValueType& cP1,
						const FuncValueType& cP2,
						const FuncValueType& cP3 ) { m_ControlPoint[0] = cP0;
													 m_ControlPoint[1] = cP1;
													 m_ControlPoint[2] = cP2;
													 m_ControlPoint[3] = cP3; }

		/// \if DE
		/// @brief Konstruktor mit den zwei End-Kontrollpunkten
		/// 
		/// Erzeugt eine Linie zwischen den beiden Punkten
		/// \else
		/// @brief Constructor with the two end control points
		/// 
		/// Creates a line between the wo points
		/// \endif
		TCubicBezier(	const FuncValueType& cP0,
						const FuncValueType& cP3 ) { m_ControlPoint[0] = cP0;
													 m_ControlPoint[1] = cP0 + ( cP3 - cP0 ) / 3.0;
													 m_ControlPoint[2] = cP0 + ( cP3 - cP0 ) / 1.5;
													 m_ControlPoint[3] = cP3; }


		TCubicBezier( const FuncValueType* pCP ) { memcpy( m_ControlPoint, pCP, sizeof( TCubicBezier ) ); }

		TCubicBezier( const TCubicBezier& cB ) { memcpy( m_ControlPoint, cB.m_ControlPoint, sizeof( TCubicBezier ) ); }

		/// \if DE
		/// @brief Konstanter Zugriff �ber Index
		/// \else
		/// @brief Const accessors by index
		/// \endif
		FuncValueType operator () ( const int i ) const
		{
			return m_ControlPoint[ Check( i ) ];
		}

		/// \if DE
		/// @brief Nichtkonstanter Zugriff �ber Index
		/// \else
		/// @brief Non-const accessors by index
		/// \endif
		FuncValueType& operator () ( const int i )
		{
			return m_ControlPoint[ Check( i ) ];
		}

		/// \if DE
		/// @brief Auswertung der Kurve am �bergebenen Punkt
		/// \else
		/// @brief Evaluation of the curve at the given point
		/// \endif
		FuncValueType operator () ( const PrecisionType& u ) const
		{
			return Evaluate( u );
		}

		/// \if DE
		/// @brief Auswertung der Kurve am �bergebenen Punkt
		/// \else
		/// @brief Evaluation of the curve at the given point
		/// \endif
		FuncValueType operator () ( const PrecisionType& u )
		{
			return Evaluate( u );
		}


		/// \if DE
		/// @brief Auswertung der Kurve am �bergebenen Punkt
		/// \else
		/// @brief Evaluation of the curve at the given point
		/// \endif
		FuncValueType Evaluate( const PrecisionType& u ) const
		{
			PrecisionType invu = 1 - u;
			return (  m_ControlPoint[0] * invu * invu * invu
					+ m_ControlPoint[1] * 3 * u * invu * invu
					+ m_ControlPoint[2] * 3 * u * u * invu
					+ m_ControlPoint[3] * u * u * u );
		}

	private:
		inline int Check( const int index ) const
		{
			// Check bounds in debug build
			assert( index >= 0 && index < 4 );

			return index;
		}

		FuncValueType	m_ControlPoint[4];
	};
}

#endif //_ZFXMATH_INCLUDE_CUBICBEZIER_H_


