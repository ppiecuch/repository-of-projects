/// \file
///
/// @brief TMatrix3x3Stack
///
/// TMatrix3x3Stack: TMultiplyStack<TMatrix3x3>

#ifndef	_ZFXMATH_INCLUDE_MATRIX3X3STACK_H_
#define	_ZFXMATH_INCLUDE_MATRIX3X3STACK_H_

namespace ZFXMath
{
	/// \if DE
	/// @brief TMultiplyStack f�r TMatrix3x3
	/// \else
	/// @brief TMultiplyStack for TMatrix3x3
	/// \endif
	template<class T>
	class TMatrix3x3Stack : public TMultiplyStack< TMatrix3x3<T> >
	{
	};
}

#endif //_ZFXMATH_INCLUDE_MATRIX3X3STACK_H_