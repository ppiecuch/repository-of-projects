/// \file
///
/// \if DE
///
/// @brief f�gt alle Header zusammen
///
/// Erstellt von Florianx am 2004/08/04
/// Letzte �nderung: Version $Revision: 1.1 $ am $Date: 2004/08/24 14:42:29 $ von $Author: Florianx $
///
/// \else
///
/// @brief include all headers
///
/// Created by Florianx at 2004/08/04
/// Last change: Version $Revision: 1.1 $ at $Date: 2004/08/24 14:42:29 $ by $Author: Florianx $
///
/// \endif
///
/// CVS-Log:
/// \n $Log: FilterTest.h,v $
/// \n Revision 1.1  2004/08/24 14:42:29  Florianx
/// \n *** empty log message ***
/// \n

void SillyFunction();