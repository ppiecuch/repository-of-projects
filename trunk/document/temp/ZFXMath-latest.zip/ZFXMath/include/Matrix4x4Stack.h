/// \file
///
/// @brief TMatrix4x4Stack
///
/// TMatrix4x4Stack: TMultiplyStack<TMatrix4x4>

#ifndef	_ZFXMATH_INCLUDE_MATRIX4X4STACK_H_
#define	_ZFXMATH_INCLUDE_MATRIX4X4STACK_H_

namespace ZFXMath
{
	/// \if DE
	/// @brief TMultiplyStack f�r TMatrix4x4
	/// \else
	/// @brief TMultiplyStack for TMatrix4x4
	/// \endif
	template<class T>
	class TMatrix4x4Stack : public TMultiplyStack< TMatrix4x4<T> >
	{
	};
}

#endif //_ZFXMATH_INCLUDE_MATRIX4X4STACK_H_