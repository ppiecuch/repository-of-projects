/// \file
///
/// @brief TMatrixMxN
///
/// TMatrixMxN : M:N Dimensions TMatrixMxN Structure
// ///////////////////////////////////////////////////////////////////////////
// Autor:         Patrick Ullmann
// Erstellt:      05.04.04
// �nderungen:    05.04.04 (Patrick)  Datei erstellt
// ///////////////////////////////////////////////////////////////////////////
// Beschreibung:  Struktur f�r eine Matrix mit frei belegbaren Spalten 
//                und Zeilenanzahl (Inline-File)

#ifndef _ZFXMATH_INCLUDE_MATRIXMXN_H_
#define _ZFXMATH_INCLUDE_MATRIXMXN_H_

// I N C L U D E S ///////////////////////////////////////////////////////////
// Noch keine

// S T R U K T U R E N ///////////////////////////////////////////////////////
namespace ZFXMath
{
	// M = Zeilen
	// N = Spalten
	template <int M, int N, class T> class TMatrixMxN
	{
	public:
		// Konstruktoren
		TMatrixMxN<M, N, T>    (void);
		TMatrixMxN<M, N, T>    (const T& value);
		TMatrixMxN<M, N, T>    (TMatrixMxN<M, N, T> const &other);
		TMatrixMxN<M, N, T>    (const T (&value)[M*N]);

		// Destruktor
		~TMatrixMxN<M, N, T>   (void);

		// Funktionen
		void                zero         (void);
		void                identity     (void);
		TMatrixMxN<N, M, T> transpose    (void) const;
		void                negate       (void);

		// Zuweisungsoperatoren
		TMatrixMxN<M, N, T> const& operator=    (TMatrixMxN<M, N, T> const &other);
		TMatrixMxN<M, N, T> const& operator=    (const T& value);
		TMatrixMxN<M, N, T> const& operator=    (const T (&value)[M*N]);

		// Vergleichsoperatoren
		bool                       operator==   (TMatrixMxN<M, N, T> const &other);
		bool                       operator==   (const T& value);
		bool                       operator==   (const T (&value)[M*N]);

		bool                       operator!=   (TMatrixMxN<M, N, T> const &other);
		bool                       operator!=   (const T& value);
		bool                       operator!=   (const T (&value)[M*N]);

		// Additionsoperatoren
		TMatrixMxN<M, N, T>        operator+    (TMatrixMxN<M, N, T> const &other) const;
		TMatrixMxN<M, N, T>        operator+    (const T& value) const;
		TMatrixMxN<M, N, T>        operator+    (const T (&value)[M*N]) const;

		TMatrixMxN<M, N, T> const& operator+=   (TMatrixMxN<M, N, T> const &other);
		TMatrixMxN<M, N, T> const& operator+=   (const T& value);
		TMatrixMxN<M, N, T> const& operator+=   (const T (&value)[M*N]);

		// Subtraktionsoperatoren
		TMatrixMxN<M, N, T>        operator-    (void) const;
		TMatrixMxN<M, N, T>        operator-    (TMatrixMxN<M, N, T> const &other) const;
		TMatrixMxN<M, N, T>        operator-    (const T& value) const;
		TMatrixMxN<M, N, T>        operator-    (const T (&value)[M*N]) const;

		TMatrixMxN<M, N, T> const& operator-=   (TMatrixMxN<M, N, T> const &other);
		TMatrixMxN<M, N, T> const& operator-=   (const T& value);
		TMatrixMxN<M, N, T> const& operator-=   (const T (&value)[M*N]);

		// Multiplikationsoperatoren
		TMatrixMxN<M, M, T>        operator*    (TMatrixMxN<N, M, T> const &other) const;
		TMatrixMxN<M, N, T>        operator*    (const T& value) const;
		TMatrixMxN<M, M, T>        operator*    (const T (&value)[M*N]) const;

		TMatrixMxN<M, M, T> const& operator*=   (TMatrixMxN<M, N, T> const &other);
		TMatrixMxN<M, N, T> const& operator*=   (const T& value);
		TMatrixMxN<M, M, T> const& operator*=   (const T (&value)[M*N]);

		// Divisionsoperatoren
		/*      TMatrixMxN<M, N, T>        operator/    (void) const;
		TMatrixMxN<M, N, T>        operator/    (TMatrixMxN<M, N, T> const &other) const;
		TMatrixMxN<M, N, T>        operator/    (const T& value) const;
		TMatrixMxN<M, N, T>        operator/    (const T (&value)[M*N]) const;

		TMatrixMxN<M, N, T> const& operator/=   (TMatrixMxN<M, N, T> const &other);
		TMatrixMxN<M, N, T> const& operator/=   (const T& value);
		TMatrixMxN<M, N, T> const& operator/=   (const T (&value)[M*N]);
		*/
	public:
		T    matrix[N][M];
	};
} // namespace ZFXMath


#include "MatrixMxN.inl"

#endif // _ZFXMATH_INCLUDE_MATRIXMXN_H_
