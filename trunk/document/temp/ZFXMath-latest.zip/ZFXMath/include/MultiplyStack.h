/// \file
///
/// @brief TMultiplyStack
///
/// \if DE
/// TMultiplyStack: Stack, bei dem die Elemtente Multipliziert werden k�nnen.
/// \else
/// TMultiplyStack: Stack, where you can multiply the top elements.
/// \endif

#ifndef	_ZFXMATH_INCLUDE_MULTIPLYSTACK_H_
#define	_ZFXMATH_INCLUDE_MULTIPLYSTACK_H_

#include <stack>

namespace ZFXMath
{
	/// \if DE
	/// @brief Stack, bei dem die Elemtente Multipliziert werden k�nnen.
	///
	/// Erweiterung von std::stack um Funktionen,
	/// mit denen das erste Elemten multipliziert werden kann, etc.
	/// z.B. TMatrix4x4Stack
	/// \else
	/// @brief Stack, where you can multiply the top elements.
	///
	/// Extension of std::stack with functions,
	/// which alloc multiplication of the top elements.
	/// for example: TMatrix4x4Stack
	/// \endif
	template<class T>
	class TMultiplyStack : public std::stack<T>
	{
	public:
		/// \if DE
		/// @brief Kopiert das erste Element.
		/// \else
		/// @brief Copy the top element.
		/// \endif
		inline void PushTop()
		{
			if(!empty()) push(top());
		}

		/// \if DE
		/// @brief Kopiert das erste Element und multipliziert es mit 'val'.
		/// \else
		/// @brief Copy the top element and multiply it with 'val'.
		/// \endif
		inline void PushMultiply(const T& val)
		{
			if(!empty()) push(top()*val);
			else push(val);
		}

		/// \if DE
		/// @brief Multipliziert das erste Element mit val.
		/// \else
		/// @brief Multiply the top element with 'val'.
		/// \endif
		inline void Multiply(const T& val)
		{
			if(!empty()) top() *= val;
			else push(val);
		}
	};
}

#endif //_ZFXMATH_INCLUDE_MULTIPLYSTACK_H_