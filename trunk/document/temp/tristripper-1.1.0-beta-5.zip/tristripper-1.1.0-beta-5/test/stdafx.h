// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#ifndef HEADER_GUARD_STDAFX_H
#define HEADER_GUARD_STDAFX_H

#include <cassert>

#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>

#include <GL/glut.h>

#include "base_exception.h"
#include "stdint.h"



#endif // HEADER_GUARD_STDAFX_H
