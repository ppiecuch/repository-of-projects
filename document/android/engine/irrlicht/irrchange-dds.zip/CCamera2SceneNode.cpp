// Copyright (C) 2002-2005 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in irrlicht.h

#include "CCamera2SceneNode.h"
#include "ISceneManager.h"
#include "IVideoDriver.h"

namespace irr
{
namespace scene
{


//! constructor
CCamera2SceneNode::CCamera2SceneNode(ISceneNode* parent, ISceneManager* mgr, s32 id, 
	const core::vector3df& position, const core::vector3df& rotation)
	: ICameraSceneNode(parent, mgr, id, position, rotation,
			core::vector3df(1.0f, 1.0f, 1.0f)), InputReceiverEnabled(true)
{
	#ifdef _DEBUG
	setDebugName("CCamera2SceneNode");
	#endif

	BBox.reset(0,0,0);

	// set default projection

	fovy = core::PI / 2.5f;	// Field of view, in radians. 
	aspect = 4.0f / 3.0f;	// Aspect ratio. 
	zn = 1.0f;				// value of the near view-plane. 
	zf = 3000.0f;			// Z-value of the far view-plane. 

	video::IVideoDriver* d = mgr->getVideoDriver();
	if (d)
	{
		screenDim.Width = (f32)d->getScreenSize().Width;
		screenDim.Height = (f32)d->getScreenSize().Height;
		aspect = screenDim.Height / screenDim.Width;
	}

	recalculateProjectionMatrix();
}



//! destructor
CCamera2SceneNode::~CCamera2SceneNode()
{
}


//! Disables or enables the camera to get key or mouse inputs.
void CCamera2SceneNode::setInputReceiverEnabled(bool enabled)
{
	InputReceiverEnabled = enabled;
}


//! Returns if the input receiver of the camera is currently enabled.
bool CCamera2SceneNode::isInputReceiverEnabled()
{
	_IRR_IMPLEMENT_MANAGED_MARSHALLING_BUGFIX;
	return InputReceiverEnabled;
}


//! Sets the projection matrix of the camera. The core::matrix4 class has some methods
//! to build a projection matrix. e.g: core::matrix4::buildProjectionMatrixPerspectiveFovLH
//! \param projection: The new projection matrix of the camera. 
void CCamera2SceneNode::setProjectionMatrix(const core::matrix4& projection)
{
	Projection = projection;
}



//! Gets the current projection matrix of the camera
//! \return Returns the current projection matrix of the camera.
const core::matrix4& CCamera2SceneNode::getProjectionMatrix()
{
	return Projection;
}



//! Gets the current view matrix of the camera
//! \return Returns the current view matrix of the camera.
const core::matrix4& CCamera2SceneNode::getViewMatrix()
{
	return View;
}



//! It is possible to send mouse and key events to the camera. Most cameras
//! may ignore this input, but camera scene nodes which are created for 
//! example with scene::ISceneManager::addMayaCameraSceneNode or
//! scene::ISceneManager::addMeshViewerCameraSceneNode, may want to get this input
//! for changing their position, look at target or whatever. 
bool CCamera2SceneNode::OnEvent(SEvent event)
{
	return false;
}



//! sets the look at target of the camera
//! \param pos: Look at target of the camera.
void CCamera2SceneNode::setTarget(const core::vector3df& pos)
{
	lookAt(pos, UpVector);
}



//! Gets the current look at target of the camera
//! \return Returns the current look at target of the camera
core::vector3df CCamera2SceneNode::getTarget() const
{
	core::matrix4 mat;
	mat.setRotationDegrees(getRotation());
	return getPosition()+core::vector3df(mat.M[8], mat.M[9], mat.M[10]);
}



//! sets the up vector of the camera
//! \param pos: New upvector of the camera.
void CCamera2SceneNode::setUpVector(const core::vector3df& pos)
{
	lookAt(Target, pos);
}



//! Gets the up vector of the camera.
//! \return Returns the up vector of the camera.
core::vector3df CCamera2SceneNode::getUpVector() const
{
	core::matrix4 mat;
	mat.setRotationDegrees(getRotation());
	return core::vector3df(mat.M[4], mat.M[5], mat.M[6]);
}



void CCamera2SceneNode::lookAt(const core::vector3df& trgt, const core::vector3df& up)
{
	core::matrix4 rot;
	if (Parent) {
		core::array<ISceneNode*> nodes;
		for (ISceneNode* node = Parent; node; node = node->getParent()) 
			nodes.push_front(node);
		for (u32 i=0; i<nodes.size(); i++) {
			nodes[i]->updateAbsolutePosition();
			core::matrix4 tmp;
			tmp.setRotationDegrees(nodes[i]->getRotation());
			rot *= tmp;
		}
	}
	updateAbsolutePosition();
	
	core::vector3df newView = (trgt-getAbsolutePosition()).normalize();
	core::vector3df newRight = up.crossProduct(newView).normalize();
	core::vector3df newUp = newView.crossProduct(newRight);
	core::matrix4 mat(newRight.X, newRight.Y, newRight.Z, 0,
					newUp.X, newUp.Y, newUp.Z, 0,
					newView.X, newView.Y, newView.Z, 0,		0,0,0,1);
	if (Parent) mat = rot.getTransposed() * mat;
	setRotation(mat.getRotationDegrees());
}

f32 CCamera2SceneNode::getNearValue()
{
	return zn;
}

f32 CCamera2SceneNode::getFarValue()
{
	return zf;
}

f32 CCamera2SceneNode::getAspectRatio()
{
	return aspect;
}

f32 CCamera2SceneNode::getFOV()
{
	return fovy;
}

void CCamera2SceneNode::setNearValue(f32 f)
{
	zn = f;
	recalculateProjectionMatrix();
}

void CCamera2SceneNode::setFarValue(f32 f)
{
	zf = f;
	recalculateProjectionMatrix();
}

void CCamera2SceneNode::setAspectRatio(f32 f)
{
	aspect = f;
	recalculateProjectionMatrix();
}

void CCamera2SceneNode::setFOV(f32 f)
{
	fovy = f;
	recalculateProjectionMatrix();
}

void CCamera2SceneNode::recalculateProjectionMatrix()
{
	Projection.buildProjectionMatrixPerspectiveFovLH(fovy, aspect, zn, zf);
}

#include <stdio.h>
//! prerender
void CCamera2SceneNode::OnPreRender()
{
	video::IVideoDriver* driver = SceneManager->getVideoDriver();
	if (!driver)
		return;

	if (SceneManager->getActiveCamera() == this)
	{
		screenDim.Width = (f32)driver->getScreenSize().Width;
		screenDim.Height = (f32)driver->getScreenSize().Height;

		driver->setTransform(video::ETS_PROJECTION, Projection);

		core::matrix4 rot;
		if (Parent) {
			core::array<ISceneNode*> nodes;
			for (ISceneNode* node = this; node; node = node->getParent()) 
				nodes.push_front(node);
			for (u32 i=0; i<nodes.size(); i++) {
				nodes[i]->updateAbsolutePosition();
				core::matrix4 tmp;
				tmp.setRotationDegrees(nodes[i]->getRotation());
				rot *= tmp;
			}
		}

		View.buildCameraLookAtMatrixLH(getAbsolutePosition(), 
			getAbsolutePosition()+core::vector3df(rot.M[8], rot.M[9], rot.M[10]), 
			core::vector3df(rot.M[4], rot.M[5], rot.M[6]));

		recalculateViewArea();

		SceneManager->registerNodeForRendering(this, ESNRP_LIGHT_AND_CAMERA);
	}

	ISceneNode::OnPreRender();
}


//! render
void CCamera2SceneNode::render()
{	
	video::IVideoDriver* driver = SceneManager->getVideoDriver();
	if (!driver)
		return;

	driver->setTransform(video::ETS_VIEW, View);
}


//! returns the axis aligned bounding box of this node
const core::aabbox3d<f32>& CCamera2SceneNode::getBoundingBox() const
{
	return BBox;
}



//! returns the view frustrum. needed sometimes by bsp or lod render nodes.
const SViewFrustrum* CCamera2SceneNode::getViewFrustrum()
{
	return &ViewArea;
}


void CCamera2SceneNode::recalculateViewArea()
{
	core::matrix4 mat = Projection * View;
	ViewArea = SViewFrustrum(mat);

	ViewArea.cameraPosition = getAbsolutePosition();
	ViewArea.recalculateBoundingBox();
}



} // end namespace
} // end namespace

