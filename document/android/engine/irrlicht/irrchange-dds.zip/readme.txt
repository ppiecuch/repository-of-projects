Included binaries are Win32 release builds, D3D and software renderes have been removed

Added functions to create arbitrary and main axes rotation matrices
and constructor to initialize all elements
matrix4.h

Added scene node transformations (rotate/translate)
ISceneNode.h (uses new matrix4.h)

Added lookAt function (combining setTarget and setUpVector) to camera interface
ICameraSceneNode.h

New camera (correct behaviour when attached to other nodes)
CCamera2SceneNode.h (using new ICameraSceneNode.h)
CCamera2SceneNode.cpp

Added addCamera2SceneNode to SceneManager
ISceneManager.h
CSceneManager.h
CSceneManager.cpp

Added new ECOLOR_FORMATs, EIMAGE_TYPE and DataSize, NumMipMaps, DataType to IImage and a new contructor
IImage.h
CImage.h
CImage.cpp

Added loader for DDS files (should support DXT1/3/5 and internal mipmaps) (uses new xImage.x)
CImageLoaderDDS.h
CImageLoaderDDS.cpp

Added DDS loader to list of loaders
CNullDriver.cpp (using CImageLoaderDDS.h)

Added driver as parameter for texture loading and added CompressedTexImage2D extension
COpenGLDriver.h
COpenGLDriver.cpp

Added new and seperate block for dds color format to copy image data
Changed texture building to support compressed textures
COpenGLTexture.h
COpenGLTexture.cpp