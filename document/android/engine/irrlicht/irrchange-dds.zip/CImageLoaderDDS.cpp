// Copyright (C) 2002-2005 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in irrlicht.h

#include "CImageLoaderDDS.h"
#include <string.h>
#include "SColor.h"
#include "CColorConverter.h"
#include "CImage.h"
#include "os.h"

namespace irr
{
namespace video
{


//! constructor
CImageLoaderDDS::CImageLoaderDDS()
: DDSData(0)
{
	#ifdef _DEBUG
	setDebugName("CImageLoaderDDS");
	#endif
}

//! destructor
CImageLoaderDDS::~CImageLoaderDDS()
{
	if (DDSData)delete [] DDSData;
}

//! returns true if the file maybe is able to be loaded by this class
//! based on the file extension (e.g. ".tga")
bool CImageLoaderDDS::isALoadableFileExtension(const c8* fileName)
{
	return strstr(fileName, ".dds") != 0;
}

//! returns true if the file maybe is able to be loaded by this class
bool CImageLoaderDDS::isALoadableFileFormat(irr::io::IReadFile* file)
{
	u32 headerID;
	file->read(&headerID, sizeof(u32));
	return headerID == 0x20534444;
}

//! creates a surface from the file
IImage* CImageLoaderDDS::loadImage(irr::io::IReadFile* file)
{
	ddsHeader header;
	file->read(&header, sizeof(header));

	EIMAGE_TYPE type = EIT_IMAGE_2D;
	if (header.Magic != 0x20534444)	return 0;
	if (header.MipMapCount>1) header.Size<<=1;
	if (header.Caps2) {
		header.Size*=6;
		type=EIT_CUBE_MAP;
	}

	ECOLOR_FORMAT fmt = ECF_BGRA8;
	switch(header.FourCC) {
		case 0x31545844: fmt = ECF_DXT1; break;
		case 0x33545844: fmt = ECF_DXT3; break;
		case 0x35545844: fmt = ECF_DXT5; break;
	}

	IImage* image = new CImage(fmt, core::dimension2d<s32>(header.Width, header.Height), 
				header.Size, header.MipMapCount, type);
	file->read(image->lock(), header.Size);
	image->unlock();
	return image;
}


//! creates a loader which is able to load windows bitmaps
IImageLoader* createImageLoaderDDS()
{
	return new CImageLoaderDDS;
}


} // end namespace video
} // end namespace irr
