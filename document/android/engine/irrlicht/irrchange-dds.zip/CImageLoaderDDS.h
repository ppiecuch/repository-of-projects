#ifndef __C_IMAGE_LOADER_DDS_H_INCLUDED__
#define __C_IMAGE_LOADER_DDS_H_INCLUDED__

#include "IImageLoader.h"


namespace irr
{
namespace video
{

	// byte-align structures
#ifdef _MSC_VER
#	pragma pack( push, packing )
#	pragma pack( 1 )
#	define PACK_STRUCT
#elif defined( __GNUC__ )
#	define PACK_STRUCT	__attribute__((packed))
#else
#	error compiler not supported
#endif

struct ddsHeader{
	unsigned Magic;
	unsigned HeaderSize;
	unsigned DDSFlags;
	unsigned Height;
	unsigned Width;
	unsigned Size;
	unsigned Depth;
	unsigned MipMapCount;
	unsigned Reserved[11];

	unsigned PFSize;
	unsigned PFFlags;
	unsigned FourCC;
	unsigned RGBBitCount;
	unsigned RBitMask;
	unsigned GBitMask;
	unsigned BBitMask;
	unsigned AlphaBitMask;
    
	unsigned Caps1;
	unsigned Caps2;
	unsigned DDSX;
	unsigned Whatever[2];
};


// Default alignment
#ifdef _MSC_VER
#	pragma pack( pop, packing )
#endif

#undef PACK_STRUCT


/*!
	Surface Loader fow Windows bitmaps
*/
class CImageLoaderDDS : public IImageLoader
{
public:

	//! constructor
	CImageLoaderDDS();

	//! destructor
	virtual ~CImageLoaderDDS();

	//! returns true if the file maybe is able to be loaded by this class
	//! based on the file extension (e.g. ".tga")
	virtual bool isALoadableFileExtension(const c8* fileName);

	//! returns true if the file maybe is able to be loaded by this class
	virtual bool isALoadableFileFormat(irr::io::IReadFile* file);

	//! creates a surface from the file
	virtual IImage* loadImage(irr::io::IReadFile* file);

private:
	c8* DDSData;
};


} // end namespace video
} // end namespace irr


#endif

