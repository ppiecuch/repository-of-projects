/*
 Copyright (c) 2009 Ben Hopkins
 
 Permission is hereby granted, free of charge, to any person
 obtaining a copy of this software and associated documentation
 files (the "Software"), to deal in the Software without
 restriction, including without limitation the rights to use,
 copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following
 conditions:
 
 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 OTHER DEALINGS IN THE SOFTWARE.
*/

#include <sys/time.h>
#import "FrameTimeKeeper.h"


@implementation FrameTimeKeeper

#pragma mark Properties

@dynamic fps;
@synthesize tickCount=_tickCount, deltaTime=_deltaTime, time=_timeAccumulator;

/****************************************************************************************************
 *	fps
 ****************************************************************************************************/

- (float) fps
{
	if ( _fpsAccumulator > 0.25)  
	{
		_fps = _fpsTickCount/_fpsAccumulator;
		_fpsTickCount = 0;
		_fpsAccumulator = 0.0f;
	}
	
	return _fps;
}

#pragma mark Public methods

/****************************************************************************************************
 *	init
 ****************************************************************************************************/

- (id) init
{
	if( self = [super init])
	{
		[self reset];
	}
	return self;
}

/****************************************************************************************************
 *	reset
 ****************************************************************************************************/

- (void) reset
{
	_tickCount = 0;
	_deltaTime = 0.0f;
	_timeAccumulator = 0.0f;
	_fps = 0.0f;
	_fpsTickCount = 0;
	_fpsAccumulator = 0.0f;
	
	NSAssert( gettimeofday( &_previousTickTimeVal, NULL) == 0, @"gettimeofday error");
}

/****************************************************************************************************
 *	tick
 ****************************************************************************************************/

- (void) tick
{
	struct timeval now;
	NSAssert( gettimeofday( &now, NULL) == 0, @"gettimeofday error");
	
	_deltaTime = (now.tv_sec - _previousTickTimeVal.tv_sec) + (now.tv_usec - _previousTickTimeVal.tv_usec) / 1000000.0f;
	_deltaTime = MAX( 0, _deltaTime);
	_timeAccumulator += _deltaTime;
	
	_fpsTickCount++;
	_fpsAccumulator += _deltaTime;
	
	_previousTickTimeVal = now;	
	_tickCount++;
}

@end
