/*
 Copyright (c) 2009 Ben Hopkins
 
 Permission is hereby granted, free of charge, to any person
 obtaining a copy of this software and associated documentation
 files (the "Software"), to deal in the Software without
 restriction, including without limitation the rights to use,
 copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following
 conditions:
 
 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 OTHER DEALINGS IN THE SOFTWARE.
*/

#import <QuartzCore/QuartzCore.h>
#import <OpenGLES/EAGLDrawable.h>

#import "KEEAGLView.h"

#define USE_DEPTH_BUFFER 1

// A class extension to declare private methods
@interface KEEAGLView ()

@property (nonatomic, retain) EAGLContext *context;
@property (nonatomic, assign) NSTimer *animationTimer;

- (BOOL) createFramebuffer;
- (void) destroyFramebuffer;

@end


@implementation KEEAGLView

#pragma mark Properties

@synthesize context=_context;
@synthesize animationTimer=_animationTimer;
@synthesize animationInterval=_animationInterval;

/****************************************************************************************************
 *	layerClass
 ****************************************************************************************************/

+ (Class)layerClass 
{
    return [CAEAGLLayer class];
}

/****************************************************************************************************
 *	setAnimationTimer:
 ****************************************************************************************************/

- (void)setAnimationTimer:(NSTimer *)newTimer 
{
    [_animationTimer invalidate];
    _animationTimer = newTimer;
}

/****************************************************************************************************
 *	setAnimationInterval:
 ****************************************************************************************************/

- (void)setAnimationInterval:(NSTimeInterval)interval 
{
    _animationInterval = interval;
    if (_animationTimer) 
	{
        [self stopAnimation];
        [self startAnimation];
    }
}

#pragma mark Public methods

/****************************************************************************************************
 *	initWithFrame:useDepthBuffer:
 ****************************************************************************************************/

- (id) initWithFrame:(CGRect)frame useDepthBuffer:(BOOL)useDepthBuffer
{
	if( self = [super initWithFrame:frame])
	{
		_useDepthBuffer = useDepthBuffer;
		
        CAEAGLLayer *eaglLayer = (CAEAGLLayer *)self.layer;
        
        eaglLayer.opaque = YES;
        eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO], kEAGLDrawablePropertyRetainedBacking, 
																				  kEAGLColorFormatRGBA8, kEAGLDrawablePropertyColorFormat, nil];
        
        _context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
        
		NSLog(@"before context check");
        if (!_context || ![EAGLContext setCurrentContext:_context]) 
		{
			NSLog(@"context fail");
            [self release];
            return nil;
        }
        
		if( _useDepthBuffer)
			glEnable( GL_DEPTH_TEST);

        _animationInterval = 1.0 / 60.0;
	}
	return self;
}

/****************************************************************************************************
 *	drawView
 ****************************************************************************************************/

- (void)drawView 
{    
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, _viewRenderbuffer);
    [_context presentRenderbuffer:GL_RENDERBUFFER_OES];
}

/****************************************************************************************************
 *	layoutSubviews
 ****************************************************************************************************/

- (void)layoutSubviews 
{
    [EAGLContext setCurrentContext:_context];
    [self destroyFramebuffer];
    [self createFramebuffer];
    [self drawView];
}

/****************************************************************************************************
 *	setupGLPerspectiveNear:far:
 ****************************************************************************************************/

- (void) setupGLPerspectiveNear:(float)near far:(float)far
{
	float size = near * tanf(DEGREES_TO_RADIANS(60) / 2.0);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustumf( -size, size, 
			   -size / (self.bounds.size.width / self.bounds.size.height), size / (self.bounds.size.width / self.bounds.size.height), 
			   near, far);
	glViewport(0, 0, self.bounds.size.width, self.bounds.size.height);
}

/****************************************************************************************************
 *	createFramebuffer
 ****************************************************************************************************/

- (BOOL)createFramebuffer
{
    glGenFramebuffersOES(1, &_viewFramebuffer);
    glGenRenderbuffersOES(1, &_viewRenderbuffer);
    
    glBindFramebufferOES(GL_FRAMEBUFFER_OES, _viewFramebuffer);
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, _viewRenderbuffer);
    [_context renderbufferStorage:GL_RENDERBUFFER_OES fromDrawable:(CAEAGLLayer*)self.layer];
    glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER_OES, _viewRenderbuffer);
    
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES, &_backingWidth);
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &_backingHeight);
    
    if (_useDepthBuffer) 
	{
        glGenRenderbuffersOES(1, &_depthRenderbuffer);
        glBindRenderbufferOES(GL_RENDERBUFFER_OES, _depthRenderbuffer);
        glRenderbufferStorageOES(GL_RENDERBUFFER_OES, GL_DEPTH_COMPONENT16_OES, _backingWidth, _backingHeight);
        glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_DEPTH_ATTACHMENT_OES, GL_RENDERBUFFER_OES, _depthRenderbuffer);
    }
    
    if(glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) != GL_FRAMEBUFFER_COMPLETE_OES) 
	{
        NSLog(@"failed to make complete framebuffer object %x", glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES));
        return NO;
    }
    
    return YES;
}

/****************************************************************************************************
 *	destroyFramebuffer
 ****************************************************************************************************/

- (void)destroyFramebuffer {
    
    glDeleteFramebuffersOES(1, &_viewFramebuffer);
    _viewFramebuffer = 0;
    glDeleteRenderbuffersOES(1, &_viewRenderbuffer);
    _viewRenderbuffer = 0;
    
    if(_depthRenderbuffer) 
	{
        glDeleteRenderbuffersOES(1, &_depthRenderbuffer);
        _depthRenderbuffer = 0;
    }
}

/****************************************************************************************************
 *	startAnimation
 ****************************************************************************************************/

- (void)startAnimation 
{
    self.animationTimer = [NSTimer scheduledTimerWithTimeInterval:_animationInterval target:self selector:@selector(drawView) userInfo:nil repeats:YES];
}

/****************************************************************************************************
 *	stopAnimation
 ****************************************************************************************************/

- (void)stopAnimation 
{
    self.animationTimer = nil;
}

/****************************************************************************************************
 *	dealloc
 ****************************************************************************************************/

- (void)dealloc 
{
	NSLog(@"eagl dealloc");
	
	[self stopAnimation];
	[EAGLContext setCurrentContext:_context];
    [self destroyFramebuffer];
    [EAGLContext setCurrentContext:nil];
    
    [_context release];  
    [super dealloc];
	NSLog(@"EAGL dealloc end");
}

@end
