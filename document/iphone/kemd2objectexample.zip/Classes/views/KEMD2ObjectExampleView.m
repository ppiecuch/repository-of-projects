/*
 Copyright (c) 2009 Ben Hopkins
 
 Permission is hereby granted, free of charge, to any person
 obtaining a copy of this software and associated documentation
 files (the "Software"), to deal in the Software without
 restriction, including without limitation the rights to use,
 copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following
 conditions:
 
 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 OTHER DEALINGS IN THE SOFTWARE.
*/

#import "Types3D.h"
#import "Texture2D.h"
#import "KEEAGLView.h"
#import "KEGLRenderable.h"
#import "KEMD2Object.h"
#import "FrameTimeKeeper.h"
#import "KEMD2ObjectExampleView.h"

@interface KEMD2ObjectExampleView ()

@property (nonatomic, readwrite, retain) KEMD2Object *stage;
@property (nonatomic, readwrite, retain) KEMD2Object *character;
@property (nonatomic, readwrite, retain) FrameTimeKeeper *timeKeeper;

@end



@implementation KEMD2ObjectExampleView

@synthesize stage=_stage, character=_character, timeKeeper=_timeKeeper;

/****************************************************************************************************
 *	initWithFrame:useDepthBuffer:
 ****************************************************************************************************/

- (id) initWithFrame:(CGRect)frame useDepthBuffer:(BOOL)useDepthBuffer
{
	if( self = [super initWithFrame:frame useDepthBuffer:useDepthBuffer])
	{
		_characterX = 0;
		_characterTargetX = 0;
		_characterRotationY = 90;
		_cameraZ = 0;
		_cameraTargetZ = 0;
		_controlX = 0;
		
		Texture2D *stageTexture = [[[Texture2D alloc] initWithImage:[UIImage imageNamed:@"Stage1a_Grid.jpg"]] autorelease];
		self.stage = [KEMD2Object md2WithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Stage1a" ofType:@"md2"] texture:stageTexture];
		
		Texture2D *characterTexture = [[[Texture2D alloc] initWithImage:[UIImage imageNamed:@"megaman.jpg"]] autorelease];
		self.character = [KEMD2Object md2WithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"megaman" ofType:@"md2"] texture:characterTexture];
		
		self.timeKeeper = [[FrameTimeKeeper new] autorelease];
		[self setupGLPerspectiveNear:0.1 far:1000];
	}
	return self;
}

/****************************************************************************************************
 *	dealloc
 ****************************************************************************************************/

- (void) dealloc
{
	self.timeKeeper = nil;
	self.character = nil;
	self.stage = nil;
	[super dealloc];
}

/****************************************************************************************************
 *	drawView
 ****************************************************************************************************/

- (void) drawView
{
	static GLfloat lightPosition[4] = { 200.0, 0.0, 11};
	static GLfloat lightDefuse[4] = { 1.0, 1, 1, 1.0};
	static GLfloat lightAmbient[4] = { 0, 0, 0, 1.0};
	
	[self.timeKeeper tick];
	
	_cameraTargetZ = -10.0 - fabs(_characterX * 2.13);
	_cameraZ += (_cameraTargetZ - _cameraZ) * 0.1;
	
	_characterTargetX += _controlX * self.timeKeeper.deltaTime * 20;
	_characterX += (_characterTargetX - _characterX) * 0.6;
	
	glClearColor( 0, 0.0, 0.12, 1);
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	// Setup Camera
	glMatrixMode( GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef( 0, -8, _cameraZ);
	glRotatef( -90.0, 1.0, 0.0, 0.0 );
	glRotatef( -90.0, 0.0, 0.0, 1.0 );
	
	// Draw Stage
	glPushMatrix();
	glScalef( 2, 2, 2);
	[self.stage setupForRenderGL];
	[self.stage renderGL];
	[self.stage cleanupAfterRenderGL];
	glPopMatrix();
	
	// Draw Character
	glEnable( GL_LIGHTING);
	glEnable( GL_LIGHT0);
	glLightfv( GL_LIGHT0, GL_DIFFUSE, lightDefuse);
	glLightfv( GL_LIGHT0, GL_AMBIENT, lightAmbient);
	glLightf( GL_LIGHT0, GL_SPOT_EXPONENT, 68);
	glLightfv( GL_LIGHT0, GL_POSITION, lightPosition);
	
	glTranslatef( -8, _characterX, 2.5);
	glRotatef( _characterRotationY, 0, 0, 1);
	glScalef( 0.119, 0.119, 0.119);
	[self.character doTick:self.timeKeeper.time];
	[self.character setupForRenderGL];
	[self.character renderGL];	
	[self.character cleanupAfterRenderGL];
	
	glDisable( GL_LIGHT0);
	glDisable( GL_LIGHTING);
	
	[super drawView];
}

#pragma mark Touch methods

/****************************************************************************************************
 *	touchesBegan:withEvent:
 ****************************************************************************************************/

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch *touch = [[event allTouches] anyObject];
	CGPoint p = [touch locationInView:self];
	
	_controlX = (p.x / 160.0) - 1;
	_characterRotationY = _controlX > 0 ? 90 : -90;
	
	self.character.animation = KEMD2AnimationRun;
	self.character.fpsScale = fabs( _controlX);
}

/****************************************************************************************************
 *	touchesEnded:withEvent:
 ****************************************************************************************************/

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	self.character.animation = KEMD2AnimationStand;
	_controlX = 0;
}

/****************************************************************************************************
 *	touchesMoved:withEvent:
 ****************************************************************************************************/

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch *touch = [[event allTouches] anyObject];
	CGPoint p = [touch locationInView:self];
	
	_controlX = (p.x / 160.0) - 1;
	_characterRotationY = _controlX > 0 ? 90 : -90;
	
	self.character.fpsScale = fabs( _controlX);
}

@end
