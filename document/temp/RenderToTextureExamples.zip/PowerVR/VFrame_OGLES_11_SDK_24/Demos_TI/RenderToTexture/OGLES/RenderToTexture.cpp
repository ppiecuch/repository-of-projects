/******************************************************************************

  File          RenderToTexture.cpp

  Title         Render to Texture Example for OpenGL ES 1.1

  Author        Clay D. Montgomery

  Copyright     Copyright (C) 2000 - 2008 by Texas Instruments, Inc.

  Platform      PowerVR VFrame emulator or the OMAP35x EVM

  Description   Demonstrates a render to texture technique using the FBO extension.

******************************************************************************/

#include <math.h>
#include <string.h>
#include "PVRShell.h"
#include "OGLESTools.h"

// Camera constants used for the projection matrix
const float gfCameraNear = 1.0f;
const float gfCameraFar  = 100.0f;

const unsigned int gTextureSize = 1024;

// Class that implements the required PVRShell functions

class RenderToTexture : public PVRShell
{
    CPVRTPrint3D    m_Print3D;          // Class used to display text
    CPVRTglesExt    m_Extensions;       // Pointer to extension functions
    
    PVRTMat4        m_mProjection;      // Projection matrix
    PVRTMat4        m_mView;            // Model View matrix
    
    GLuint          m_hTexture[2];      // Texture handles
    GLuint          m_hFBO[2];          // Handles for Frame Buffer Objects

    bool            m_bModeFlag;        // Indicates rendering mode

    GLfloat         m_fCubeSize;        // Size of the cube
    GLfloat         m_fAngleX;          // Rotation angle about x axis in degrees
    GLfloat         m_fAngleY;          // Rotation angle about y axis in degrees

    unsigned int    m_Time;
    unsigned int    m_FrameCount;
    unsigned int    m_FramesPerSecond;
    unsigned int    m_CurrentFBO;

    void            DrawCubeSmooth(void);
    void            Unpack(unsigned long, char *, unsigned int);
    bool            RenderTexture();
    bool            DrawTextureBox();
    bool            ExtensionSupported(const char *extension);

public:
    virtual bool    InitApplication();
    virtual bool    InitView();
    virtual bool    ReleaseView();
    virtual bool    QuitApplication();
    virtual bool    RenderScene();
};

/******************************************************************************

  Function      NewDemo

  Return        PVRShell *      Pointer to this PVRShell application

  Description   PVRShell calls this function to instantiate this application
                class and get a pointer to it.

******************************************************************************/

PVRShell * NewDemo()
{
    return new RenderToTexture();
}

/******************************************************************************

  Function      InitApplication

  Return        bool            False indicates a returned error.

  Description   Called once by PVRShell before the rendering context is created.
                Performs general program initialization.

******************************************************************************/

bool RenderToTexture::InitApplication()
{
//  Causes segmentation fault on PowerVR ???
//
//  // Check that the FBO extension is available.
//  if (!ExtensionSupported("GL_OES_framebuffer_object"))
//  {
//      PVRShellSet(prefExitMessage, "ERROR: GL_OES_framebuffer_object is not available\n");
//      return false;
//  }

    // Initialize the shading type
    m_bModeFlag = true;

    // Initialize the cube size
    m_fCubeSize = 1.0f;

    // Initialize the rotation angle
    m_fAngleX = 0.0f;
    m_fAngleY = 0.0f;

    // Initialize FBO index
    m_CurrentFBO = 1;

    return true;
}

/******************************************************************************

  Function      QuitApplication

  Return        bool            False indicates a returned error.

  Description   Called by PVRShell before exiting the program.  Used to close
                the program.

******************************************************************************/
bool RenderToTexture::QuitApplication()
{
    return true;
}

/******************************************************************************

  Function      InitView

  Return        bool            False indicates a returned error.

  Description   Called by PVRShell upon initialization and after any change in
                the rendering context.  Used to initialize variables that are
                dependent on the rendering context.

******************************************************************************/
bool RenderToTexture::InitView()
{
    // Display list of available OpenGL ES 1.1 extensions.
    char * pExtensions = (char *)glGetString(GL_EXTENSIONS);
    PVRShellOutputDebug("Extensions: ");
    PVRShellOutputDebug(pExtensions);
    PVRShellOutputDebug("\n");

    // Initialize the extension interface to use FBO functions
    m_Extensions.LoadExtensions();

    // Calculate the projection matrix
    bool bRotate = PVRShellGet(prefIsRotated) && PVRShellGet(prefFullScreen);
    m_mProjection = PVRTMat4::PerspectiveFovRH(1.0f, (float)PVRShellGet(prefWidth)/(float)PVRShellGet(prefHeight), gfCameraNear, gfCameraFar, PVRTMat4::OGL, bRotate);

    // Initialize Print3D for text display
    if (m_Print3D.SetTextures(0,PVRShellGet(prefWidth),PVRShellGet(prefHeight), bRotate) != PVR_SUCCESS)
    {
        PVRShellSet(prefExitMessage, "ERROR: Cannot initialize Print3D\n");
        return false;
    }

    // Set material properties
    GLfloat fObjectMatAmb[]  = { 0.1f, 0.1f, 0.1f, 1.0f };
    GLfloat fObjectMatDiff[] = { 0.5f, 0.5f, 0.5f, 1.0f };
    GLfloat fObjectMatSpec[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, fObjectMatDiff);
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, fObjectMatAmb);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, fObjectMatSpec);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 5);

    // Set light properties
    GLfloat fLightAmb[]  = { 0.1f, 0.1f, 0.1f, 1.0f };
    GLfloat fLightDif[]  = { 1.0f, 1.0f, 1.0f, 1.0f };
    GLfloat fLightSpec[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    GLfloat fAmbient[]   = { 1.0f, 1.0f, 1.0f, 1.0f };
    glLightfv(GL_LIGHT0, GL_AMBIENT, fLightAmb);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, fLightDif);
    glLightfv(GL_LIGHT0, GL_SPECULAR, fLightSpec);
    glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, 5.0f);
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, fAmbient);

    // Calculate the model-view matrix
    PVRTMatrixTranslation(m_mView, 0, 0, -4.0);

    GLfloat fLightPos[] = {10.0f, 10.0f, 10.0f, 0};
    glLightfv(GL_LIGHT0, GL_POSITION, fLightPos);

    // Generate handles for two dynamically rendered texture maps
    glGenTextures(2, m_hTexture);

    for (int Index = 0; Index < 2; Index++)
    {
        // Bind and configure each texture
        glBindTexture(GL_TEXTURE_2D, m_hTexture[Index]);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, gTextureSize, gTextureSize, 0, GL_RGB, GL_UNSIGNED_BYTE, 0);

        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }

    // Generate handles for two Frame Buffer Objects
    m_Extensions.glGenFramebuffersOES(2, m_hFBO);

    for (int Index = 0; Index < 2; Index++)
    {
        // Attach each texture to the first color buffer of an FBO and clear it
        m_Extensions.glBindFramebufferOES(GL_FRAMEBUFFER_OES, m_hFBO[Index]);
        m_Extensions.glFramebufferTexture2DOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_TEXTURE_2D, m_hTexture[Index], 0);
        glClear(GL_COLOR_BUFFER_BIT);
    }

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_NORMALIZE);
    glShadeModel(GL_SMOOTH);

    // Initialize the start time and frame counter.
    m_Time = PVRShellGetTime();
    m_FramesPerSecond = 0;
    m_FrameCount = 0;

    return true;
}

/******************************************************************************

  Function      ReleaseView

  Return        bool            False indicates a returned error.

  Description   Called by PVRShell when the application quits or before any
                change is made in the rendering context.

******************************************************************************/

bool RenderToTexture::ReleaseView()
{
    // Release Print3D Textures
    m_Print3D.ReleaseTextures();

    // Delete the textures
    glDeleteTextures(2, m_hTexture);

    // Delete the FBOs
    m_Extensions.glDeleteFramebuffersOES(2, m_hFBO);

    return true;
}

/******************************************************************************

  Function      RenderScene

  Return        bool            False indicates a returned error.

  Description   The main rendering loop of this program.  PVRShell calls this
                function to render each new frame, then it calls eglSwapBuffers()
                to display each new frame.  PVRShell also abstracts and manages
                important OS events, such as keyboard input.

******************************************************************************/
bool RenderToTexture::RenderScene()
{
    char         StringBuffer[16];
    char *       pString;
    unsigned int Time;

    // Process keyboard input to select flat/smooth shading and adjust cube size
    if (PVRShellIsKeyPressed(PVRShellKeyNameLEFT))
        m_bModeFlag = true;
    else if (PVRShellIsKeyPressed(PVRShellKeyNameRIGHT))
        m_bModeFlag = false;
    else if (PVRShellIsKeyPressed(PVRShellKeyNameUP))
        m_fCubeSize += 0.1f;
    else if (PVRShellIsKeyPressed(PVRShellKeyNameDOWN))
        m_fCubeSize -= 0.1f;

    // Limit the size of the cube
    if (m_fCubeSize < 0.1f)
        m_fCubeSize = 0.1f;
    else if (m_fCubeSize > 2.0f)
        m_fCubeSize = 2.0f;

    // Check the time
    Time = PVRShellGetTime();

    if (Time - m_Time > 1000)   // Has a one second interval passed?
    {
        m_Time = Time;
        m_FramesPerSecond = m_FrameCount;
        m_FrameCount = 0;
    }
    RenderTexture();            // Update the texture map image

    // Bind updated texture map
    glBindTexture(GL_TEXTURE_2D, m_hTexture[m_CurrentFBO]);
    m_CurrentFBO ^= 1;  // Update the FBO index

    if (m_bModeFlag)    // Draw the rendered texture map onto another cube
    {
        glViewport(0, 0, PVRShellGet(prefWidth), PVRShellGet(prefHeight));
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Reload the projection matrix
        glMatrixMode(GL_PROJECTION);
        glLoadMatrixf(m_mProjection.f);

        // Reload the model-view matrix
        glMatrixMode(GL_MODELVIEW);
        glLoadMatrixf(m_mView.f);

        glEnable(GL_CULL_FACE);
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_TEXTURE_2D);

        glColor4f(0.2f, 0.2f, 0.0f, 1.0f);

        glPushMatrix();

        // Rotate the cube model
        glRotatef(m_fAngleX, 1.0f, 0.0f, 0.0f);
        glRotatef(m_fAngleY, 0.0f, 1.0f, 0.0f);

        // Scale the size of the cube model
        glScalef(m_fCubeSize, m_fCubeSize, m_fCubeSize);

        DrawCubeSmooth();

        glPopMatrix();
    }
    else  // Draw the rendered texture map onto a triangle pair.
    {
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glColor4f(0.2f, 0.2f, 0.0f, 1.0f);

        DrawTextureBox();
    }
    // Rotate the cube model for the next frame
    m_fAngleX += 0.25f;
    m_fAngleY += 1.00f;
    m_FrameCount++;

    // Unpack and display the current FPS count along with program title.
    pString = &StringBuffer[0];
    Unpack(m_FramesPerSecond, pString, 6);
    strcpy(pString + strlen(pString), " FPS");

    m_Print3D.DisplayDefaultTitle("Render to Texture via FBO OES", StringBuffer, 0);
    m_Print3D.Flush();

    return true;
}

/******************************************************************************

  Function      RenderTexture

  Return        bool    True if no error occured.

  Description   Render the cube model to a FBO to be used as a texture.

******************************************************************************/
bool RenderToTexture::RenderTexture()
{
    PVRTMat4 mProjection;

    // Switch the render target to the current FBO to update the texture map
    m_Extensions.glBindFramebufferOES(GL_FRAMEBUFFER_OES, m_hFBO[m_CurrentFBO]);

    // FBO attachment is complete?
    if (m_Extensions.glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) == GL_FRAMEBUFFER_COMPLETE_OES)
    {
        // Set viewport to size of texture map and erase previous image
        glViewport(0, 0, gTextureSize, gTextureSize);
        glClearColor(0.8f, 0.8f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        mProjection = PVRTMat4::PerspectiveFovRH(1.0f, 1.0f, gfCameraNear, gfCameraFar, PVRTMat4::OGL, false);
  
        glMatrixMode(GL_PROJECTION);
        glLoadMatrixf(mProjection.f);
 
        // Reload the model-view matrix
        glMatrixMode(GL_MODELVIEW);
        glLoadMatrixf(m_mView.f);

        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_TEXTURE_2D);

        glPushMatrix();

        // Rotate the cube model
        glRotatef(m_fAngleX, 1.0f, 0.0f, 0.0f);
        glRotatef(m_fAngleY, 0.0f, 1.0f, 0.0f);

        // Bind the opposite texture to prevent writing to the same texture
        glBindTexture(GL_TEXTURE_2D, m_hTexture[m_CurrentFBO ^ 1]);

        DrawCubeSmooth();  // Draw the cube model

        glPopMatrix();
    }

    // Unbind the FBO so rendering will return to the backbuffer.
    m_Extensions.glBindFramebufferOES(GL_FRAMEBUFFER_OES, 0);

    return true;
}

/******************************************************************************

  Function      DrawTextureBox

  Return        bool    True if no error occured.

  Description   Display the rendered texture by mapping it to a triangle pair.

******************************************************************************/
bool RenderToTexture::DrawTextureBox()
{
    glDisable(GL_LIGHTING);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
  
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glTranslatef(-1.0f, -1.0f, 0.5f);
    glScalef(2.0f, 2.0f, 1.0f);

    static VERTTYPE Vertices[] =
    {
        0.0f, 1.0f, 0.0f,
        0.0f, 0.0f, 0.0f,
        1.0f, 0.0f, 0.0f,
        1.0f, 1.0f, 0.0f
    };
    static VERTTYPE TexCoords[] =
    {
        0.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f
    };

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glVertexPointer(3, VERTTYPEENUM, 0, (VERTTYPE *)&Vertices);
    glTexCoordPointer(2, VERTTYPEENUM, 0, (VERTTYPE *)&TexCoords);
  
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
  
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);

    return true;
}

/******************************************************************************

  Function      DrawCubeSmooth

  Return        None

  Description   Draw a cube using Vertex and NormalsPerVertex Arrays and
                glDrawArrays with two triangle strips.  Because normals are
                supplied per vertex, all the triangles will be smooth shaded.
                Triangle strips are used instead of an index array.  Both of
                the strips are texture mapped.

******************************************************************************/

void RenderToTexture::DrawCubeSmooth(void)
{
    static GLfloat Vertices[16][3] =
    {   // x     y     z
        {-1.0, -1.0,  1.0}, // 1  left    First Strip
        {-1.0,  1.0,  1.0}, // 3
        {-1.0, -1.0, -1.0}, // 0
        {-1.0,  1.0, -1.0}, // 2
        { 1.0, -1.0, -1.0}, // 4  back
        { 1.0,  1.0, -1.0}, // 6
        { 1.0, -1.0,  1.0}, // 5  right
        { 1.0,  1.0,  1.0}, // 7
        { 1.0,  1.0, -1.0}, // 6  top     Second Strip
        {-1.0,  1.0, -1.0}, // 2
        { 1.0,  1.0,  1.0}, // 7
        {-1.0,  1.0,  1.0}, // 3
        { 1.0, -1.0,  1.0}, // 5  front
        {-1.0, -1.0,  1.0}, // 1
        { 1.0, -1.0, -1.0}, // 4  bottom
        {-1.0, -1.0, -1.0}  // 0
    };
    static GLfloat NormalsPerVertex[16][3] =    // One normal per vertex.
    {   // x     y     z
        {-0.5, -0.5,  0.5}, // 1  left          First Strip
        {-0.5,  0.5,  0.5}, // 3
        {-0.5, -0.5, -0.5}, // 0
        {-0.5,  0.5, -0.5}, // 2
        { 0.5, -0.5, -0.5}, // 4  back
        { 0.5,  0.5, -0.5}, // 6
        { 0.5, -0.5,  0.5}, // 5  right
        { 0.5,  0.5,  0.5}, // 7
        { 0.5,  0.5, -0.5}, // 6  top           Second Strip
        {-0.5,  0.5, -0.5}, // 2
        { 0.5,  0.5,  0.5}, // 7
        {-0.5,  0.5,  0.5}, // 3
        { 0.5, -0.5,  0.5}, // 5  front
        {-0.5, -0.5,  0.5}, // 1
        { 0.5, -0.5, -0.5}, // 4  bottom
        {-0.5, -0.5, -0.5}  // 0
    };
    static GLfloat TexCoords[16][2] =
    {   // x   y
        {0.0, 1.0}, // 1  left                  First strip
        {1.0, 1.0}, // 3
        {0.0, 0.0}, // 0
        {1.0, 0.0}, // 2
        {0.0, 1.0}, // 4  back
        {1.0, 1.0}, // 6
        {0.0, 0.0}, // 5  right
        {1.0, 0.0}, // 7
        {0.0, 1.0}, // 1  left                  Second strip
        {1.0, 1.0}, // 3
        {0.0, 0.0}, // 0
        {1.0, 0.0}, // 2
        {0.0, 1.0}, // 4  back
        {1.0, 1.0}, // 6
        {0.0, 0.0}, // 5  right
        {1.0, 0.0}  // 7
    };

    // Enable 3 types of data

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    // Set pointers to the arrays

    glVertexPointer(3, GL_FLOAT, 0, Vertices);
    glNormalPointer(GL_FLOAT, 0, NormalsPerVertex);
    glTexCoordPointer(2, GL_FLOAT, 0, TexCoords);

    // Draw two triangle strips with texture map

    glDrawArrays(GL_TRIANGLE_STRIP, 0, 8);
    glDrawArrays(GL_TRIANGLE_STRIP, 8, 8);

    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
}

/******************************************************************************

  Function      Unpack

  Return        None

  Description   Convert an unsigned integer value to a decimal character string.
                Any leading zeros are removed from the string.

******************************************************************************/
void RenderToTexture::Unpack
(
    unsigned long Number,       // Positive integer value to unpack.
    char *        pChar,        // Pointer to store output string.
    unsigned int  DigitCount    // Count of digits to unpack.
)
{
    unsigned long Result;
    char * pStart = pChar;
    unsigned int Count = DigitCount;

    pChar += DigitCount;
    *pChar-- = '\0';

    while (DigitCount-- > 0)
    {
        Result = Number / 10;
        *pChar-- = (char)(Number - (Result * 10) + '0');
        Number = Result;
    }
    while ((*++pChar == '0') && --Count);

    strcpy(pStart, pChar);
}
 

bool RenderToTexture::ExtensionSupported(const char *extension)
{
    const GLubyte *extensions = NULL;
    const GLubyte *start;
    GLubyte *where, *terminator;

    /* Extension names should not have spaces. */
    where = (GLubyte *) strchr(extension, ' ');
    if (where || *extension == '\0')
        return 0;

    extensions = glGetString(GL_EXTENSIONS);

    /* It takes a bit of care to be fool-proof about parsing the
    OpenGL extensions string. Don't be fooled by sub-strings, etc. */
    start = extensions;
    for (;;) {
        where = (GLubyte *) strstr((const char *) start, extension);

        if (!where)
            break;

        terminator = where + strlen(extension);

        if (where == start || *(where - 1) == ' ')
        {
            if (*terminator == ' ' || *terminator == '\0')
                return true;
        }
        start = terminator;
    }
    return false;
}

 