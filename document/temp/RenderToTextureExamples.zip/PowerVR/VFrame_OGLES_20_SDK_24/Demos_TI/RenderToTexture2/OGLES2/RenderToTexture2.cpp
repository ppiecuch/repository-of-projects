/******************************************************************************

  File          RenderToTexture2.cpp

  Title         Render to Texture Example for OpenGL ES 2.0

  Author        Clay D. Montgomery

  Copyright     Copyright (C) 2000 - 2008 by Texas Instruments, Inc.

  Platform      PowerVR VFrame emulator or the OMAP35x EVM

  Description   Demonstrates a render to texture technique using Frame Buffer Objects

******************************************************************************/

#include <math.h>
#include <string.h>

#include "PVRShell.h"
#include "OGLES2Tools.h"

// Index to bind the attributes to vertex shaders
const int VERTEX_ARRAY = 0;
const int NORMAL_ARRAY = 1;
const int TEXCOORD_ARRAY = 2;

// Camera constants used for the projection matrix
const float gfCameraNear = 1.0f;
const float gfCameraFar  = 100.0f;

const unsigned int gTextureSize = 1024;

// Class that implements the required PVRShell functions

class RenderToTexture2 : public PVRShell
{
    CPVRTPrint3D m_Print3D;      // Class used to display text
    
    PVRTMat4     m_mViewProj;    // Model view projection matrix
    
    GLuint       m_hVertShader;  // Vertex shader handle
    GLuint       m_hFragShader;  // Fragment shader handle
    GLuint       m_hTexture[2];  // Texture handles
    GLuint       m_hFBO[2];      // Handles for Frame Buffer Objects

    GLfloat      m_fCubeSize;    // Size of the cube
    GLfloat      m_fAngleX;      // Rotation angle about x axis in degrees
    GLfloat      m_fAngleY;      // Rotation angle about y axis in degrees
    GLfloat      m_fLightIntensity; // Scale factor for light intensity

    unsigned int m_Time;
    unsigned int m_FrameCount;
    unsigned int m_FramesPerSecond;
    unsigned int m_CurrentFBO;

    // Shader programs and their uniform locations
    struct 
    {
        GLuint uiId;
        GLuint uiMVPMatrixLocation;
        GLuint uiLightDirLocation;
        GLuint uiLightIntensityLocation;
    }
    m_ShaderProgram;

    void        DrawCubeSmooth(void);
    void        Unpack(unsigned long, char *, unsigned int);
    bool        RenderTexture();

public:
    virtual bool InitApplication();
    virtual bool InitView();
    virtual bool ReleaseView();
    virtual bool QuitApplication();
    virtual bool RenderScene();
};

/******************************************************************************

  Function      NewDemo

  Return        PVRShell *      Pointer to this PVRShell application

  Description   PVRShell calls this function to instantiate this application
                class and get a pointer to it.

******************************************************************************/

PVRShell * NewDemo()
{
    return new RenderToTexture2();
}

/******************************************************************************

  Function      InitApplication

  Return        bool            False indicates a returned error.

  Description   Called once by PVRShell before the rendering context is created.
                Performs general program initialization.

******************************************************************************/

bool RenderToTexture2::InitApplication()
{
    // Get and set the read path for content files
    CPVRTResourceFile::SetReadPath((char*)PVRShellGet(prefReadPath));

    // Initialize the cube size
    m_fCubeSize = 1.0f;

    // Initialize the rotation angle
    m_fAngleX = 0.0f;
    m_fAngleY = 0.0f;

    // Initialize light intensity uniform
    m_fLightIntensity = 0.5f;        // Must be in the range 0.0 to 1.0

    // Initialize FBO index
    m_CurrentFBO = 1;

    return true;
}

/******************************************************************************

  Function      QuitApplication

  Return        bool            False indicates a returned error.

  Description   Called by PVRShell before exiting the program.  Used to close
                the program.

******************************************************************************/

bool RenderToTexture2::QuitApplication()
{
    return true;
}

/******************************************************************************

  Function      InitView

  Return        bool            False indicates a returned error.

  Description   Called by PVRShell upon initialization and after any change in
                the rendering context.  Used to initialize variables that are
                dependent on the rendering context.

******************************************************************************/

bool RenderToTexture2::InitView()
{
    CPVRTString ErrorStr;

    bool bRotate = PVRShellGet(prefIsRotated) && PVRShellGet(prefFullScreen);

    // Initialize Print3D
    if (m_Print3D.SetTextures(0, PVRShellGet(prefWidth), PVRShellGet(prefHeight), bRotate) != PVR_SUCCESS)
    {
        PVRShellOutputDebug("Error - Failed to load texture.\n");
        return false;
    }

    // Load precompiled vertex shader from a file.  If not found, then compile shader source file.
    if (PVRTShaderLoadFromFile("VertShader.vsc", "VertShader.vsh", GL_VERTEX_SHADER, GL_SGX_BINARY_IMG, &m_hVertShader, &ErrorStr) != PVR_SUCCESS)
    {
        PVRShellOutputDebug("Error - Failed to load vertex shader.\n");
        return false;
    }

    // Load precompiled fragment shader from a file.  If not found, then compile shader source file.
    if (PVRTShaderLoadFromFile("FragShader.fsc", "FragShader.fsh", GL_FRAGMENT_SHADER, GL_SGX_BINARY_IMG, &m_hFragShader, &ErrorStr) != PVR_SUCCESS)
    {
        PVRShellOutputDebug("Error - Failed to load fragment shader.\n");
        return false;
    }

    // Setup and link the shader programs
    const char * AttributeNames[] = { "InputVertex", "InputNormal", "InputTexCoord" };

    if (PVRTCreateProgram(&m_ShaderProgram.uiId, m_hVertShader, m_hFragShader, AttributeNames, 3, &ErrorStr) != PVR_SUCCESS)
    {
        PVRShellSet(prefExitMessage, ErrorStr.c_str());
        return false;
    }

    // Set the sampler2D variable to the first texture unit (0)
    glUniform1i(glGetUniformLocation(m_ShaderProgram.uiId, "sTexture"), 0);

    // Store the location of uniforms for later use
    m_ShaderProgram.uiMVPMatrixLocation = glGetUniformLocation(m_ShaderProgram.uiId, "MVPMatrix");
    m_ShaderProgram.uiLightDirLocation = glGetUniformLocation(m_ShaderProgram.uiId, "LightDirection");
    m_ShaderProgram.uiLightIntensityLocation = glGetUniformLocation(m_ShaderProgram.uiId, "LightIntensity");

    // Calculate the projection and model view matrices

    float fAspect = PVRShellGet(prefWidth) / (float)PVRShellGet(prefHeight);
    m_mViewProj = PVRTMat4::PerspectiveFovFloatDepthRH(PVRT_PI / 6, fAspect, 1.0f, PVRTMat4::OGL, bRotate);
    m_mViewProj *= PVRTMat4::LookAtRH(PVRTVec3(0.0f, 0.0f, 8.0f), PVRTVec3(0.0f), PVRTVec3(0.0f, 1.0f, 0.0f));

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // Generate handles for two dynamically rendered texture maps
    glGenTextures(2, m_hTexture);

    for (int Index = 0; Index < 2; Index++)
    {
        // Bind and configure each texture
        glBindTexture(GL_TEXTURE_2D, m_hTexture[Index]);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, gTextureSize, gTextureSize, 0, GL_RGB, GL_UNSIGNED_BYTE, 0);

        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }

    // Generate handles for two Frame Buffer Objects
    glGenFramebuffers(2, m_hFBO);

    for (int Index = 0; Index < 2; Index++)
    {
        // Attach each texture to the first color buffer of an FBO and clear it
        glBindFramebuffer(GL_FRAMEBUFFER, m_hFBO[Index]);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, m_hTexture[Index], 0);
        glClear(GL_COLOR_BUFFER_BIT);
    }

    // Initialize the start time and frame counter
    m_Time = PVRShellGetTime();
    m_FramesPerSecond = 0;
    m_FrameCount = 0;

    // Setup culling
    glEnable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);

    return true;
}

/******************************************************************************

  Function      ReleaseView

  Return        bool            False indicates a returned error.

  Description   Called by PVRShell when the application quits or before any
                change is made in the rendering context.

******************************************************************************/

bool RenderToTexture2::ReleaseView()
{
    // Delete the FBOs
    glDeleteFramebuffers(2, m_hFBO);

    // Delete the textures
    glDeleteTextures(2, m_hTexture);

    m_Print3D.ReleaseTextures();

    // Delete program and shader objects
    glDeleteProgram(m_ShaderProgram.uiId);
    glDeleteShader(m_hVertShader);
    glDeleteShader(m_hFragShader);

    return true;
}

/******************************************************************************

  Function      RenderScene

  Return        bool            False indicates a returned error.

  Description   The main rendering loop of this program.  PVRShell calls this
                function to render each new frame, then it calls eglSwapBuffers()
                to display each new frame.  PVRShell also abstracts and manages
                important OS events, such as keyboard input.

******************************************************************************/

bool RenderToTexture2::RenderScene()
{
    char         StringBuffer[16];
    char *       pString;
    unsigned int Time;

    // Process keyboard input to adjust light intensity and cube size
    if (PVRShellIsKeyPressed(PVRShellKeyNameLEFT))
        m_fLightIntensity -= 0.1f;
    else if (PVRShellIsKeyPressed(PVRShellKeyNameRIGHT))
        m_fLightIntensity += 0.1f;
    else if (PVRShellIsKeyPressed(PVRShellKeyNameUP))
        m_fCubeSize += 0.1f;
    else if (PVRShellIsKeyPressed(PVRShellKeyNameDOWN))
        m_fCubeSize -= 0.1f;

    // Limit the size of the cube
    if (m_fCubeSize < 0.1f)
        m_fCubeSize = 0.1f;
    else if (m_fCubeSize > 3.0f)
        m_fCubeSize = 3.0f;

    // Limit the intensity of the light
    if (m_fLightIntensity < 0.0f)
        m_fLightIntensity = 0.0f;
    else if (m_fLightIntensity > 1.0f)
        m_fLightIntensity = 1.0f;

    // Check the time
    Time = PVRShellGetTime();

    if (Time - m_Time > 1000)   // Has a one second interval passed?
    {
        m_Time = Time;
        m_FramesPerSecond = m_FrameCount;
        m_FrameCount = 0;
    }
    glUseProgram(m_ShaderProgram.uiId);

    RenderTexture();            // Update the texture map image

    // Load light intensity scaler for the shaders
    glUniform1f(m_ShaderProgram.uiLightIntensityLocation, m_fLightIntensity);

    // Set viewport to size of framebuffer and clear color and depth buffers
    glViewport(0, 0, PVRShellGet(prefWidth), PVRShellGet(prefHeight));
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Calculate a rotated and scaled model matrix
    PVRTMat4 mModel, mRotateX, mRotateY, mScale;
    mRotateX = PVRTMat4::RotationX(m_fAngleX);
    mRotateY = PVRTMat4::RotationY(m_fAngleY);
    mScale = PVRTMat4::Scale(m_fCubeSize, m_fCubeSize, m_fCubeSize);
    mModel = mRotateX * mRotateY * mScale;

    // Rotate the cube model for the next frame
    m_fAngleX += 0.01f;
    m_fAngleY += 0.02f;

    // Calculate model view projection matrix
    PVRTMat4 mMVP = m_mViewProj * mModel;

    // Load projection model view matrix for the shaders
    glUniformMatrix4fv(m_ShaderProgram.uiMVPMatrixLocation, 1, GL_FALSE, mMVP.ptr());

    // Load light direction for the shaders
    PVRTVec3 vMsLightDir = (PVRTVec3(10.0f, 10.0f, 10.0f) * PVRTMat3(mModel)).normalized();
    glUniform3fv(m_ShaderProgram.uiLightDirLocation, 1, vMsLightDir.ptr());

    // Bind updated texture map
    glBindTexture(GL_TEXTURE_2D, m_hTexture[m_CurrentFBO]);
    m_CurrentFBO ^= 1;  // Update the FBO index

    DrawCubeSmooth();   // Draw the cube model
    m_FrameCount++;

    // Unpack and display the current FPS count along with program title.
    pString = &StringBuffer[0];
    Unpack(m_FramesPerSecond, pString, 6);
    strcpy(pString + strlen(pString), " FPS");

    m_Print3D.DisplayDefaultTitle("Render to Texture via FBO", StringBuffer, 0);
    m_Print3D.Flush();

    return true;
}

/******************************************************************************

  Function      RenderTexture

  Return        bool    True if no error occured.

  Description   Render the cube model to a FBO to be used as a texture.

******************************************************************************/
bool RenderToTexture2::RenderTexture()
{
    // Switch the render target to the current FBO to update the texture map
    glBindFramebuffer(GL_FRAMEBUFFER, m_hFBO[m_CurrentFBO]);

    // FBO attachment is complete?
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE)
    {
        // Set viewport to size of texture map and erase previous image
        glViewport(0, 0, gTextureSize, gTextureSize);
        glClearColor(0.8f, 0.8f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Calculate the model matrix
        PVRTMat4 mModel, mRotateX, mRotateY, mTrans;
        mRotateX = PVRTMat4::RotationX(m_fAngleX);
        mRotateY = PVRTMat4::RotationY(m_fAngleY);
        mTrans = PVRTMat4::Translation(0.0f, 0.0f, -4.0f);
        mModel = mTrans * mRotateX * mRotateY;
  
        // Calculate model view projection matrix

        PVRTMat4 mViewProj = PVRTMat4::PerspectiveFovRH(1.0f, 1.0f, gfCameraNear, gfCameraFar, PVRTMat4::OGL, false);
        PVRTMat4 mMVP = mViewProj * mModel;
  
        // Load projection model view matrix for the shaders
        glUniformMatrix4fv(m_ShaderProgram.uiMVPMatrixLocation, 1, GL_FALSE, mMVP.ptr());
  
        // Load light direction for the shaders
        PVRTVec3 vMsLightDir = (PVRTVec3(10.0f, 10.0f, 10.0f) * PVRTMat3(mModel)).normalized();
        glUniform3fv(m_ShaderProgram.uiLightDirLocation, 1, vMsLightDir.ptr());

        // Bind the opposite texture to prevent writing to the same texture
        glBindTexture(GL_TEXTURE_2D, m_hTexture[m_CurrentFBO ^ 1]);

        DrawCubeSmooth();   // Draw the cube model
    }

    // Unbind the FBO so rendering will return to the backbuffer.
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    return true;
}

/******************************************************************************

  Function      DrawCubeSmooth

  Return        None

  Description   Draw a cube using Vertex and NormalsPerVertex Arrays and
                glDrawArrays with two triangle strips.  Because normals are
                supplied per vertex, all the triangles will be smooth shaded.
                Triangle strips are used instead of an index array.  Both of
                the strips are texture mapped.

******************************************************************************/
void RenderToTexture2::DrawCubeSmooth(void)
{
    static GLfloat Vertices[16][3] =
    {   // x     y     z
        {-1.0, -1.0,  1.0}, // 1  left    First Strip
        {-1.0,  1.0,  1.0}, // 3
        {-1.0, -1.0, -1.0}, // 0
        {-1.0,  1.0, -1.0}, // 2
        { 1.0, -1.0, -1.0}, // 4  back
        { 1.0,  1.0, -1.0}, // 6
        { 1.0, -1.0,  1.0}, // 5  right
        { 1.0,  1.0,  1.0}, // 7
        { 1.0,  1.0, -1.0}, // 6  top     Second Strip
        {-1.0,  1.0, -1.0}, // 2
        { 1.0,  1.0,  1.0}, // 7
        {-1.0,  1.0,  1.0}, // 3
        { 1.0, -1.0,  1.0}, // 5  front
        {-1.0, -1.0,  1.0}, // 1
        { 1.0, -1.0, -1.0}, // 4  bottom
        {-1.0, -1.0, -1.0}  // 0
    };
    static GLfloat NormalsPerVertex[16][3] =    // One normal per vertex.
    {   // x     y     z
        {-0.5, -0.5,  0.5}, // 1  left          First Strip
        {-0.5,  0.5,  0.5}, // 3
        {-0.5, -0.5, -0.5}, // 0
        {-0.5,  0.5, -0.5}, // 2
        { 0.5, -0.5, -0.5}, // 4  back
        { 0.5,  0.5, -0.5}, // 6
        { 0.5, -0.5,  0.5}, // 5  right
        { 0.5,  0.5,  0.5}, // 7
        { 0.5,  0.5, -0.5}, // 6  top           Second Strip
        {-0.5,  0.5, -0.5}, // 2
        { 0.5,  0.5,  0.5}, // 7
        {-0.5,  0.5,  0.5}, // 3
        { 0.5, -0.5,  0.5}, // 5  front
        {-0.5, -0.5,  0.5}, // 1
        { 0.5, -0.5, -0.5}, // 4  bottom
        {-0.5, -0.5, -0.5}  // 0
    };
    static GLfloat TexCoords[16][2] =
    {   // x   y
        {0.0, 1.0}, // 1  left                  First Strip
        {1.0, 1.0}, // 3
        {0.0, 0.0}, // 0
        {1.0, 0.0}, // 2
        {0.0, 1.0}, // 4  back
        {1.0, 1.0}, // 6
        {0.0, 0.0}, // 5  right
        {1.0, 0.0}, // 7
        {0.0, 1.0}, // 1  top                   Second Strip
        {1.0, 1.0}, // 3
        {0.0, 0.0}, // 0
        {1.0, 0.0}, // 2
        {0.0, 1.0}, // 4  front
        {1.0, 1.0}, // 6
        {0.0, 0.0}, // 5  bottom
        {1.0, 0.0}  // 7
    };

    // Enable 3 types of data
    glEnableVertexAttribArray(VERTEX_ARRAY);
    glEnableVertexAttribArray(NORMAL_ARRAY);
    glEnableVertexAttribArray(TEXCOORD_ARRAY);

    // Set pointers to the arrays
    glVertexAttribPointer(VERTEX_ARRAY, 3, GL_FLOAT, GL_FALSE, 0, Vertices);
    glVertexAttribPointer(NORMAL_ARRAY, 3, GL_FLOAT, GL_FALSE, 0, NormalsPerVertex);
    glVertexAttribPointer(TEXCOORD_ARRAY, 2, GL_FLOAT, GL_FALSE, 0, TexCoords);

    // Draw both triangle strips with texture map
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 8);
    glDrawArrays(GL_TRIANGLE_STRIP, 8, 8);

    glDisableVertexAttribArray(VERTEX_ARRAY);
    glDisableVertexAttribArray(NORMAL_ARRAY);
    glDisableVertexAttribArray(TEXCOORD_ARRAY);
};

/******************************************************************************

  Function      Unpack

  Return        None

  Description   Convert an unsigned integer value to a decimal character string.
                Any leading zeros are removed from the string.

******************************************************************************/
void RenderToTexture2::Unpack
(
    unsigned long Number,       // Positive integer value to unpack.
    char *        pChar,        // Pointer to store output string.
    unsigned int  DigitCount    // Count of digits to unpack.
)
{
    unsigned long Result;
    char * pStart = pChar;
    unsigned int Count = DigitCount;

    pChar += DigitCount;
    *pChar-- = '\0';

    while (DigitCount-- > 0)
    {
        Result = Number / 10;
        *pChar-- = (char)(Number - (Result * 10) + '0');
        Number = Result;
    }
    while ((*++pChar == '0') && --Count);

    strcpy(pStart, pChar);
}
 