#ifndef _FBKernal_Vector_h_
#define _FBKernal_Vector_h_

#include "FBKernal_Allocator.h"

template<class Type, BOOL bConstruct = true>
class CFBKernal_Vector
{
protected:
	void Clear(void);

public:
	CFBKernal_Vector(CFBKernal_Allocator* pAllocator = FBKernal_DefaultAllocator());
	virtual ~CFBKernal_Vector();

	void Release(void);

	void Resize(DWORD dwSize);
	DWORD Capacity(void);

	Type& GetData(DWORD dwIndex);
	Type& operator[](DWORD dwIndex);

	Type* Ptr(void);

	void Construct(DWORD dwIndex);

public:
	Type*					m_pPtr;
	DWORD					m_dwSize;

	CFBKernal_Allocator*	m_pAllocator;
};

template<class Type, BOOL bConstruct>
void CFBKernal_Vector<Type, bConstruct>::Clear(void)
{
	m_pPtr = 0;
	m_dwSize = 0;
}

template<class Type, BOOL bConstruct>
CFBKernal_Vector<Type, bConstruct>::CFBKernal_Vector(CFBKernal_Allocator* pAllocator)
{
	Clear();
	m_pAllocator = pAllocator;
}
template<class Type, BOOL bConstruct>
CFBKernal_Vector<Type, bConstruct>::~CFBKernal_Vector()
{
	Release();
}

template<class Type, BOOL bConstruct>
void CFBKernal_Vector<Type, bConstruct>::Release(void)
{
	if(bConstruct)
	{
		for(DWORD n = 0; n < m_dwSize; n++)
		{
			FBKernal_Pool_Construct(m_pPtr + n);
		}
	}
	m_pAllocator->Free(m_pPtr);
	Clear();
}

template<class Type, BOOL bConstruct>
void CFBKernal_Vector<Type, bConstruct>::Resize(DWORD dwSize)
{
	// ��������е�С�����
	if(dwSize <= m_dwSize)
	{
		return;
	}
	// ��������еĴ��򴴽�������
	DWORD dwTemp = max(dwSize * 2, 16);
	Type* pPtr = (Type*)m_pAllocator->Malloc(sizeof(Type), dwTemp, false);
	if(bConstruct)
	{
		for(DWORD n = m_dwSize; n < dwTemp; n++)
		{
			FBKernal_Pool_Construct(pPtr + n);
		}
	}
	if(m_pPtr)
	{
		CopyMemory(pPtr, m_pPtr, sizeof(Type) * m_dwSize);
		m_pAllocator->Free(m_pPtr);
	}
	m_pPtr = pPtr;
	m_dwSize = dwTemp;
}
template<class Type, BOOL bConstruct>
DWORD CFBKernal_Vector<Type, bConstruct>::Capacity(void)
{
	return m_dwSize;
}

template<class Type, BOOL bConstruct>
Type& CFBKernal_Vector<Type, bConstruct>::GetData(DWORD dwIndex)
{
	Resize(dwIndex + 1);
	return *(m_pPtr + dwIndex);
}
template<class Type, BOOL bConstruct>
Type& CFBKernal_Vector<Type, bConstruct>::operator[](DWORD dwIndex)
{
	return GetData(dwIndex);
}

template<class Type, BOOL bConstruct>
Type* CFBKernal_Vector<Type, bConstruct>::Ptr(void)
{
	return m_pPtr;
}

#endif