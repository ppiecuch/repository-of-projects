#ifndef _FBKernal_Float_h_
#define _FBKernal_Float_h_

#include "FBKernal_Assert.h"
#include <math.h>

inline int FBKernal_Float_Cmp(float f0, float f1, float fGap = 0.0001f)
{
	FBKernal_Assert(fGap >= 0);

	if(fabs(f0 - f1) <= fGap)
	{
		return 0;
	}
	if(f0 > f1)
	{
		return 1;
	}
	else
	if(f0 < f1)
	{
		return -1;
	}
	else
		return 0;
}

#endif