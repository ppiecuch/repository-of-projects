#ifndef _FBKernal_PoolEx_h_
#define _FBKernal_PoolEx_h_

#include "FBKernal_List.h"

#ifdef _DEBUG
struct CFBKernal_PoolEx_Chunk : public CFBKernal_ListNode<CFBKernal_PoolEx_Chunk>
#else
struct CFBKernal_PoolEx_Chunk
#endif
{
	DWORD					m_dwSize;

	#ifndef _DEBUG
	CFBKernal_PoolEx_Chunk*	m_pNext;
	#endif
};

struct CFBKernal_PoolEx_Block
{
	char*					m_pPtr;
	char*					m_pPtr_Cur;

	CFBKernal_PoolEx_Block*	m_pNext;
};

class CFBKernal_PoolEx
{
public:
	CFBKernal_PoolEx(DWORD dwChunkSize);
	~CFBKernal_PoolEx();

	void* Malloc(void);
	void Free(void* pPtr);

	template<class Type>
	Type* New(DWORD dwCount);
	template<class Type>
	void Delete(Type* pPtr);

protected:
	DWORD									m_dwChunkSize;
	DWORD									m_dwChunksPerBlock;

	CFBKernal_PoolEx_Block*					m_pBlockHead;

	#ifdef _DEBUG
	CFBKernal_List<CFBKernal_PoolEx_Chunk>	m_pNChunkList;
	CFBKernal_List<CFBKernal_PoolEx_Chunk>	m_pAChunkList;
	#else
	CFBKernal_PoolEx_Chunk*					m_pNChunkHead;
	#endif
};

template<class Type>
Type* CFBKernal_PoolEx::New(DWORD dwCount)
{
	Type* pPtr = (Type*)Malloc();
	if(!pPtr)
	{
		return 0;
	}

	for(DWORD n = 0; n < dwCount; n++)
	{
		new(pPtr + n) Type;
	}
	return pPtr;
	}
template<class Type>
void CFBKernal_PoolEx::Delete(Type* pPtr)
{
	if(!pPtr)
	{
		return;
	}

	DWORD dwCount = *((DWORD*)pPtr - 1) / sizeof(Type);
	for(DWORD n = 0; n < dwCount; n++)
	{
		(pPtr + n)->~Type();
	}
	Free(pPtr);
}

class CFBKernal_PoolRealEx
{
public:
	void* Malloc(DWORD dwSize);
	void Free(void* pPtr);

	template<class Type>
	Type* New(DWORD dwCount);
	template<class Type>
	void Delete(Type* pPtr);

protected:
	#ifdef _DEBUG
	CFBKernal_List<CFBKernal_PoolEx_Chunk>	m_pAChunkList;
	#endif
};

template<class Type>
Type* CFBKernal_PoolRealEx::New(DWORD dwCount)
{
	Type* pPtr = (Type*)Malloc(sizeof(Type) * dwCount);
	if(!pPtr)
	{
		return 0;
	}

	for(DWORD n = 0; n < dwCount; n++)
	{
		new(pPtr + n) Type;
	}
	return pPtr;
}
template<class Type>
void CFBKernal_PoolRealEx::Delete(Type* pPtr)
{
	if(!pPtr)
	{
		return;
	}

	DWORD dwCount = *((DWORD*)pPtr - 1) / sizeof(Type);
	for(DWORD n = 0; n < dwCount; n++)
	{
		(pPtr + n)->~Type();
	}
	Free(pPtr);
}

#endif
