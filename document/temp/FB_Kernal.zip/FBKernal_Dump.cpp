#include "FBKernal_Dump.h"
#include "FBKernal_CallStack.h"

char CFBKernal_Dump::m_pAppName[FBKERNAL_STRING_SMALL] = "\0";
void (CALLBACK *CFBKernal_Dump::m_pCallBack)(void) = 0;

CFBKernal_Dump::CFBKernal_Dump(char* pAppName, void (CALLBACK *pCallBack)(void))
{
	#ifndef _DEBUG
	CopyMemory(m_pAppName, pAppName, FBKERNAL_STRING_SMALL);
	m_pAppName[FBKERNAL_STRING_SMALL - 1] = '\0';

	m_pCallBack = pCallBack;

	SetUnhandledExceptionFilter(TopLevelFilter);
	#endif
}
LONG WINAPI CFBKernal_Dump::TopLevelFilter(EXCEPTION_POINTERS* pException)
{
	LONG retval = EXCEPTION_CONTINUE_SEARCH;
	HWND hParent = 0;

	LPCTSTR szResult = NULL;

	SYSTEMTIME SystemTime;
	GetSystemTime(&SystemTime);

	char pCurDir[FBKERNAL_STRING_SMALL];
	sprintf(pCurDir, "save\\%d-%d-%d_%d-%d-%d.dmp", SystemTime.wYear, SystemTime.wMonth, SystemTime.wDay, SystemTime.wHour, SystemTime.wMinute, SystemTime.wSecond);

	if(MessageBox(GetActiveWindow(), "���ڳ�������޷�Ԥ֪�Ĵ����ֽ�����һ���ɹ����Ե��ļ��Ƿ񱣴棿", m_pAppName, MB_YESNO) == IDYES)
	{
		HANDLE hFile = CreateFile(pCurDir, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);

		if(hFile != INVALID_HANDLE_VALUE)
		{
			MINIDUMP_EXCEPTION_INFORMATION ExInfo;

			ExInfo.ThreadId = GetCurrentThreadId();
			ExInfo.ExceptionPointers = pException;
			ExInfo.ClientPointers = 0;

			BOOL bOK = MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), hFile, MiniDumpNormal, &ExInfo, 0, 0);
			if(bOK)
			{
				CloseHandle(hFile);

				m_pCallBack();

				char szMsg[FBKERNAL_STRING_SMALL];
				sprintf(szMsg, "�ɹ����浽 %s", pCurDir);
				MessageBox(GetActiveWindow(), szMsg, m_pAppName, MB_OK);
				return EXCEPTION_EXECUTE_HANDLER;
			}
			else
			{
				CloseHandle(hFile);

				char szMsg[FBKERNAL_STRING_SMALL];
				sprintf(szMsg, "�����ļ�ʧ�� %s", pCurDir);
				MessageBox(GetActiveWindow(), szMsg, m_pAppName, MB_OK);
				return EXCEPTION_CONTINUE_SEARCH;
			}
		}
		else
		{
			char szMsg[FBKERNAL_STRING_SMALL];
			sprintf(szMsg, "�����ļ�ʧ�� %s", pCurDir);
			MessageBox(GetActiveWindow(), szMsg, m_pAppName, MB_OK);
			return EXCEPTION_CONTINUE_SEARCH;
		}
	}
	return EXCEPTION_CONTINUE_SEARCH;
}
