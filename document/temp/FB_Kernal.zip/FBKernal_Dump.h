#ifndef _FBKernal_Dump_h_
#define _FBKernal_Dump_h_

#include <windows.h>
#include <stdio.h>
#include "dbghelp.h"
#include "FBKernal_Macro.h"

class CFBKernal_Dump
{
public:
	explicit CFBKernal_Dump(char* pAppName, void (CALLBACK *pCallBack)(void));

private:
	static LONG WINAPI TopLevelFilter(EXCEPTION_POINTERS* pException);

private:
	static char				m_pAppName[FBKERNAL_STRING_SMALL];
	static void				(CALLBACK *m_pCallBack)(void);
};

#endif