#ifndef _FBKernal_Log_h_
#define _FBKernal_Log_h_

class CFBKernal_Log
{
protected:
	void Clear(void)
	{
		m_fFile = 0;
	}

public:
	CFBKernal_Log()
	{
		Clear();
	}
	~CFBKernal_Log()
	{
	}

	BOOL Create(char* pFilename)
	{
		DeleteFile(pFilename);
		m_fFile = fopen(pFilename, "a");
		if(!m_fFile)
		{
			return false;
		}
		return true;
	}
	void Release(void)
	{
		if(!m_fFile)
		{
			return;
		}
		fclose(m_fFile);
	}

	void Log(char* pLog)
	{
		fprintf(m_fFile, "%s", pLog);

		#ifdef _DEBUG
		OutputDebugString(pLog);
		#endif
	}

public:
	FILE*		m_fFile;
};

#endif