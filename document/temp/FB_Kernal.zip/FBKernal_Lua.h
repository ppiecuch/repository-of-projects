#ifndef _FBKernal_Lua_h_
#define _FBKernal_Lua_h_

class CFBKernal_Lua
{
protected:
	void Clear(void);

public:
	CFBKernal_Lua();
	~CFBKernal_Lua();


};

#endif