#ifndef _FBKernal_AllocatorEx_h_
#define _FBKernal_AllocatorEx_h_

#include "FBKernal_PoolEx.h"

class CFBKernal_AllocatorEx
{
public:
	CFBKernal_PoolRealEx	m_RealPool;
	CFBKernal_PoolEx		m_Pool_16;
	CFBKernal_PoolEx		m_Pool_32;
	CFBKernal_PoolEx		m_Pool_48;
	CFBKernal_PoolEx		m_Pool_64;
	CFBKernal_PoolEx		m_Pool_80;
	CFBKernal_PoolEx		m_Pool_96;
	CFBKernal_PoolEx		m_Pool_112;
	CFBKernal_PoolEx		m_Pool_128;
	CFBKernal_PoolEx		m_Pool_144;
	CFBKernal_PoolEx		m_Pool_160;
	CFBKernal_PoolEx		m_Pool_176;
	CFBKernal_PoolEx		m_Pool_192;
	CFBKernal_PoolEx		m_Pool_208;
	CFBKernal_PoolEx		m_Pool_224;
	CFBKernal_PoolEx		m_Pool_240;
	CFBKernal_PoolEx		m_Pool_256;

public:
	inline CFBKernal_AllocatorEx();
	inline virtual ~CFBKernal_AllocatorEx();

	inline void* Malloc(DWORD dwSize);
	inline void Free(void* pPtr);

	template<class Type>
	Type* New(DWORD dwCount);
	template<class Type>
	void Delete(Type* pPtr);
};

CFBKernal_AllocatorEx::CFBKernal_AllocatorEx() : 
m_Pool_16(16), 
m_Pool_32(32), 
m_Pool_48(48),
m_Pool_64(64), 
m_Pool_80(80), 
m_Pool_96(96), 
m_Pool_112(112),
m_Pool_128(128), 
m_Pool_144(144), 
m_Pool_160(160), 
m_Pool_176(176),
m_Pool_192(192),
m_Pool_208(208),
m_Pool_224(224),
m_Pool_240(240),
m_Pool_256(256)
{
}
CFBKernal_AllocatorEx::~CFBKernal_AllocatorEx()
{
}

void* CFBKernal_AllocatorEx::Malloc(DWORD dwSize)
{
	if(dwSize > 256)
	{
		return m_RealPool.Malloc(dwSize);
	}
	return (&m_Pool_16 + ((dwSize + 15) / 16 - 1))->Malloc();
}
void CFBKernal_AllocatorEx::Free(void* pPtr)
{
	if(!pPtr)
	{
		return;
	}

	DWORD dwSize = *((DWORD*)pPtr - 1);
	if(dwSize > 256)
	{
		m_RealPool.Free(pPtr);
		return;
	}
	(&m_Pool_16 + ((dwSize + 15) / 16 - 1))->Free(pPtr);
}

template<class Type>
Type* CFBKernal_AllocatorEx::New(DWORD dwCount)
{
	DWORD dwSize = sizeof(Type) * dwCount;
	if(dwSize > 256)
	{
		return m_RealPool.New<Type>(dwCount);
	}
	return (&m_Pool_16 + ((dwSize + 15) / 16 - 1))->New<Type>(dwCount);
}
template<class Type>
void CFBKernal_AllocatorEx::Delete(Type* pPtr)
{
	if(!pPtr)
	{
		return;
	}

	DWORD dwSize = *((DWORD*)pPtr - 1);
	if(dwSize > 256)
	{
		m_RealPool.Delete(pPtr);
		return;
	}
	(&m_Pool_16 + ((dwSize + 15) / 16 - 1))->Delete(pPtr);
}

inline CFBKernal_AllocatorEx* FBKernal_DefaultAllocatorEx(void)
{
	static CFBKernal_AllocatorEx Allocator_DefaultEx;
	return &Allocator_DefaultEx;
}

#define FB_NEW(Type, dwCount, bDump)\
	FBKernal_DefaultAllocatorEx()->New<Type >(dwCount);
#define FB_DELETE(pPtr)\
	FBKernal_DefaultAllocatorEx()->Delete(pPtr);\
	pPtr = 0;

#define FB_MALLOC(dwSize, dwCount, bDump)\
	FBKernal_DefaultAllocatorEx()->Malloc(dwSize * dwCount);
#define FB_FREE(pPtr)\
	FBKernal_DefaultAllocatorEx()->Free(pPtr);\
	pPtr = 0;

#endif