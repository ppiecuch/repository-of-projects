#ifndef _FBKernal_HashMap_h_
#define _FBKernal_HashMap_h_

#include "FBKernal_Vector.h"
#include "FBKernal_List.h"

template <class Key>
struct CFBKernal_HashMap_Hash
{
};

template<> struct CFBKernal_HashMap_Hash<char*>
{
	DWORD operator()(const char* key) const
	{
		DWORD dwHash = 0; 
		for(; *key; ++key)
		{
			dwHash = 5 * dwHash + *key;
		}
		return dwHash;
	}
};
template<> struct CFBKernal_HashMap_Hash<const char*>
{
	DWORD operator()(const char* key) const
	{
		DWORD dwHash = 0; 
		for(; *key; ++key)
		{
			dwHash = 5 * dwHash + *key;
		}
		return dwHash;
	}
};
template<> struct CFBKernal_HashMap_Hash<char>
{
	DWORD operator()(char key) const {return key;}
};
template<> struct CFBKernal_HashMap_Hash<unsigned char>
{
	DWORD operator()(unsigned char key) const {return key;}
};
template<> struct CFBKernal_HashMap_Hash<signed char>
{
	DWORD operator()(unsigned char key) const {return key;}
};
template<> struct CFBKernal_HashMap_Hash<short>
{
	DWORD operator()(short key) const {return key;}
};
template<> struct CFBKernal_HashMap_Hash<unsigned short> 
{
	DWORD operator()(unsigned short key) const {return key;}
};
template<> struct CFBKernal_HashMap_Hash<int> 
{
	DWORD operator()(int key) const {return key;}
};
template<> struct CFBKernal_HashMap_Hash<unsigned int> 
{
	DWORD operator()(unsigned int key) const {return key;}
};
template<> struct CFBKernal_HashMap_Hash<long> 
{
	DWORD operator()(long key) const {return key;}
};
template<> struct CFBKernal_HashMap_Hash<unsigned long> 
{
	DWORD operator()(unsigned long key) const {return key;}
};

template <class Key>
struct CFBKernal_HashMap_Comp
{
};

template<> struct CFBKernal_HashMap_Comp<char*>
{
	BOOL operator()(const char* key0, const char* key1) const
	{
		return strcmp(key0, key1) == 0;
	}
};
template<> struct CFBKernal_HashMap_Comp<const char*>
{
	BOOL operator()(const char* key0, const char* key1) const
	{
		return strcmp(key0, key1) == 0;
	}
};
template<> struct CFBKernal_HashMap_Comp<char>
{
	BOOL operator()(char key0, char key1) const {return key0 == key1;}
};
template<> struct CFBKernal_HashMap_Comp<unsigned char>
{
	BOOL operator()(unsigned char key0, unsigned char key1) const {return key0 == key1;}
};
template<> struct CFBKernal_HashMap_Comp<signed char>
{
	BOOL operator()(unsigned char key0, unsigned char key1) const {return key0 == key1;}
};
template<> struct CFBKernal_HashMap_Comp<short>
{
	BOOL operator()(short key0, short key1) const {return key0 == key1;}
};
template<> struct CFBKernal_HashMap_Comp<unsigned short> 
{
	BOOL operator()(unsigned short key0, unsigned short key1) const {return key0 == key1;}
};
template<> struct CFBKernal_HashMap_Comp<int> 
{
	BOOL operator()(int key0, int key1) const {return key0 == key1;}
};
template<> struct CFBKernal_HashMap_Comp<unsigned int> 
{
	BOOL operator()(unsigned int key0, unsigned int key1) const {return key0 == key1;}
};
template<> struct CFBKernal_HashMap_Comp<long> 
{
	BOOL operator()(unsigned long key0, unsigned long key1) const {return key0 == key1;}
};
template<> struct CFBKernal_HashMap_Comp<unsigned long> 
{
	BOOL operator()(unsigned long key0, unsigned long key1) const {return key0 == key1;}
};

template<class Type>
class CFBKernal_HashMapNode
{
public:
	Type						m_Key;
	DWORD						m_dwVal;
	CFBKernal_HashMapNode*		m_pNext;
};

template<class Type, class Hash = CFBKernal_HashMap_Hash<Type>, class Comp = CFBKernal_HashMap_Comp<Type> >
class CFBKernal_HashMap
{
public:
	typedef CFBKernal_HashMapNode<Type>			Node;
	typedef CFBKernal_Vector<Node*, false>		Map;

protected:
	void Clear(void);

public:
	DWORD										m_dwNodes;
	Map*										m_pMap;
	Hash										m_Hash;
	Comp										m_Comp;

public:
	CFBKernal_HashMap();
	~CFBKernal_HashMap();

	void Release(void);

	void Push(const Type Key, DWORD dwVal);
	void Pop(const Type Key);

	DWORD Find(const Type Key);
};

template<class Type, class Hash, class Comp>
void CFBKernal_HashMap<Type, Hash, Comp>::Clear(void)
{
	m_dwNodes = 0;
	m_pMap = 0;
}

template<class Type, class Hash, class Comp>
CFBKernal_HashMap<Type, Hash, Comp>::CFBKernal_HashMap()
{
	Clear();

	m_pMap = FB_NEW(Map, 1, false);
	m_pMap->Resize(50);
	ZeroMemory(m_pMap->Ptr(), m_pMap->Capacity() * 4);
}
template<class Type, class Hash, class Comp>
CFBKernal_HashMap<Type, Hash, Comp>::~CFBKernal_HashMap()
{
	Release();
}

template<class Type, class Hash, class Comp>
void CFBKernal_HashMap<Type, Hash, Comp>::Release(void)
{
	if(m_pMap)
	{
		Node* pNext;
		Node* pNode;

		for(DWORD n = 0; n < m_pMap->Capacity(); n++)
		{
			pNode = m_pMap->Ptr()[n];
			while(pNode)
			{
				pNext = pNode->m_pNext;
				FB_FREE(pNode);
				pNode = pNext;
			}
		}
		m_pMap->Release();
		FB_DELETE(m_pMap);
	}
	Clear();
}

template<class Type, class Hash, class Comp>
void CFBKernal_HashMap<Type, Hash, Comp>::Push(const Type Key, DWORD dwVal)
{
	if(m_dwNodes + 1 > m_pMap->Capacity())
	{
		Map* pNewMap = FB_NEW(Map, 1, false);
		pNewMap->Resize(m_dwNodes + 1);
		ZeroMemory(pNewMap->Ptr(), pNewMap->Capacity() * 4);

		DWORD dwHash;
		Node* pNext;
		Node* pNode;
		for(DWORD n = 0; n < m_dwNodes; n++)
		{
			pNode = m_pMap->Ptr()[n];
			while(pNode)
			{
				dwHash = m_Hash(pNode->m_Key) % pNewMap->Capacity();
				
				pNext = pNode->m_pNext;

				pNode->m_pNext = pNewMap->Ptr()[dwHash];
				pNewMap->Ptr()[dwHash] = pNode;

				pNode = pNext;
			}
		}
		FB_DELETE(m_pMap);
		m_pMap = pNewMap;
	}

	DWORD dwHash = m_Hash(Key) % m_pMap->Capacity();

	Node* pNode = (Node*)FB_MALLOC(sizeof(Node), 1, false);
	pNode->m_Key = Key;
	pNode->m_dwVal = dwVal;
	pNode->m_pNext = m_pMap->Ptr()[dwHash];
	m_pMap->Ptr()[dwHash] = pNode;
	m_dwNodes++;
}
template<class Type, class Hash, class Comp>
void CFBKernal_HashMap<Type, Hash, Comp>::Pop(const Type Key)
{
	DWORD dwHash = m_Hash(Key) % m_pMap->Capacity();
	Node* pPrev = 0;
	Node* pNode = m_pMap->Ptr()[dwHash];
	while(pNode)
	{
		if(m_Comp(pNode->m_Key, Key))
		{
			if(!pPrev)
			{
				m_pMap->Ptr()[dwHash] = pNode->m_pNext;
			}
			else
			{
				pPrev->m_pNext = pNode->m_pNext;
			}
			FB_FREE(pNode);
			m_dwNodes--;
			return;
		}
		pPrev = pNode;
		pNode = pNode->m_pNext;
	}
}

template<class Type, class Hash, class Comp>
DWORD CFBKernal_HashMap<Type, Hash, Comp>::Find(const Type Key)
{	
	DWORD dwHash = m_Hash(Key) % m_pMap->Capacity();
	CFBKernal_HashMapNode<Type>* pNode = m_pMap->Ptr()[dwHash];
	while(pNode)
	{
		if(m_Comp(pNode->m_Key, Key))
		{
			return pNode->m_dwVal;
		}
		pNode = pNode->m_pNext;
	}
	return 0;
}

#endif
