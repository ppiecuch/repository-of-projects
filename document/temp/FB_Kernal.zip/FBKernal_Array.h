#ifndef _FBKernal_Array_h_
#define _FBKernal_Array_h_

#include "FBKernal_Assert.h"
#include "FBKernal_Memory.h"

template<class Type, int nPresentCount = 0>
class CFBKernal_Array
{
protected:
	void Clear(void);

public:
	CFBKernal_Array();
	~CFBKernal_Array();

	void SetCount(int nCount);

	Type& GetData(int nIndex);
    Type& operator[](int nIndex);
		
	void Release(void);

public:
	Type*				m_pPtr;
	int					m_nCount;
};

template<class Type, int nPresentCount>
void CFBKernal_Array<Type, nPresentCount>::Clear(void)
{
	m_pPtr = 0;
	m_nCount = 0;
}

template<class Type, int nPresentCount>
CFBKernal_Array<Type, nPresentCount>::CFBKernal_Array()
{
	Clear();
}
template<class Type, int nPresentCount>
CFBKernal_Array<Type, nPresentCount>::~CFBKernal_Array()
{
	Clear();
}

template<class Type, int nPresentCount>
void CFBKernal_Array<Type, nPresentCount>::SetCount(int nCount)
{
	FBKernal_Assert(nCount >= 0);

	if(!m_pPtr)
	{
		// ֱ�ӷ���ָ����С�Ŀռ�
		nCount += nPresentCount;
		m_pPtr = FB_New(Type, nCount);
	}
	else
	{
		// ��������е�С�����
		if(nCount <= m_nCount)
		{
			return;
		}
		// ��������еĴ��򴴽�������
		nCount += nPresentCount;
		Type* pPtr = FB_New(Type, nCount);
		CopyMemory(pPtr, m_pPtr, sizeof(Type) * m_nCount);
		FB_Delete(m_pPtr);
		m_pPtr = pPtr;
	}
	m_nCount = nCount;
}

template<class Type, int nPresentCount>
Type& CFBKernal_Array<Type, nPresentCount>::GetData(int nIndex)
{
	FBKernal_Assert(nIndex >= 0);

	SetCount(nIndex + 1);
	return *(m_pPtr + nIndex);
}
template<class Type, int nPresentCount>
Type& CFBKernal_Array<Type, nPresentCount>::operator[](int nIndex)
{
	return GetData(nIndex);
}

template<class Type, int nPresentCount>
void CFBKernal_Array<Type, nPresentCount>::Release(void)
{
	FB_Delete(m_pPtr);
	Clear();
}

#endif