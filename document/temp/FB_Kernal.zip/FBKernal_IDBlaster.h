#ifndef _FBKernal_IDBlaster_h_
#define _FBKernal_IDBlaster_h_

class CFBKernal_IDBlaster
{
protected:
	void Clear(void)
	{
		m_dwNowValidID = 0;
		m_pFilename[0] = '\0';
	}

public:
	CFBKernal_IDBlaster(void)
	{
		Clear();
	}
	~CFBKernal_IDBlaster()
	{
		if(FBKernal_Helper_StringValid(m_pFilename))
		{
			FILE* file = fopen(m_pFilename, "wb");
			if(!file)
			{
				return;
			}
			fwrite(&m_dwNowValidID, sizeof(DWORD), 1, file);
			fclose(file);


		}
	}

	void StartID(DWORD dwStartID, char* pFilename = 0)
	{
		m_dwNowValidID = dwStartID;
		FBKernal_Helper_StringCopy(m_pFilename, pFilename, FBKERNAL_STRING_SMALL);
		
		if(pFilename)
		{
			FILE* file = fopen(m_pFilename, "rb");
			if(!file)
			{
				return;
			}
			fread(&m_dwNowValidID, sizeof(DWORD), 1, file);
			fclose(file);
		}
	}

	DWORD QueryValidID(BOOL bSaveNow = false)
	{
		DWORD dwRet = m_dwNowValidID++;
		if(FBKernal_Helper_StringValid(m_pFilename) && bSaveNow)
		{
			FILE* file = fopen(m_pFilename, "wb");
			if(!file)
			{
				return 0;
			}
			fwrite(&m_dwNowValidID, sizeof(DWORD), 1, file);
			fclose(file);
		}
		return dwRet;
	}

public:
	DWORD		m_dwNowValidID;
	char		m_pFilename[FBKERNAL_STRING_SMALL];
};

#endif
