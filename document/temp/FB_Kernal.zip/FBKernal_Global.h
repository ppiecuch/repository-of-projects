#ifndef _FBKernal_Global_h_
#define _FBKernal_Global_h_

#include "FBKernal_String.h"

extern CFBKernal_String					g_FBKernal_Global_CurDir;

void FBKernal_Global_Init(void);

#endif