#include "FBKernal_File.h"
#include <mbstring.h>
#include "FBKernal_Array.h"

static CFBKernal_Array<wchar_t*, 256>	m_pWTextDic;
static int nRowCount = 0;

void CFBKernal_File::Clear(void)
{
	m_fFile = 0;

	m_nBeginTell = 0;
	m_nEndTell = 0;
	m_nCurTell = 0;
}

CFBKernal_File::CFBKernal_File()
{
	Clear();
}
CFBKernal_File::~CFBKernal_File()
{
	Clear();
}

BOOL CFBKernal_File::Eof(void)
{
	FBKernal_Assert(m_fFile);
	FBKernal_Assert(m_nCurTell >= m_nBeginTell && m_nCurTell <= m_nEndTell);

	if(m_nEndTell == m_nCurTell)
	{
		return true;
	}
	return false;
}
int CFBKernal_File::Length(void)
{
	return m_nEndTell - m_nBeginTell;
}

int CFBKernal_File::Read(void* pBuffer, int nSize, int nCount)
{
	FBKernal_Assert(m_fFile);
	FBKernal_Assert(m_nCurTell >= m_nBeginTell && m_nCurTell <= m_nEndTell);
	FBKernal_Assert(pBuffer);

	fseek(m_fFile, m_nCurTell, SEEK_SET);
	int nRealSize = min(nSize * nCount, m_nEndTell - m_nCurTell);
	fread(pBuffer, nRealSize, 1, m_fFile);
	m_nCurTell += nRealSize;
	return nRealSize;
}

void CFBKernal_File_Pack::Clear(void)
{
	m_fFile = 0;
	m_pHeader = 0;
}

CFBKernal_File_Pack::CFBKernal_File_Pack()
{
	Clear();
}
CFBKernal_File_Pack::~CFBKernal_File_Pack()
{
	Clear();
}

BOOL CFBKernal_File_Pack::Open(char* pPackname)
{
	Close();
	m_fFile = fopen(pPackname, "rb");
	if(!m_fFile)
	{
		return false;
	}
	
	// �ļ���
	fread(&m_nHeaders, sizeof(int), 1, m_fFile);
	m_pHeader = FB_New(_Header, m_nHeaders);
	fread(m_pHeader, sizeof(_Header), m_nHeaders, m_fFile);

	return true;
}
void CFBKernal_File_Pack::Close(void)
{
	FB_Delete(m_pHeader);

	if(m_fFile)
	{
		fclose(m_fFile);
	}
}

CFBKernal_File* CFBKernal_File_Pack::QueryFile(char* pFilename)
{
	// ��m_pHeader�ж��ֲ���ָ���ļ�
	for(int h = 0; h < m_nHeaders; h++)
	{
		if(stricmp(m_pHeader[h].m_Filename.c_str(), pFilename) == 0)
		{
			break;
		}
	}
			
	{
		return 0;
	}

	// ����һ���µ�CFBKernal_File
	CFBKernal_File* pFile = FB_New(CFBKernal_File, 1);
	pFile->m_fFile = m_fFile;
	pFile->m_nBeginTell = m_pHeader[h].m_nBeginTell;
	pFile->m_nEndTell = m_pHeader[h].m_nEndTell;

	return pFile;
}
void CFBKernal_File_Pack::ReleaseFile(CFBKernal_File* pFile)
{
	FB_Delete(pFile);
}

BOOL FBKernal_File_IsExist(char* pFilename)
{
	FILE* file = fopen(pFilename, "rb");
	if(!file)
	{
		return false;
	}
	fclose(file);
	return true;
}
BOOL FBkernal_File_IsEof(FILE* file)
{
	return ftell(file) == filelength(fileno(file));
}

BOOL TransTxt( const char* pFilenameIn, const char* pFilenameOut)
{
	FBKernal_Assert( pFilenameIn && pFilenameOut );
	if ( !pFilenameIn || !pFilenameOut )
	{
		return FALSE;
	}
	FILE* infile = fopen(pFilenameIn, "r");
	if(!infile)
	{
		char msg[256];
		sprintf(msg, "�޷��� %s �ļ���", pFilenameIn);
		FBKernal_MessageBox(msg);
		return FALSE;
	}

	FILE* OutFile = fopen( pFilenameOut, "w");
	if ( !OutFile )
	{
		return false;
	}

	int nLen = filelength(fileno(infile));
	char* pcLine;
	pcLine = new char[nLen];
	nLen = (int)fread(pcLine, sizeof(char), nLen, infile);
	pcLine[nLen] = '\0';
	char* pbuf;
	pbuf = new char[nLen];
	for ( int i = 0; i < nLen; i++ )
	{
		pbuf[i] = pcLine[nLen-i-1];
	}
	pbuf[nLen] = '\0';
	fwrite((char*)&nLen, sizeof(int), 1, OutFile);
	fwrite((char*)pbuf, sizeof(char), nLen, OutFile);

	fclose(infile);
	fclose(OutFile);
	return TRUE;
}


BOOL InitDic( const char* pFilenameIn)
{
	FILE* file = fopen(pFilenameIn, "rb");
	if(!file)
	{
		char msg[256];
		sprintf(msg, "�޷��� %s �ļ���", pFilenameIn);
		FBKernal_MessageBox(msg);
		return FALSE;
	}

	int nLen1 = filelength(fileno(file));
	nLen1 -= sizeof(int);
	if ( nLen1 < 0 )
	{
		char msg[256];
		sprintf(msg, "���ļ� %s ����", pFilenameIn);
		FBKernal_MessageBox(msg);
		fclose(file);
		return FALSE;
	}

	int nLen;
	fread((void*)&nLen, sizeof(int),1,file);
	char* pbuf;
	pbuf = new char[nLen];
	int anLen = (int)fread(pbuf, sizeof(char), nLen, file);
	if ( anLen != nLen )
	{
		char msg[256];
		sprintf(msg, "���ļ� %s ����", pFilenameIn);
		FBKernal_MessageBox(msg);
		fclose(file);
		return FALSE;
	}
	fclose(file);

	char* pcLine;
	pcLine = new char[nLen];
	for ( int i = 0; i < nLen; i++ )
	{
		pcLine[i] = pbuf[nLen -i -1];
	}
	pcLine[nLen] = '\0';

	// ����
	char seps[]   = " ,\t\n";
	char *token;
	token = strtok( pcLine, seps );
	while( token != NULL  )
	{
		int len = (int)strlen(token);
		wchar_t buf[64];
		MultiByteToWideChar(CP_ACP, 0, token, -1, buf, 256);
		int wlen = (int)wcslen( buf ) + 1;
		m_pWTextDic[nRowCount] = new wchar_t[wlen];
		memcpy( m_pWTextDic[nRowCount], buf, wlen*sizeof(wchar_t) );
		++nRowCount;

		token = strtok( NULL, seps );
	}

	return TRUE;
}

BOOL IsValidString(const wchar_t* pWChar)
{
	FBKernal_Assert( pWChar );

	wchar_t mbdest[256];
	int id = 0;
	for (const wchar_t* p = pWChar; *p; ++p)
	{
		if ( _ismbcalpha(*p) )
		{
			wchar_t tmp[2];
			tmp[0 ]= p[0];
			tmp[1] = NULL;
			_wcsupr( tmp );
			mbdest[id] = tmp[0];
		}
		else
		{
			mbdest[id] = p[0];
		}
		++id;
	}
	mbdest[id] = NULL;

	for (wchar_t* p = mbdest; *p; ++p)
	{
		for ( int i = 0; i < nRowCount; i++)			//
		{
			if (  m_pWTextDic[i][0] == NULL )
			{
				break;
			}
			if ( *p == m_pWTextDic[i][0])
			{
				int wlen = (int)wcslen( m_pWTextDic[i] );
				int findlen = 1;
				for ( const wchar_t* pd = &m_pWTextDic[i][1]; *pd; ++pd )
				{
					wchar_t* ps = p;
					for ( ps++ ; *ps; ps++)
					{
						if ( *pd == *ps )
						{
							findlen++;
							pd++;
							if ( *pd )	
							{	
								continue;	
							}	
							else	
							{	
								goto __label;	
							}
						}
						else
						{
							char ctemp[256];
							wchar_t wchar;
							wchar = ps[0];
							WideCharToMultiByte(CP_ACP, WC_COMPOSITECHECK, &wchar, -1, ctemp, 256, NULL, NULL);
							ctemp[2] = NULL;
							if ( IsDBCSLeadByte( ctemp[0]) )
							{
								BYTE byTemp = 0;
								byTemp = (BYTE)ctemp[0];
								if (  byTemp >= 0xB0 && byTemp <= 0xF9 )
								{
									goto __label;
								}
							}
							else if ( isalpha( ctemp[0]) )
							{
								goto __label;
							}
						}
					}
				}
__label:
				if ( findlen == wlen )
				{
					return FALSE;
				}
			}
		}
	}

	return true;
}

void ReleaseDic()
{
	for ( int i = 0; i < nRowCount; i++ )
	{
		if ( m_pWTextDic[i] )
		{
			delete [] m_pWTextDic[i];
		}
	}
	m_pWTextDic.Release();
	nRowCount = 0;
}

