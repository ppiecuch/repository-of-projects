#ifndef _FBKernal_INI_h_
#define _FBKernal_INI_h_

#include "FBKernal_String.h"
#include "FBKernal_Memory.h"
#include "FBKernal_File.h"
#include "FBKernal_HashTable.h"

class CFBKernal_INI_KeyAndValue : public CFBKernal_LinkNode<CFBKernal_INI_KeyAndValue>
{
protected:
	void Clear(void);

public:
	CFBKernal_INI_KeyAndValue();
	~CFBKernal_INI_KeyAndValue();

	void Release(void);

public:
	CFBKernal_String					m_Key;
	CFBKernal_String					m_Value;
};

class CFBKernal_INI_Section : public CFBKernal_LinkNode<CFBKernal_INI_Section>
{
protected:
	void Clear(void);

public:
	CFBKernal_INI_Section();
	~CFBKernal_INI_Section();

	void Release(void);

public:
	CFBKernal_String								m_Section;

	CFBKernal_Link<CFBKernal_INI_KeyAndValue>		m_KeyAndValue;

	CFBKernal_HashTable<>							m_KeyAndValueHT;
};

class CFBKernal_INI
{
protected:
	void Clear(void);

public:
	CFBKernal_INI();
	~CFBKernal_INI();

	void Release(void);

	void SetBuffer(int nSize);
	BOOL SetFileName(char* pPath, char* pFilename);

	int GetInt(char* pSection, char* pKey, int nDefault);
	void SetInt(char* pSectoin, char* pKey, int nValue);

	char* GetString(char* pSection, char* pKey, char* pDefault);
	void SetString(char* pSection, char* pKey, char* pValue);

	// ����ȡֵ��ռ���ڴ棬�ʺϵõ�ȫ������
	void EnumAll(void);

	CFBKernal_INI_Section* QuerySection(char* pSection);

	char* QueryString(CFBKernal_INI_Section* pSection, char* pKey, char* pDefault);
	int QueryInt(CFBKernal_INI_Section* pSection, char* pKey, int nDefault);
	float QueryFloat(CFBKernal_INI_Section* pSection, char* pKey, float fDefault);

public:
	int											m_nBufferSize;
	char*										m_pBuffer;

	CFBKernal_String							m_Filename;

	CFBKernal_Link<CFBKernal_INI_Section>		m_Section;

	CFBKernal_HashTable<>						m_SectionHT;
};

BOOL FBKernal_INI_ReadTableFile(char* pFilename, int (CALLBACK* pCallBack)(char* pRes, int nLine, BOOL bNewLine, int nSegment));

#endif