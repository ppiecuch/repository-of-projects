#ifndef _FBKernal_Service_h_
#define _FBKernal_Service_h_

#include <windows.h>

BOOL FBKernal_Service_Start(char* pServiceName, DWORD dwTimeout);
BOOL FBKernal_Service_Stop(char* pServiceName, DWORD dwTimeout);

#endif