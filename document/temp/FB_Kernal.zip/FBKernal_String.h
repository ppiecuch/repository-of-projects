#ifndef _FBKernal_String_h_
#define _FBKernal_String_h_

#include "FBKernal_Array.h"

class CFBKernal_String : public CFBKernal_Array<char, 10>
{
protected:
	inline void Clear(void);

public:
	inline CFBKernal_String();
	inline ~CFBKernal_String();

    inline void Equal(const char* pString);
	inline void Equal(CFBKernal_String* pString);

	inline void Attach(const char* pString);
	inline void Attach(CFBKernal_String* pString);

	inline int Cmp(const char* pString);
	inline int Cmp(CFBKernal_String* pString);

	inline int Icmp(const char* pString);
	inline int Icmp(CFBKernal_String* pString);

	inline char* Ptr(void);
	inline int Length(void);

	inline int GetBufferSize(void);

	inline char* CutPath(int nLevel);
	inline char* CullPath(void);
};
inline void CFBKernal_String::Clear(void)
{
}

inline CFBKernal_String::CFBKernal_String()
{
	Clear();
}
inline CFBKernal_String::~CFBKernal_String()
{
	Clear();
}

inline void CFBKernal_String::Equal(const char* pString)
{
	int nLen = (int)strlen(pString) + 1;
	SetCount(nLen);
	CopyMemory(m_pPtr, pString, nLen);
}
inline void CFBKernal_String::Equal(CFBKernal_String* pString)
{
	Equal(pString->m_pPtr);
}

inline void CFBKernal_String::Attach(const char* pString)
{
	int nLen = (int)strlen(pString) + 1;
	int nMe = (int)strlen(m_pPtr);
	SetCount(nLen + nMe);
	CopyMemory(m_pPtr + nMe, pString, nLen);
}
inline void CFBKernal_String::Attach(CFBKernal_String* pString)
{
	Attach(pString->m_pPtr);
}

inline int CFBKernal_String::Cmp(const char* pString)
{
	return strcmp(m_pPtr, pString);
}
inline int CFBKernal_String::Cmp(CFBKernal_String* pString)
{
	return Cmp(pString->m_pPtr);
}

inline int CFBKernal_String::Icmp(const char* pString)
{
	return stricmp(m_pPtr, pString);
}
inline int CFBKernal_String::Icmp(CFBKernal_String* pString)
{
	return Icmp(pString->m_pPtr);
}

inline char* CFBKernal_String::Ptr(void)
{
	return m_pPtr;
}
inline int CFBKernal_String::Length(void)
{
	return (int)strlen(m_pPtr);
}

inline int CFBKernal_String::GetBufferSize(void)
{
	return m_nCount;
}

inline char* CFBKernal_String::CutPath(int nLevel)
{
	if(nLevel == 0)
	{
		return m_pPtr;
	}

	int nTotal = 0;
	int nLen = (int)strlen(m_pPtr);
	for(int p = 0; p < nLen; p++)
	{
		if(m_pPtr[p] == '\\')
		{
			nTotal++;
			if(nTotal == nLevel)
			{
				p++;
				break;
			}
		}
	}
	if(nTotal < nLevel)
	{
		return m_pPtr;
	}
	return m_pPtr + p;
}
inline char* CFBKernal_String::CullPath(void)
{
	for(int p = (int)strlen(m_pPtr) - 1; p >= 0; p--)
	{
		if(m_pPtr[p] == '\\')
		{
			return m_pPtr + p + 1;
		}
	}
	return m_pPtr;
}

inline int FBKernal_String_Copy(char* pDest, char* pSrc, int nMaxDestLen)
{
	int nLen;
	if((int)strlen(pSrc) + 1 > nMaxDestLen)
	{
		nLen = nMaxDestLen;
	}
	else
	{
		nLen = (int)strlen(pSrc) + 1;
	}
	CopyMemory(pDest, pSrc, nLen);
	pDest[nLen - 1] = '\0';
	return nLen;
}
inline char* FBKernal_String_UnPack(char* pString, int nIndex)
{
	char* pNow = pString;
	for(int n = 0; n < nIndex; n++)
	{
		pNow = pNow + strlen(pNow) + 1;
	}
	return pNow;
}
inline BOOL FBKernal_String_IsValid(char* pString)
{
	if ( pString == NULL )
		return false;

	if ( pString[0] == NULL )
		return false;

	while(*pString)
	{
		if(*pString != ' ' && *pString != '\t' && *pString != '\n' && *pString != '\0')
		{
			return true;
		}
		pString++;
	}
	return false;
}

#endif