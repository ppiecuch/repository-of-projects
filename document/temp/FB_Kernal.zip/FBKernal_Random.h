
#pragma once
#ifndef _FBKernal_Random_h_
#define _FBKernal_Random_h_

#include "FBKernal_Port.h"
#include <mmsystem.h>

inline void FBKernal_Random_NewSeed(void)
{
	srand(timeGetTime() + rand());
}
inline int FBKernal_Random(int nMin, int nMax, BOOL bNewSeed = false)
{
	if ( bNewSeed )
		FBKernal_Random_NewSeed();

	return rand() % (nMax - nMin + 1) + nMin;
}

class CFBKernal_Rand
{
public:
	CFBKernal_Rand()
	{
		Clear();
	}
	~CFBKernal_Rand(){};

	BOOL		Create(char* pFilename )
	{
		CFBKernal_INI inifile;
		char strDir[256];

		GetCurrentDirectory( 256, strDir );
		if ( inifile.SetFileName( strDir, pFilename ) )
		{
			inifile.EnumAll();
		}
		else
		{
			char str[128];
			sprintf( str, "���ļ�\"%s\"ʧ��",pFilename);
			FBKernal_MessageBox( str );
			return FALSE;
		}

		CFBKernal_INI_Section* pSection = inifile.QuerySection( "NumDic" );
		if ( !pSection )
		{
			char str[128];
			sprintf( str, "���ļ�\"%s\"ʧ��",pFilename);
			FBKernal_MessageBox( str );
			return FALSE;
		}

		for ( BYTE i = 0; i < 10; i++ )
		{
			char buf[32];
			sprintf( buf, "Num_%d", i );
			int Count = inifile.QueryInt( pSection, buf, 0 );
			m_nSize += Count;
		}

		m_pNumDic = FB_New( int, m_nSize );
		int arrayidx = 0;
		for ( BYTE i = 0; i < 10; i++ )
		{
			char buf[32];
			sprintf( buf, "Num_%d", i );
			int Count = inifile.QueryInt( pSection, buf, 0 );
			for ( int k = 0; k < Count; k++ )
			{
				m_pNumDic[arrayidx] = i;
				arrayidx += 1;
			}
		}

		inifile.Release();

		return TRUE;
	}
	int			GetRand( int nmin, int nmax )
	{
		int nMin,nMax;
		if ( nmin < nmax )
		{
			nMin = nmin;
			nMax = nmax;
		}
		else
		{
			nMin = nmax;
			nMax = nmin;
		}

		int nTemp =  nMax - nMin + 1;
		int nValue = FBKernal_Random( 0, m_nSize-1 );
		int nResult = (int)((float)(m_pNumDic[nValue] * nTemp) / 10.0f);

		return nMin + nResult;
	}

	void		Release()
	{
		FB_Delete(m_pNumDic);
		Clear();
	}
protected:
	void		Clear()
	{
		m_pNumDic = NULL;
		m_nSize   = 0;
	}

private:

	int*		m_pNumDic;
	int			m_nSize;
};


#endif

