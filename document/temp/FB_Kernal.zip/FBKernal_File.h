#ifndef _FBKernal_File_h_
#define _FBKernal_File_h_

#include "FBKernal_Assert.h"
#include "FBKernal_Memory.h"

class CFBKernal_File
{
protected:
	void Clear(void);

public:
	CFBKernal_File();
	~CFBKernal_File();

	BOOL Eof(void);
	int Length(void);

	int Read(void* pBuffer, int nSize, int nCount);

public:
	FILE*				m_fFile;

	int					m_nBeginTell;
	int					m_nEndTell;
	int					m_nCurTell;
};

class CFBKernal_File_Pack
{
protected:
	void Clear(void);

public:
	CFBKernal_File_Pack();
	~CFBKernal_File_Pack();

	BOOL Open(char* pPackname);
	void Close(void);

	CFBKernal_File* QueryFile(char* pFilename);
	void ReleaseFile(CFBKernal_File* pFile);

public:
	class _Header
	{
	protected:
		void Clear(void)
		{
			m_nBeginTell = 0;
			m_nEndTell = 0;
		}

	public:
		_Header()
		{
			Clear();
		}
		~_Header()
		{
			Clear();
		}

	public:
		string				m_Filename;
		int					m_nBeginTell;
		int					m_nEndTell;
	};

	FILE*				m_fFile;

	int					m_nHeaders;
	_Header*			m_pHeader;
};

BOOL FBKernal_File_IsExist(char* pFilename);
BOOL FBkernal_File_IsEof(FILE* file);

//CFBKernal_File_Pack pack;
//pack.Open("1.pak");
//CFBKernal_File *file = pack.Query("haha.dat");
//file->Read();


BOOL		TransTxt( const char* pFilenameIn, const char* pFilenameOut);
BOOL		InitDic( const char* pFilenameIn);
BOOL		IsValidString(const wchar_t* pWChar);
void		ReleaseDic();


#endif
