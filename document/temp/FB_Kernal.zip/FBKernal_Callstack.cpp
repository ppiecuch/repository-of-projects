#include "FBKernal_Callstack.h"

CFBKernal_Lock				g_FBKernal_CallStack_Lock;