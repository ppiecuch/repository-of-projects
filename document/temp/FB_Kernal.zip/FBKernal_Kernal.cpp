#include "FBKernal_Global.h"

CFBKernal_String					g_FBKernal_Global_CurDir;

void FBKernal_Global_Init(void)
{
	g_FBKernal_Global_CurDir.SetCount(256);
	GetCurrentDirectory(
		g_FBKernal_Global_CurDir.GetBufferSize(),
		g_FBKernal_Global_CurDir.Ptr());
	g_FBKernal_Global_CurDir.Attach("\\");
}