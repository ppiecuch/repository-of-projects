#include "FBKernal_Service.h"

BOOL FBKernal_Service_Start(char* pServiceName, DWORD dwTimeout)
{
	SC_HANDLE hManager = OpenSCManager( 
		0,
		0,
		SC_MANAGER_ALL_ACCESS);

	if(!hManager) 
	{
		goto _false_exit;
	}

	SC_HANDLE hService = OpenService( 
		hManager,
		pServiceName,
		SERVICE_ALL_ACCESS); 
	if(!hService) 
	{ 
		goto _false_exit;
	}
	
	if (!StartService(
		hService,
		0,
		0))
	{
		goto _false_exit;
	}

	SERVICE_STATUS ServiceStatus; 
	if (!QueryServiceStatus( 
		hService,
		&ServiceStatus))
	{
		goto _false_exit;
	}

	DWORD dwWaitTime = 0;
	while(ServiceStatus.dwCurrentState == SERVICE_START_PENDING) 
	{ 
		Sleep(1000);
		if(!QueryServiceStatus( 
			hService,
			&ServiceStatus))
		{
			goto _false_exit;
		}
		if(dwWaitTime + 1000 > dwTimeout)
		{
			goto _false_exit;
		}
	} 

	if(ServiceStatus.dwCurrentState == SERVICE_RUNNING) 
	{
		goto _true_exit;
	}
	goto _false_exit;

	_false_exit:
	CloseServiceHandle(hService); 
	CloseServiceHandle(hManager); 
	return false;

	_true_exit:
	CloseServiceHandle(hService); 
	CloseServiceHandle(hManager); 
	return true;
}
BOOL FBKernal_Service_Stop(char* pServiceName, DWORD dwTimeout)
{
	SC_HANDLE hManager = OpenSCManager( 
		0,
		0,
		SC_MANAGER_ALL_ACCESS);

	if(!hManager) 
	{
		goto _false_exit;
	}

	SC_HANDLE hService = OpenService( 
		hManager,
		pServiceName,
		SERVICE_ALL_ACCESS); 
	if(!hService) 
	{ 
		goto _false_exit;
	}

	SERVICE_STATUS ServiceStatus; 
	if(!QueryServiceStatus(hService, &ServiceStatus))
	{
		goto _false_exit;
	}

	if(ServiceStatus.dwCurrentState == SERVICE_STOPPED)
	{
		goto _true_exit;
	}

	DWORD dwWaitTime = 0;
	while(ServiceStatus.dwCurrentState == SERVICE_STOP_PENDING) 
	{
		Sleep(1000);
		if(!QueryServiceStatus(hService, &ServiceStatus))
		{
			goto _false_exit;
		}
		if(ServiceStatus.dwCurrentState == SERVICE_STOPPED)
		{
			goto _true_exit;
		}
		if(dwWaitTime + 1000 > dwTimeout)
		{
			goto _false_exit;
		}
	}

	SC_HANDLE               hDepService;
	LPENUM_SERVICE_STATUS   lpDependencies = NULL;
	DWORD					dwBytesNeeded;
	DWORD					dwCount;
	ENUM_SERVICE_STATUS		EnumServiceStatus;

	if(EnumDependentServices(
		hService,
		SERVICE_ACTIVE, 
		lpDependencies,
		0,
		&dwBytesNeeded,
		&dwCount)) 
	{
		// û����������
	} 
	else 
	{
		if(GetLastError() != ERROR_MORE_DATA)
		{
			goto _false_exit;
		}

		lpDependencies = (LPENUM_SERVICE_STATUS)HeapAlloc(
            GetProcessHeap(),
			HEAP_ZERO_MEMORY,
			dwBytesNeeded);
		if(!lpDependencies)
		{
			goto _false_exit;
		}

		if(!EnumDependentServices(
			hService, 
			SERVICE_ACTIVE, 
			lpDependencies, 
			dwBytesNeeded, 
			&dwBytesNeeded,
			&dwCount))
		{
			goto _false_exit;
		}

		for(DWORD i = 0; i < dwCount; i++) 
		{
			EnumServiceStatus = *(lpDependencies + i);

			hDepService = OpenService(
				hManager,
				EnumServiceStatus.lpServiceName, 
				SERVICE_STOP | SERVICE_QUERY_STATUS);
			if(!hDepService)
			{
				CloseServiceHandle(hDepService);
				goto _false_exit;
			}

			if(!ControlService(
				hDepService, 
				SERVICE_CONTROL_STOP,
				&ServiceStatus))
			{
				CloseServiceHandle(hDepService);
				goto _false_exit;
			}

			dwWaitTime = 0;
			while(ServiceStatus.dwCurrentState != SERVICE_STOPPED) 
			{
				Sleep(1000);
				if(!QueryServiceStatus(hDepService, &ServiceStatus))
				{
					CloseServiceHandle(hDepService);
					goto _false_exit;
				}
				if(ServiceStatus.dwCurrentState == SERVICE_STOPPED)
				{
					break;
				}
				if(dwWaitTime + 1000 > dwTimeout)
				{
					CloseServiceHandle(hDepService);
					goto _false_exit;
				}
			}
			CloseServiceHandle(hDepService);
		}
	} 

	if(!ControlService(hService, SERVICE_CONTROL_STOP, &ServiceStatus))
	{
		goto _false_exit;
	}

	dwWaitTime = 0;
	while(ServiceStatus.dwCurrentState != SERVICE_STOPPED) 
	{
		Sleep(1000);
		if(!QueryServiceStatus(hService, &ServiceStatus))
		{
			goto _false_exit;
		}
		if(ServiceStatus.dwCurrentState == SERVICE_STOPPED)
		{
			break;
		}
		if(dwWaitTime + 1000 > dwTimeout)
		{
			goto _false_exit;
		}
	}
	goto _true_exit;

	_false_exit:
	CloseServiceHandle(hService); 
	CloseServiceHandle(hManager); 
	return false;

	_true_exit:
	CloseServiceHandle(hService); 
	CloseServiceHandle(hManager); 
	return true;
}
