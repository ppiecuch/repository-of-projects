#ifndef _FBKernal_Allocator_h_
#define _FBKernal_Allocator_h_

#include "FBKernal_Pool.h"

class CFBKernal_Allocator
{
public:
	CFBKernal_Pool			m_Pool_0;
	CFBKernal_Pool			m_Pool_8;
	CFBKernal_Pool			m_Pool_16;
	CFBKernal_Pool			m_Pool_32;
	CFBKernal_Pool			m_Pool_64;
	CFBKernal_Pool			m_Pool_128;
	CFBKernal_Pool			m_Pool_256;
	CFBKernal_Pool			m_Pool_512;
	CFBKernal_Pool			m_Pool_1024;
	CFBKernal_Pool			m_Pool_2048;

public:
	inline CFBKernal_Allocator();
	inline virtual ~CFBKernal_Allocator();

	inline void* Malloc(DWORD dwSize, DWORD dwCount, BOOL bDump);
	inline void Free(void* pPtr);

	template<class Type>
	Type* New(DWORD dwCount, BOOL bDump);
	template<class Type>
	void Delete(Type* pPtr);
};

CFBKernal_Allocator::CFBKernal_Allocator() : m_Pool_0(0), m_Pool_8(8), m_Pool_16(16), m_Pool_32(32), m_Pool_64(64), m_Pool_128(128), m_Pool_256(256), m_Pool_512(512), m_Pool_1024(1024), m_Pool_2048(2048)
{
}
CFBKernal_Allocator::~CFBKernal_Allocator()
{
}

void* CFBKernal_Allocator::Malloc(DWORD dwSize, DWORD dwCount, BOOL bDump)
{
	DWORD dwReal = dwSize * dwCount;
	if(dwReal <= 8)
	{
		return m_Pool_8.Malloc(dwSize, dwCount, bDump);
	}
	else
	if(dwReal <= 16)
	{
		return m_Pool_16.Malloc(dwSize, dwCount, bDump);
	}
	else
	if(dwReal <= 32)
	{
		return m_Pool_32.Malloc(dwSize, dwCount, bDump);
	}
	else
	if(dwReal <= 64)
	{
		return m_Pool_64.Malloc(dwSize, dwCount, bDump);
	}
	else
	if(dwReal <= 128)
	{
		return m_Pool_128.Malloc(dwSize, dwCount, bDump);
	}
	else
	if(dwReal <= 256)
	{
		return m_Pool_256.Malloc(dwSize, dwCount, bDump);
	}
	else
	if(dwReal <= 512)
	{
		return m_Pool_512.Malloc(dwSize, dwCount, bDump);
	}
	else
	if(dwReal <= 1024)
	{
		return m_Pool_1024.Malloc(dwSize, dwCount, bDump);
	}
	else
	if(dwReal <= 2048)
	{
		return m_Pool_2048.Malloc(dwSize, dwCount, bDump);
	}
	else
	if(dwReal > 2048)
	{
		return m_Pool_0.Malloc(dwSize, dwCount, bDump);
	}
	return 0;
}
void CFBKernal_Allocator::Free(void* pPtr)
{
	if(!pPtr)
	{
		return;
	}

	CFBKernal_Pool_Chunk* pChunk = (CFBKernal_Pool_Chunk*)((char*)pPtr - sizeof(CFBKernal_Pool_Chunk));
	pChunk->m_pPool->Free(pPtr);
}

template<class Type>
Type* CFBKernal_Allocator::New(DWORD dwCount, BOOL bDump)
{
	DWORD dwReal = sizeof(Type) * dwCount;
	if(dwReal <= 8)
	{
		return m_Pool_8.New<Type>(dwCount, bDump);
	}
	else
	if(dwReal <= 16)
	{
		return m_Pool_16.New<Type>(dwCount, bDump);
	}
	else
	if(dwReal <= 32)
	{
		return m_Pool_32.New<Type>(dwCount, bDump);
	}
	else
	if(dwReal <= 64)
	{
		return m_Pool_64.New<Type>(dwCount, bDump);
	}
	else
	if(dwReal <= 128)
	{
		return m_Pool_128.New<Type>(dwCount, bDump);
	}
	else
	if(dwReal <= 256)
	{
		return m_Pool_256.New<Type>(dwCount, bDump);
	}
	else
	if(dwReal <= 512)
	{
		return m_Pool_512.New<Type>(dwCount, bDump);
	}
	else
	if(dwReal <= 1024)
	{
		return m_Pool_1024.New<Type>(dwCount, bDump);
	}
	else
	if(dwReal <= 2048)
	{
			return m_Pool_2048.New<Type>(dwCount, bDump);
	}
	else
	if(dwReal > 2048)
	{
		return m_Pool_0.New<Type>(dwCount, bDump);
	}
	return 0;
}
template<class Type>
void CFBKernal_Allocator::Delete(Type* pPtr)
{
	if(!pPtr)
	{
		return;
	}

	CFBKernal_Pool_Chunk* pChunk = (CFBKernal_Pool_Chunk*)((char*)pPtr - sizeof(CFBKernal_Pool_Chunk));
	pChunk->m_pPool->Delete(pPtr);
}

inline CFBKernal_Allocator* FBKernal_DefaultAllocator(void)
{
	static CFBKernal_Allocator Allocator_Default;
	return &Allocator_Default;
}

#define FB_NEW(Type, dwCount, bDump)\
	FBKernal_DefaultAllocator()->New<Type >(dwCount, bDump);
#define FB_DELETE(pPtr)\
	FBKernal_DefaultAllocator()->Delete(pPtr);\
	pPtr = 0;

#define FB_MALLOC(dwSize, dwCount, bDump)\
	FBKernal_DefaultAllocator()->Malloc(dwSize, dwCount, bDump);
#define FB_FREE(pPtr)\
	FBKernal_DefaultAllocator()->Free(pPtr);\
	pPtr = 0;

#endif