#ifndef _FBKernal_BitArray_h_
#define _FBKernal_BitArray_h_

#define FBKernal_BitArray_Bits2Bytes(nBits)\
	((nBits) / 8 + (((nBits) % 8) == 0 ? 0 : 1))

class CFBKernal_BitArray
{
protected:
	void Clear(void)
	{
	}

public:
	CFBKernal_BitArray()
	{
		Clear();
	}
	~CFBKernal_BitArray()
	{
		Clear();
	}

	void Release(void)
	{
		m_Array.Release();
	}
	
	void Set(int nIndex, BYTE byTrue)
	{
		FBKernal_Assert(byTrue == 0 || byTrue == 1);

		int nOld = m_Array.m_dwSize;
		BYTE *pPtr = &m_Array[nIndex / 8];
		int nNew = m_Array.m_dwSize;

		for(int n = nOld; n < nNew; n++)
		{
			m_Array[n] = 0;
		}
	
		nIndex = nIndex % 8;
		if ( byTrue )
		{
			_asm
			{
				mov edx, pPtr;
				mov ecx, nIndex;
				mov al, byte ptr[edx];
				mov ebx, 0x80;
				shr ebx, cl;
				mov ecx, ebx;
				and ecx, eax;
				or  eax, ebx;
				mov byte ptr[edx], al;
			}
		}
		else
		{
			_asm
			{
				mov edx, pPtr;
				mov ecx, nIndex;
				mov al, byte ptr[edx];
				mov ebx, 0x80;
				shr ebx, cl;
				mov ecx, ebx;
				and ecx, eax;
				not ebx;
				and eax, ebx;
				mov byte ptr [edx], al;
			}
		}
	}
	BOOL Get(int nIndex)
	{
		int nOld = m_Array.m_dwSize;
		BYTE byTemp = m_Array[nIndex / 8];
		int nNew = m_Array.m_dwSize;

		for(int n = nOld; n < nNew; n++)
		{
			m_Array[n] = 0;
		}

		byTemp = (byTemp >> (7 - nIndex % 8)) & 0x01;
		return (BOOL)byTemp;
	}

	int Dessamble(int nCount, BYTE* pPtr)
	{
		CopyMemory(pPtr, m_Array.m_pPtr, nCount);
		return m_Array.m_dwSize;
	}

	void Assamble(int nCount, BYTE* pPtr)
	{
		m_Array.Resize(nCount);
		CopyMemory(m_Array.m_pPtr, pPtr, nCount);
	}

	void Equal(CFBKernal_BitArray* pSrc)
	{
		m_Array.Resize(pSrc->m_Array.m_dwSize);
		CopyMemory(m_Array.m_pPtr, pSrc->m_Array.m_pPtr, sizeof(BYTE) * pSrc->m_Array.m_dwSize);
	}

public:
	CFBKernal_Vector<BYTE, false>				m_Array;
};

#endif