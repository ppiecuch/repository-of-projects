#ifndef _FBKernal_Helper_h_
#define _FBKernal_Helper_h_

// ���ظ����˶����ֽڣ�����\0
inline DWORD FBKernal_Helper_StringCopy(char* pDest, char* pSrc, DWORD dwDestSize)
{
	DWORD dwRet = (DWORD)min(strlen(pSrc) + 1, dwDestSize);
	CopyMemory(pDest, pSrc, dwRet);
	pDest[dwDestSize - 1] = '\0';
	return dwRet;
}
// ���ظ����˶����ֽڣ�����\0
inline DWORD FBKernal_Helper_StringMallocCopy(char** pDest, char* pSrc, CFBKernal_Allocator* pAllocator = 0)
{
	CFBKernal_Allocator* pAllc;
	if(pAllocator == 0)
	{
		pAllc = FBKernal_DefaultAllocator();
	}
	else
	{
		pAllc = pAllocator;
	}

	if(*pDest)
	{
		pAllc->Free(*pDest);
	}
	DWORD dwRet = (DWORD)strlen(pSrc) + 1;
	*pDest = (char*)pAllc->Malloc(sizeof(char), dwRet, false);
	CopyMemory(*pDest, pSrc, dwRet);
	return dwRet;
}

// ���ظ����˶����ֽڣ�����\0
inline DWORD FBKernal_Helper_StringPack(char* pDest, DWORD dwDestSize, DWORD dwSegments, ...)
{
	DWORD dwOffset = 0;
	va_list List;

	va_start(List, dwSegments);
	for(DWORD n = 0; n < dwSegments; n++)
	{
		dwOffset += FBKernal_Helper_StringCopy(pDest + dwOffset, va_arg(List, char*), dwDestSize - dwOffset);
		if(dwOffset == dwDestSize)
		{
			break;
		}
	}
	va_end(List); 
	return dwOffset;
}
inline void FBKernal_Helper_StringUnpack(char* pSrc, DWORD dwSegments, ...)
{
	char* pDest;
	DWORD dwDestSize;
	va_list List;

	va_start(List, dwSegments);
	for(DWORD n = 0; n < dwSegments; n++)
	{
		pDest = va_arg(List, char*);
		dwDestSize = va_arg(List, DWORD);

		FBKernal_Helper_StringCopy(pDest, pSrc, dwDestSize);
		pSrc += strlen(pSrc) + 1;
	}
	va_end(List); 
}
inline void FBKernal_Helper_StringUnpackPtr(char* pSrc, DWORD dwSegments, ...)
{
	char** pDest;
	va_list List;

	va_start(List, dwSegments);
	for(DWORD n = 0; n < dwSegments; n++)
	{
		pDest = va_arg(List, char**);

		*pDest = pSrc;
		pSrc += strlen(pSrc) + 1;
	}
	va_end(List); 
}

inline BOOL FBKernal_Helper_CharValid(char cSrc)
{
	if(cSrc != ' ' && cSrc != '\t' && cSrc != '\n' && cSrc != '\0')
	{
		return true;
	}
	return false;
}
inline BOOL FBKernal_Helper_StringValid(char* pSrc)
{
	if(pSrc == 0)
	{
		return false;
	}
	if(pSrc[0] == 0)
	{
		return false;
	}

	while(*pSrc)
	{
		if(*pSrc != ' ' && *pSrc != '\t' && *pSrc != '\n' && *pSrc != '\0')
		{
			return true;
		}
		pSrc++;
	}
	return false;
}

inline char* FBKernal_Helper_CullHInvalid(char* pSrc)
{
	DWORD dwLen = (DWORD)strlen(pSrc);
	for(DWORD n = 0; n < dwLen; n++)
	{
		if(pSrc[n] != '\n' && pSrc[n] != '\t' && pSrc[n] != '\0' && pSrc[n] != ' ')
		{
			return pSrc + n;
		}
	}
	return 0;
}
inline char* FBKernal_Helper_CullTInvalid(char* pSrc)
{
	DWORD dwLen = (DWORD)strlen(pSrc);
	for(DWORD n = dwLen - 1; n >= 0; n--)
	{
		if(pSrc[n] != '\n' && pSrc[n] != '\t' && pSrc[n] != '\0' && pSrc[n] != ' ')
		{
			pSrc[n + 1] = '\0';
			break;
		}
	}
	return pSrc;
}
inline char* FBKernal_Helper_CullHTInvalid(char* pSrc)
{
	DWORD dwLen = (DWORD)strlen(pSrc);
	for(DWORD n = dwLen - 1; n >= 0; n--)
	{
		if(pSrc[n] != '\n' && pSrc[n] != '\t' && pSrc[n] != '\0' && pSrc[n] != ' ')
		{
			pSrc[n + 1] = '\0';
			break;
		}
	}
	for(n = 0; n < dwLen; n++)
	{
		if(pSrc[n] != '\n' && pSrc[n] != '\t' && pSrc[n] != '\0' && pSrc[n] != ' ')
		{
			return pSrc + n;
		}
	}
	return 0;
}

inline BOOL FBKernal_Helper_IsNumberOrLowEnglish(char* pSrc)
{
	DWORD dwLen = (DWORD)strlen(pSrc);
	if(dwLen == 0)
	{
		return false;
	}

	for(DWORD n = 0; n < dwLen; n++)
	{
		if((pSrc[n] < '0' || pSrc[n] > '9') && (pSrc[n] < 'a' || pSrc[n] > 'z'))
		{
			return false;
		}
	}
	return true;
}

inline BOOL FBKernal_Helper_StringIncludingGap(char* pSrc)
{
	int nLen = (int)strlen(pSrc);
	for(int n = 0; n < nLen; n++)
	{
		if(pSrc[n] == ' ' || pSrc[n] == '\n' || pSrc[n] == '\t')
		{
			return false;
		}
	}
	return true;
}

inline BOOL FBKernal_Hepler_IncludingEnglish(char* pSrc)
{
	DWORD dwLen = (DWORD)strlen(pSrc);
	if(dwLen == 0)
	{
		return false;
	}

	for(DWORD n = 0; n < dwLen; n++)
	{
		if((pSrc[n] >= 'a' && pSrc[n] <= 'z') || (pSrc[n] >= 'A' && pSrc[n] <= 'Z'))
		{
			return true;
		}
	}
	return false;
}

#endif