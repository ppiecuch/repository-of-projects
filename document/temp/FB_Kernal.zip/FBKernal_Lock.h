#ifndef _FBKernal_Lock_h_
#define _FBKernal_Lock_h_

#include "FBKernal_Assert.h"

class CFBKernal_Lock
{
protected:
	CRITICAL_SECTION		m_Section;

public:
	CFBKernal_Lock()
	{
		InitializeCriticalSection(&m_Section);
	}
	virtual ~CFBKernal_Lock()
	{
		DeleteCriticalSection(&m_Section);
	}

	void Lock(void)
	{
		EnterCriticalSection(&m_Section);
	}
	void Unlock(void)
	{
		LeaveCriticalSection(&m_Section);
	}
};

#endif