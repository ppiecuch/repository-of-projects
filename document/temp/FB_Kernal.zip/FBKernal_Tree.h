#ifndef _FBKernal_Tree_h_
#define _FBKernal_Tree_h_

#include "FBKernal_Assert.h"

template<class Owner>
class CFBKernal_TreeNode : public CFBKernal_LinkNode<Owner>
{
protected:
	void Clear(void);

public:
	CFBKernal_TreeNode();
	~CFBKernal_TreeNode();

public:
	Owner*									m_pFather;
	CFBKernal_Link<Owner>					m_Child;
};

template<class Owner>
void CFBKernal_TreeNode<Owner>::Clear(void)
{
	m_pFather = 0;
}

template<class Owner>
CFBKernal_TreeNode<Owner>::CFBKernal_TreeNode()
{
	Clear();
}

template<class Owner>
CFBKernal_TreeNode<Owner>::~CFBKernal_TreeNode()
{
	Clear();
}

template<class Type>
class CFBKernal_Tree
{
protected:
	void Clear(void);

public:
	CFBKernal_Tree();
	~CFBKernal_Tree();

	void AddChild(Type* pFather, Type* pNode);
	Type* GetHead(void);

	int GetSize(void);

	//void Attach(Type* pFather, Type* pNode);
	//CFBKernal_Tree<Type>* Detch(Type* pNode);

	BOOL BrowseF(Type* pNode, BOOL (CALLBACK* pCallBack)(Type*, void*), void* pUserData);
	BOOL BrowseL(Type* pNode, BOOL (CALLBACK* pCallBack)(Type*, void*), void* pUserData);

private:
	Type*				m_pHead;
	int					m_nSize;
};

template<class Type>
void CFBKernal_Tree<Type>::Clear(void)
{
	m_pHead = 0;
	m_nSize = 0;
}

template<class Type>
CFBKernal_Tree<Type>::CFBKernal_Tree()
{
	Clear();
}

template<class Type>
CFBKernal_Tree<Type>::~CFBKernal_Tree()
{
	Clear();
}

template<class Type>
void CFBKernal_Tree<Type>::AddChild(Type* pFather, Type* pNode)
{
	FBKernal_Assert(pNode);

	if(!pFather)
	{
		FBKernal_Assert(!m_pHead);

		m_pHead = pNode;
	}
	else
	{
		FBKernal_Assert(m_pHead);

		pNode->m_pFather = pFather;
		pFather->m_Child.InsertA(0, pNode);
	}

	m_nSize++;
}
template<class Type>
Type* CFBKernal_Tree<Type>::GetHead(void)
{
	return m_pHead;
}

template<class Type>
int CFBKernal_Tree<Type>::GetSize(void)
{
	return m_nSize;
}

//template<class Type>
//void CFBKernal_Tree<Type>::Attach(Type* pFather, Type* pNode)
//{
//	FBKernal_Assert(pFather && pNode);
//	
//	pFather->m_pChilds.InsertA(0, pNode);
//	pNode->m_pFather = pFather;
//}
//template<class Type>
//CFBKernal_Tree<Type>* CFBKernal_Tree<Type>::Detch(Type* pNode)
//{
//	// ���pNode��head�ͷ���
//	if(!pNode->m_pFather)
//	{
//		return 0;
//	}
//
//	pNode->m_pFather->m_pChilds.Delete(pNode);
//	pNode->m_pFather = 0;
//
//	CFBKernal_Tree<Type>* pTree = new CFBKernal_Tree<Type>;
//	pTree->AddChild(0, pNode);
//}

template<class Type>
BOOL CFBKernal_Tree<Type>::BrowseF(Type* pNode, BOOL (CALLBACK* pCallBack)(Type*, void*), void* pUserData)
{
	if(!(*pCallBack)(pNode, pUserData))
	{
		return false;
	}

	Type* pNodeNext;
	Type* pNodeIt = pNode->m_Child.GetHead();
	while(pNodeIt)
	{
		pNodeNext = pNodeIt->m_pNext;
		if(!BrowseF(pNodeIt, pCallBack, pUserData))
		{
			return false;
		}
		pNodeIt = pNodeNext;
	}
	return true;
}
template<class Type>
BOOL CFBKernal_Tree<Type>::BrowseL(Type* pNode, BOOL (CALLBACK* pCallBack)(Type*, void*), void* pUserData)
{
	Type* pNodeNext;
	Type* pNodeIt = pNode->m_Child.GetHead();
	while(pNodeIt)
	{
		pNodeNext = pNodeIt->m_pNext;
		if(!BrowseL(pNodeIt, pCallBack, pUserData))
		{
			return false;
		}
		pNodeIt = pNodeNext;
	}

	if(!(*pCallBack)(pNode, pUserData))
	{
		return false;
	}
	return true;
}

#endif

