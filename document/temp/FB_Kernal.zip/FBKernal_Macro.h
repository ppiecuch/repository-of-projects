#ifndef _FBKernal_Macro_h_
#define _FBKernal_Macro_h_

#define		FBKERNAL_STRING_IP				16
#define		FBKERNAL_STRING_SMALL			256
#define		FBKERNAL_STRING_NORMAL			512
#define		FBKERNAL_STRING_LARGE			1024
#define		FBKERNAL_STRING_HUGE			4096
#define		FBKERNAL_STRING_VERYHUGE		8192

#define		FBKERNAL_LOCK_SYSTEM			0
#define		FBKERNAL_LOCK_USER				128

#endif