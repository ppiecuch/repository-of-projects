#ifndef _FBKernal_Port_h_
#define _FBKernal_Port_h_

#include "FBKernal_CallStack.h"
#include "FBKernal_Dump.h"
#include "FBKernal_HashMap.h"
#include "FBKernal_Vector.h"
#include "FBKernal_List.h"
#include "FBKernal_Pool.h"
#include "FBKernal_Allocator.h"
#include "FBKernal_Lock.h"
#include "FBKernal_STLAllocator.h"
#include "FBKernal_Helper.h"
#include "FBKernal_Macro.h"
#include "FBKernal_INIFile.h"
#include "FBKernal_Service.h"

#include "FBKernal_Assert.h"
#include "FBKernal_Memory.h"
#include "FBKernal_Link.h"
#include "FBKernal_Array.h"
#include "FBKernal_Tree.h"
#include "FBKernal_Float.h"
#include "FBKernal_String.h"
#include "FBKernal_File.h"
#include "FBKernal_INI.h"
#include "FBKernal_Random.h"
#include "FBKernal_Timer.h"
#include "FBKernal_HashTable.h"
#include "FBKernal_FPS.h"
#include "FBKernal_BitArray.h"
#include "FBKernal_IDGenerater.h"
#include "FBKernal_IDBlaster.h"
#include "FBKernal_Log.h"

inline void FBKernal_Init(void)
{
}
inline void FBKernal_Quit(void)
{
}

#pragma comment(lib, "dbghelp.lib")
#ifdef _DEBUG
	#pragma comment(lib, "FB_Kernald.lib")
#else
	#pragma comment(lib, "FB_Kernal.lib")
#endif

#endif