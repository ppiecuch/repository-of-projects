#include "FBKernal_PoolEx.h"
#include "FBKernal_Assert.h"

CFBKernal_PoolEx::CFBKernal_PoolEx(DWORD dwChunkSize)
{
	FBKernal_Assert(dwChunkSize >= 4);

	#ifdef _DEBUG
	m_dwChunkSize = dwChunkSize + sizeof(CFBKernal_PoolEx_Chunk);
	#else
	m_dwChunkSize = dwChunkSize + 4;
	#endif

	m_dwChunksPerBlock = 16;

	m_pBlockHead = 0;

	#ifndef _DEBUG
	m_pNChunkHead = 0;
	#endif
}
CFBKernal_PoolEx::~CFBKernal_PoolEx()
{
	CFBKernal_PoolEx_Block* pNext;
	while(m_pBlockHead)
	{
		pNext = m_pBlockHead->m_pNext;
		free(m_pBlockHead);
		m_pBlockHead = pNext;
	}

	#ifndef _DEBUG
	m_pNChunkHead = 0;
	#endif
}

void* CFBKernal_PoolEx::Malloc(void)
{
	// �Ƿ����һ��block��nchunklist��Ϊ��
	#ifdef _DEBUG
	if(m_pNChunkList.Size() == 0)
	#else
	if(m_pNChunkHead == 0)
	#endif
	{
		if((!m_pBlockHead) || (m_pBlockHead->m_pPtr_Cur == m_pBlockHead->m_pPtr + m_dwChunkSize * m_dwChunksPerBlock))
		{
			// �����µ�block
			m_dwChunksPerBlock *= 2;

			CFBKernal_PoolEx_Block* pBlock = (CFBKernal_PoolEx_Block*)malloc(
				sizeof(CFBKernal_PoolEx_Block) +
				m_dwChunkSize * m_dwChunksPerBlock);
			if(!pBlock)
			{
				return 0;
			}

			pBlock->m_pPtr = (char*)pBlock + sizeof(CFBKernal_PoolEx_Block);
			pBlock->m_pPtr_Cur = pBlock->m_pPtr + m_dwChunkSize;
			((CFBKernal_PoolEx_Chunk*)pBlock->m_pPtr)->m_dwSize = m_dwChunkSize;

			pBlock->m_pNext = m_pBlockHead;
			m_pBlockHead = pBlock;

			#ifdef _DEBUG
			((CFBKernal_PoolEx_Chunk*)pBlock->m_pPtr)->m_pPrev = 0;
			m_pAChunkList.Push_Back((CFBKernal_PoolEx_Chunk*)pBlock->m_pPtr);
			return pBlock->m_pPtr + sizeof(CFBKernal_PoolEx_Chunk);
			#else
			return pBlock->m_pPtr + 4;
			#endif
		}
		else
		{
			// ����ȥ���һ��block�����Ƿ��п��õ�
			char* pRet = m_pBlockHead->m_pPtr_Cur;
			((CFBKernal_PoolEx_Chunk*)pRet)->m_dwSize = m_dwChunkSize;
			m_pBlockHead->m_pPtr_Cur += m_dwChunkSize;

			#ifdef _DEBUG
			((CFBKernal_PoolEx_Chunk*)pRet)->m_pPrev = 0;
			m_pAChunkList.Push_Back((CFBKernal_PoolEx_Chunk*)pRet);
			return pRet + sizeof(CFBKernal_PoolEx_Chunk);
			#else
			return pRet + 4;
			#endif
		}
	}
	else
	{
		// nchunklist�п϶��п���ʹ�õ�
		#ifdef _DEBUG
		CFBKernal_PoolEx_Chunk* pChunk = m_pNChunkList.GetTail();
		m_pNChunkList.Pop(pChunk);
		m_pAChunkList.Push_Back(pChunk);
		return pChunk + 1;
		#else
		char* pRet = (char*)m_pNChunkHead;
		m_pNChunkHead = m_pNChunkHead->m_pNext;
		return pRet + 4;
		#endif
	}
	return 0;
}
void CFBKernal_PoolEx::Free(void* pPtr)
{
	if(!pPtr)
	{
		return;
	}

	#ifdef _DEBUG
	CFBKernal_PoolEx_Chunk* pChunk = (CFBKernal_PoolEx_Chunk*)pPtr - 1;
	m_pAChunkList.Pop(pChunk);
	m_pNChunkList.Push_Back(pChunk);
	#else
	CFBKernal_PoolEx_Chunk* pTemp = (CFBKernal_PoolEx_Chunk*)((char*)pPtr - 4);
	pTemp->m_pNext = m_pNChunkHead;
	m_pNChunkHead = pTemp;
	#endif
}

void* CFBKernal_PoolRealEx::Malloc(DWORD dwSize)
{
	#ifdef _DEBUG
	CFBKernal_PoolEx_Chunk* pChunk = (CFBKernal_PoolEx_Chunk*)malloc(dwSize + sizeof(CFBKernal_PoolEx_Chunk));
	pChunk->m_dwSize = dwSize;
	pChunk->m_pPrev = 0;
	m_pAChunkList.Push_Back(pChunk);
	return pChunk + 1;
	#else
	DWORD* pPtr = (DWORD*)malloc(dwSize + 4);
	*pPtr = dwSize;
	return pPtr + 1;
	#endif
}
void CFBKernal_PoolRealEx::Free(void* pPtr)
{
	if(!pPtr)
	{
		return;
	}

	#ifdef _DEBUG
	CFBKernal_PoolEx_Chunk* pChunk = (CFBKernal_PoolEx_Chunk*)pPtr - 1;
	m_pAChunkList.Pop(pChunk);
	free(pChunk);
	#else
	free((char*)pPtr - 4);
	#endif
}
