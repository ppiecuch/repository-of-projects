#ifndef _FBKernal_IDGenerater_h_
#define _FBKernal_IDGenerater_h_

class CFBKernal_IDGenerater
{
public:
	CFBKernal_IDGenerater(void)
	{
	}
	~CFBKernal_IDGenerater()
	{
	}

	void SetStartID(char* pFilename, DWORD dwStartID)
	{
		FBKernal_Assert(dwStartID > 0);

		m_pFilename[0] = '\0';
		m_dwNowValidID = dwStartID;
		m_fFile = 0;

		if(pFilename)
		{
			strcpy(m_pFilename, pFilename);
			m_fFile = fopen(m_pFilename, "rb");
			if(!m_fFile)
			{
				return;
			}
			fread(&m_dwNowValidID, sizeof(DWORD), 1, m_fFile);
			fclose(m_fFile);
		}
	}

	DWORD QueryValidID(void)
	{
		DWORD dwRet = m_dwNowValidID++;
		if(FBKernal_String_IsValid(m_pFilename))
		{
			m_fFile = fopen(m_pFilename, "wb");
			if(!m_fFile)
			{
				return 0;
			}
			fwrite(&m_dwNowValidID, sizeof(DWORD), 1, m_fFile);
			fclose(m_fFile);
		}
		return dwRet;
	}

public:
	DWORD		m_dwNowValidID;
	FILE*		m_fFile;
	char		m_pFilename[256];
};

#endif
