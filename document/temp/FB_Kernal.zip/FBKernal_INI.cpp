#include "FBKernal_INI.h"

void CFBKernal_INI_KeyAndValue::Clear(void)
{
}

CFBKernal_INI_KeyAndValue::CFBKernal_INI_KeyAndValue()
{
	Clear();
}
CFBKernal_INI_KeyAndValue::~CFBKernal_INI_KeyAndValue()
{
	Clear();
}

void CFBKernal_INI_KeyAndValue::Release(void)
{
	m_Key.Release();
	m_Value.Release();
}

void CFBKernal_INI_Section::Clear(void)
{
}

CFBKernal_INI_Section::CFBKernal_INI_Section()
{
	Clear();
}
CFBKernal_INI_Section::~CFBKernal_INI_Section()
{
	Clear();
}

void CFBKernal_INI_Section::Release(void)
{
	m_Section.Release();
	
	CFBKernal_INI_KeyAndValue* pNode;
	while(pNode = m_KeyAndValue.GetHead())
	{
		m_KeyAndValue.Delete(pNode);
		pNode->Release();
		FB_Delete(pNode);
	}
	m_KeyAndValueHT.Release();
}

void CFBKernal_INI::Clear(void)
{
	m_nBufferSize = 0;
	m_pBuffer = 0;
}

CFBKernal_INI::CFBKernal_INI()
{
	Clear();
}
CFBKernal_INI::~CFBKernal_INI()
{
	Clear();
}

void CFBKernal_INI::Release(void)
{
	FB_Delete(m_pBuffer);
	m_Filename.Release();

	CFBKernal_INI_Section* pNode;
	while(pNode = m_Section.GetHead())
	{
		m_Section.Delete(pNode);
		pNode->Release();
		FB_Delete(pNode);
	}
	m_SectionHT.Release();
}

void CFBKernal_INI::SetBuffer(int nSize)
{
	if(m_nBufferSize < nSize)
	{
		FB_Delete(m_pBuffer);
		m_pBuffer = FB_New(char, nSize);
		m_nBufferSize = nSize;
	}
}
BOOL CFBKernal_INI::SetFileName(char* pPath, char* pFilename)
{
	m_Filename.Equal(pPath);
	m_Filename.Attach(pFilename);

	if(!FBKernal_File_IsExist(m_Filename.Ptr()))
	{
		char msg[256];
		sprintf(msg, "�޷����ļ� %s", pFilename);
		FBKernal_MessageBox(msg);
		return false;
	}
	return true;
}

int CFBKernal_INI::GetInt(char* pSection, char* pKey, int nDefault)
{
	return GetPrivateProfileInt(
		pSection,
		pKey,
		nDefault,
		m_Filename.Ptr());
}
void CFBKernal_INI::SetInt(char* pSectoin, char* pKey, int nValue)
{
}

char* CFBKernal_INI::GetString(char* pSection, char* pKey, char* pDefault)
{
	GetPrivateProfileString(
		pSection,
		pKey,
		pDefault,
		m_pBuffer,
		m_nBufferSize,
		m_Filename.Ptr());
	return m_pBuffer;
}
void CFBKernal_INI::SetString(char* pSection, char* pKey, char* pValue)
{
}

void CFBKernal_INI::EnumAll(void)
{
	// �õ��ļ���С��Ϊbuffer��С
	FILE* file = fopen(m_Filename.Ptr(), "rb");
	SetBuffer(filelength(fileno(file)));
	fclose(file);

	// �õ����е�section
	DWORD dwLen = GetPrivateProfileSectionNames(
		m_pBuffer,
		m_nBufferSize,
		m_Filename.Ptr());

	// ����
	int nLastPos = 0;
	for(DWORD l = 0; l < dwLen; l++)
	{
		if(m_pBuffer[l] == 0)
		{
			CFBKernal_INI_Section* pSection = FB_New(CFBKernal_INI_Section, 1);
			pSection->m_Section.Equal(m_pBuffer + nLastPos);
			m_Section.InsertA(0, pSection);
			m_SectionHT.Push(m_pBuffer + nLastPos, (DWORD)(DWORD_PTR)pSection);

			nLastPos = l + 1;
		}
	}

	// �õ�ÿ��section�������е�value
	CFBKernal_INI_Section* pSection = m_Section.GetHead();
	CFBKernal_INI_KeyAndValue* pKeyAndValue = 0;
	while(pSection)
	{
		dwLen = GetPrivateProfileSection(
			pSection->m_Section.Ptr(),
			m_pBuffer,
			m_nBufferSize,
			m_Filename.Ptr());

		// ����
		int nSwitch = 0;
		int nLastPos = 0;
		for(DWORD l = 0; l < dwLen; l++)
		{
			switch(nSwitch)
			{
			case 0:
				if(m_pBuffer[l] == '=')
				{
					m_pBuffer[l] = '\0';

					pKeyAndValue = FB_New(CFBKernal_INI_KeyAndValue, 1);
					pKeyAndValue->m_Key.Equal(m_pBuffer + nLastPos);

					nLastPos = l + 1;
					nSwitch = 1;
				}
				break;

			case 1:
				if(m_pBuffer[l] == 0)
				{
					m_pBuffer[l] = '\0';

					pKeyAndValue->m_Value.Equal(m_pBuffer + nLastPos);

					pSection->m_KeyAndValue.InsertA(0, pKeyAndValue);
					pSection->m_KeyAndValueHT.Push(pKeyAndValue->m_Key.Ptr(), (DWORD)(DWORD_PTR)pKeyAndValue);
					pKeyAndValue = 0;

					nLastPos = l + 1;
					nSwitch = 0;
				}
				break;
			default:
				break;
			}
		}
		pSection = pSection->m_pNext;
	}
}

CFBKernal_INI_Section* CFBKernal_INI::QuerySection(char* pSection)
{
	return (CFBKernal_INI_Section*)m_SectionHT.Seek(pSection);
}

char* CFBKernal_INI::QueryString(CFBKernal_INI_Section* pSection, char* pKey, char* pDefault)
{
	CFBKernal_INI_KeyAndValue* pKeyAndValue = (CFBKernal_INI_KeyAndValue*)pSection->m_KeyAndValueHT.Seek(pKey);
	if(pKeyAndValue)
	{
		return pKeyAndValue->m_Value.Ptr();
	}
	return pDefault;
}
int CFBKernal_INI::QueryInt(CFBKernal_INI_Section* pSection, char* pKey, int nDefault)
{
	CFBKernal_INI_KeyAndValue* pKeyAndValue = (CFBKernal_INI_KeyAndValue*)pSection->m_KeyAndValueHT.Seek(pKey);
	if(pKeyAndValue)
	{
		return atoi(pKeyAndValue->m_Value.Ptr());
	}
	return nDefault;
}
float CFBKernal_INI::QueryFloat(CFBKernal_INI_Section* pSection, char* pKey, float fDefault)
{
	CFBKernal_INI_KeyAndValue* pKeyAndValue = (CFBKernal_INI_KeyAndValue*)pSection->m_KeyAndValueHT.Seek(pKey);
	if(pKeyAndValue)
	{
		return (float)atof(pKeyAndValue->m_Value.Ptr());
	}
	return fDefault;
}

BOOL FBKernal_INI_ReadTableFile(char* pFilename, int (CALLBACK* pCallBack)(char* pRes, int nLine, BOOL bNewLine, int nSegment))
{
	// ���Ʊ����ļ�����
	FILE* file = fopen(pFilename, "r");
	if(!file)
	{
		char msg[256];
		sprintf(msg, "�޷����ļ� %s", pFilename);
		FBKernal_MessageBox(msg);
		return false;
	}

	char pSegTemp[256];
	char pLineTemp[1024];

	int nLastLine = -1;
	int nNowLine = 0;

	while(1)
	{
		if(FBkernal_File_IsEof(file))
		{
			break;
		}

		// ����һ��
		fgets(pLineTemp, 1024, file);

		// ������һ��
		char* pStart = pLineTemp;
		char* pEnd;
		int nNowSeg = 0;
		CFBKernal_INI_Section* pSection = 0;
		while(1)
		{
			// �ҵ���һ�� /t ��λ��
			pEnd = strstr(pStart, "\t");
			if(!pEnd)
			{
				pEnd = strstr(pStart, "\n");
				if(!pEnd)
				{
					break;
				}
			}
			CopyMemory(pSegTemp, pStart, pEnd - pStart);
			pSegTemp[pEnd - pStart] = '\0';
			pEnd++;

			int nRet = pCallBack(pSegTemp, nNowLine, (nNowLine != nLastLine), nNowSeg);
			
			if(nRet == -1)
			{
				break;
			}
			else if(nRet == 0)
			{
				goto _end;
			}

			pStart = pEnd;
			nNowSeg++;
			nLastLine = nNowLine;
		}
		nNowLine++;
	}
_end:
	fclose(file);
	return true;
}