#ifndef _FBKernal_INIFile_h_
#define _FBKernal_INIFile_h_

#include "FBKernal_Vector.h"

class CFBKernal_INIFile_State_Section
{
public:
	char*				m_pBValid;
	char*				m_pEValid;

public:
	CFBKernal_INIFile_State_Section()
	{
		m_pBValid = 0;
		m_pEValid = 0;
	}
};

template<class MemType = CFBKernal_Allocator>
class CFBKernal_INIFile_Section
{
public:
	CFBKernal_HashMap<
		char*, 
		CFBKernal_HashMap_Hash<char*>, 
		CFBKernal_HashMap_Comp<char*> >		m_KeyValue;
	
	CFBKernal_INIFile_Section*				m_pNext;

public:
	~CFBKernal_INIFile_Section();

	void Release(void);

	char* QueryString(char* pKey, char* pDefault);
	int QueryInt(char* pKey, int nDefault);
	float QueryFloat(char* pKey, float fDefault);
	double QueryDouble(char* pKey, double dDefault);
	DWORD QueryDWORD(char* pKey, DWORD dwDefault);
	WORD QueryWORD(char* pKey, WORD wDefault);
	BOOL QueryBOOL(char* pKey, BOOL bDefault);
	BYTE QueryBYTE(char* pKey, BYTE byDefault);
};

template<class MemType>
CFBKernal_INIFile_Section<MemType>::~CFBKernal_INIFile_Section()
{
	Release();
}

template<class MemType>
void CFBKernal_INIFile_Section<MemType>::Release(void)
{
	m_KeyValue.Release();
}

template<class MemType>
char* CFBKernal_INIFile_Section<MemType>::QueryString(char* pKey, char* pDefault)
{
	char* pRet = (char*)(DWORD_PTR)m_KeyValue.Find(pKey);
	if(!pRet)
	{
		return pDefault;
	}
	return pRet;
}
template<class MemType>
int CFBKernal_INIFile_Section<MemType>::QueryInt(char* pKey, int nDefault)
{
	char* pRet = (char*)(DWORD_PTR)m_KeyValue.Find(pKey);
	if(!pRet)
	{
		return nDefault;
	}
	return atoi(pRet);
}
template<class MemType>
float CFBKernal_INIFile_Section<MemType>::QueryFloat(char* pKey, float fDefault)
{
	char* pRet = (char*)(DWORD_PTR)m_KeyValue.Find(pKey);
	if(!pRet)
	{
		return fDefault;
	}
	return (float)atof(pRet);
}
template<class MemType>
double CFBKernal_INIFile_Section<MemType>::QueryDouble(char* pKey, double dDefault)
{
	char* pRet = (char*)(DWORD_PTR)m_KeyValue.Find(pKey);
	if(!pRet)
	{
		return dDefault;
	}
	return atof(pRet);
}
template<class MemType>
DWORD CFBKernal_INIFile_Section<MemType>::QueryDWORD(char* pKey, DWORD dwDefault)
{
	char* pRet = (char*)(DWORD_PTR)m_KeyValue.Find(pKey);
	if(!pRet)
	{
		return dwDefault;
	}
	return (DWORD)atoi(pRet);
}
template<class MemType>
WORD CFBKernal_INIFile_Section<MemType>::QueryWORD(char* pKey, WORD wDefault)
{
	char* pRet = (char*)(DWORD_PTR)m_KeyValue.Find(pKey);
	if(!pRet)
	{
		return wDefault;
	}
	return (WORD)atoi(pRet);
}
template<class MemType>
BOOL CFBKernal_INIFile_Section<MemType>::QueryBOOL(char* pKey, BOOL bDefault)
{
	char* pRet = (char*)(DWORD_PTR)m_KeyValue.Find(pKey);
	if(!pRet)
	{
		return bDefault;
	}
	return (BOOL)atoi(pRet);
}
template<class MemType>
BYTE CFBKernal_INIFile_Section<MemType>::QueryBYTE(char* pKey, BYTE byDefault)
{
	char* pRet = (char*)(DWORD_PTR)m_KeyValue.Find(pKey);
	if(!pRet)
	{
		return byDefault;
	}
	return (BYTE)atoi(pRet);
}

template<class MemType = CFBKernal_Allocator>
class CFBKernal_INIFile
{
protected:
	enum STATE
	{
		S_FLOW,
		S_SECTION,
		S_KEY,
		S_VALUE,
	};

protected:
	void Clear(void);

public:
	DWORD													m_dwLen;
	char*													m_pBuffer;

	CFBKernal_HashMap<
		char*, 
		CFBKernal_HashMap_Hash<char*>, 
		CFBKernal_HashMap_Comp<char*> >						m_Section;

	CFBKernal_INIFile_Section<MemType>*						m_pHead;

public:
	CFBKernal_INIFile();
	~CFBKernal_INIFile();

	BOOL Load(char* pFilename);
	void Unload(void);

	CFBKernal_INIFile_Section<MemType>*	QuerySection(char* pSection);
};

template<class MemType>
void CFBKernal_INIFile<MemType>::Clear(void)
{
	m_pBuffer = 0;
	m_pHead = 0;
}

template<class MemType>
CFBKernal_INIFile<MemType>::CFBKernal_INIFile()
{
	Clear();
}
template<class MemType>
CFBKernal_INIFile<MemType>::~CFBKernal_INIFile()
{
	Unload();
}

template<class MemType>
BOOL CFBKernal_INIFile<MemType>::Load(char* pFilename)
{
	FILE* file = fopen(pFilename, "r");
	if(!file)
	{
		return false;
	}
	m_dwLen = filelength(fileno(file));
	m_pBuffer = (char*)FB_MALLOC(sizeof(char), m_dwLen, false);
	m_dwLen = (DWORD)fread(m_pBuffer, sizeof(char), m_dwLen, file);
	m_pBuffer[m_dwLen] = '\n';
	m_dwLen++;
	fclose(file);

	// ��ʼ����
	char* pSection;
	char* pKey;
	char* pValue;
	STATE State = S_FLOW;
	CFBKernal_INIFile_Section<MemType>* pSectionNow = 0;
	for(DWORD n = 0; n < m_dwLen; n++)
	{
		switch(State)
		{
		case S_FLOW:
			if(FBKernal_Helper_CharValid(m_pBuffer[n]))
			{
				if(m_pBuffer[n] == '[')
				{
					pSection = m_pBuffer + n + 1;
					State = S_SECTION;
				}
				else
				{
					pKey = m_pBuffer + n;
					State = S_KEY;
				}
			}
			break;
		case S_SECTION:
			if(m_pBuffer[n] == '\n')
			{
				return false;
			}
			if(m_pBuffer[n] == ']')
			{
				// �ų�[]�����
				if(pSection > m_pBuffer + n - 1)
				{
					return false;
				}
				m_pBuffer[n] = '\0';
				// ȥͷβ
				pSection = FBKernal_Helper_CullHTInvalid(pSection);

				pSectionNow = FB_NEW(CFBKernal_INIFile_Section<MemType>, 1, false);
				pSectionNow->m_pNext = m_pHead;
				m_pHead = pSectionNow;
				m_Section.Push(pSection, (DWORD)(DWORD_PTR)pSectionNow);

				State = S_FLOW;
			}
			break;
		case S_KEY:
			if(m_pBuffer[n] == '=')
			{
				m_pBuffer[n] = '\0';
				// ȥͷβ
				pKey = FBKernal_Helper_CullHTInvalid(pKey);

				pValue = m_pBuffer + n + 1;
				State = S_VALUE;
			}
			else if(m_pBuffer[n] == '\n')
			{
				State = S_FLOW;
			}
			break;
		case S_VALUE:
			if(m_pBuffer[n] == '\n')
			{
				m_pBuffer[n] = '\0';
				// ȥͷβ
				pValue = FBKernal_Helper_CullHTInvalid(pValue);
				if(pSectionNow)
				{
					pSectionNow->m_KeyValue.Push(pKey, (DWORD)(DWORD_PTR)pValue);
				}
				State = S_FLOW;
			}
			break;
		}
	}
	return true;
}
template<class MemType>
void CFBKernal_INIFile<MemType>::Unload(void)
{
	FB_FREE(m_pBuffer);

	CFBKernal_INIFile_Section<MemType>* pNext;
	CFBKernal_INIFile_Section<MemType>* pNode = m_pHead;
	while(pNode)
	{
		pNext = pNode->m_pNext;
		pNode->Release();
		FB_DELETE(pNode);
		pNode = pNext;
	}

	m_Section.Release();
	Clear();
}

template<class MemType>
CFBKernal_INIFile_Section<MemType>*	CFBKernal_INIFile<MemType>::QuerySection(char* pSection)
{
	return (CFBKernal_INIFile_Section<MemType>*)(DWORD_PTR)m_Section.Find(pSection);
}

#endif