#include "FBKernal_Allocator.h"

CFBKernal_Allocator			g_FBKernal_Allocator_Default(true);
