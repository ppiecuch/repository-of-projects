#ifndef _FBKernal_FPS_h_
#define _FBKernal_FPS_h_

#include "FBKernal_Timer.h"

class CFBKernal_FPS
{
protected:
	void Clear(void)
	{
		m_nTotalPassMS = 0;
		m_nRealFPS = 0;
		m_nLastRealFPS = 0;
		m_nPassMS = 0;
		SetFPS(30);
		m_Timer.GetElapsedTime();
	}

public:
	CFBKernal_FPS()
	{
		Clear();
	}
	~CFBKernal_FPS()
	{
		Clear();
	}

	void SetFPS(int nFPS)
	{
		FBKernal_Assert(nFPS > 0);
		m_nDelayPerFrame = 1000 / nFPS;
	}
	void Process(void)
	{
		int nPassMS = (int)(m_Timer.GetElapsedTime() * 1000);
		m_nTotalPassMS += nPassMS;
		if(nPassMS < m_nDelayPerFrame)
		{
			Sleep(m_nDelayPerFrame - nPassMS);
			m_nTotalPassMS += (int)(m_Timer.GetElapsedTime() * 1000);
			
			m_nPassMS += m_nDelayPerFrame;
		}
		else
		{
			m_nPassMS += nPassMS;
		}

		m_nRealFPS++;
		if(m_nPassMS >= 1000)
		{
			m_nLastRealFPS = m_nRealFPS;
			m_nRealFPS = 0;
			m_nPassMS = 0;
		}
	}
	int GetFPS(void)
	{
		return m_nLastRealFPS;
	}
	int GetTotalPassMS(void)
	{
		return m_nTotalPassMS;
	}

public:
	int							m_nTotalPassMS;
	int							m_nRealFPS;
	int							m_nLastRealFPS;
	int							m_nPassMS;
	int							m_nDelayPerFrame;
	CFBKernal_Timer				m_Timer;
};

#endif