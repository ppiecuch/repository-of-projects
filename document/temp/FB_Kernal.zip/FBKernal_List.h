#ifndef _FBKernal_List_h_
#define _FBKernal_List_h_

#include "FBKernal_Assert.h"

template<class Type>
class CFBKernal_ListNode
{
public:
	Type*      m_pPrev;
	Type*      m_pNext;

public:
	#ifdef _DEBUG
	CFBKernal_ListNode()
	{
		m_pPrev = 0;
	}
	#endif
};

template<class Type>
class CFBKernal_List
{
public:
	CFBKernal_List();

public:
	void Push_Front(Type* pNode);
	void Push_Front(Type* pPos, Type* pNode);

	void Push_Back(Type* pNode);
	void Push_Back(Type* pPos, Type* pNode);

	void Pop(Type* pNode);
	void Pop_All(void);

	DWORD Size(void);
	Type* GetHead(void);
	Type* GetTail(void);

	Type* GetPrev(CFBKernal_ListNode<Type>* pNode);
	Type* GetNext(CFBKernal_ListNode<Type>* pNode);

private:
	Type						m_Head;
	Type						m_Tail;
	DWORD						m_dwSize;
};

template<class Type>
CFBKernal_List<Type>::CFBKernal_List()
{
	m_Head.m_pPrev = 0;
	m_Head.m_pNext = (Type*)&m_Tail;

	m_Tail.m_pPrev = (Type*)&m_Head;
	m_Tail.m_pNext = 0;

	m_dwSize = 0;
}

template<class Type>
void CFBKernal_List<Type>::Push_Front(Type* pNode)
{
	FBKernal_Assert(pNode);
	FBKernal_Assert(!pNode->m_pPrev);

	pNode->m_pPrev = (Type*)&m_Head;
	pNode->m_pNext = m_Head.m_pNext;

	m_Head.m_pNext->m_pPrev = pNode;
	m_Head.m_pNext = pNode;

	m_dwSize++;
}
template<class Type>
void CFBKernal_List<Type>::Push_Front(Type* pPos, Type* pNode)
{
	FBKernal_Assert(pPos);
	FBKernal_Assert(pNode);
	FBKernal_Assert(!pNode->m_pPrev);

	pNode->m_pPrev = pPos->m_pPrev;
	pNode->m_pNext = pPos;

	pPos->m_pPrev->m_pNext = pNode;
	pPos->m_pPrev = pNode;

	m_dwSize++;
}

template<class Type>
void CFBKernal_List<Type>::Push_Back(Type* pNode)
{
	FBKernal_Assert(pNode);
	FBKernal_Assert(!pNode->m_pPrev);

	pNode->m_pNext = (Type*)&m_Tail;
	pNode->m_pPrev = m_Tail.m_pPrev;

	m_Tail.m_pPrev->m_pNext = pNode;
	m_Tail.m_pPrev = pNode;

	m_dwSize++;
}
template<class Type>
void CFBKernal_List<Type>::Push_Back(Type* pPos, Type* pNode)
{
	FBKernal_Assert(pPos);
	FBKernal_Assert(pNode);
	FBKernal_Assert(!pNode->m_pPrev);

	pNode->m_pNext = pPos->m_pNext;
	pNode->m_pPrev = pPos;

	pPos->m_pNext->m_pPrev = pNode;
	pPos->m_pNext = pNode;

	m_dwSize++;
}

template<class Type>
void CFBKernal_List<Type>::Pop(Type* pNode)
{
	FBKernal_Assert(pNode);
	FBKernal_Assert(pNode->m_pPrev);

	pNode->m_pPrev->m_pNext = pNode->m_pNext;
	pNode->m_pNext->m_pPrev = pNode->m_pPrev;

	#ifdef _DEBUG
	pNode->m_pPrev = 0;
	#endif

	m_dwSize--;
}
template<class Type>
void CFBKernal_List<Type>::Pop_All(void)
{
	m_dwSize = 0;
}

template<class Type>
DWORD CFBKernal_List<Type>::Size(void)
{
	return m_dwSize;
}
template<class Type>
Type* CFBKernal_List<Type>::GetHead(void)
{
	return m_Head.m_pNext == &m_Tail ? 0 : m_Head.m_pNext;
}
template<class Type>
Type* CFBKernal_List<Type>::GetTail(void)
{
	return m_Tail.m_pPrev == &m_Head ? 0 : m_Tail.m_pPrev;
}

template<class Type>
Type* CFBKernal_List<Type>::GetPrev(CFBKernal_ListNode<Type>* pNode)
{
	FBKernal_Assert(pNode);
	return pNode->m_pPrev == &m_Head ? 0 : pNode->m_pPrev;
}
template<class Type>
Type* CFBKernal_List<Type>::GetNext(CFBKernal_ListNode<Type>* pNode)
{
	FBKernal_Assert(pNode);
	return pNode->m_pNext == &m_Tail ? 0 : pNode->m_pNext;
}

#endif