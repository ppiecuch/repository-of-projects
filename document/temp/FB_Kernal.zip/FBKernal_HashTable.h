#ifndef _FBKernal_HashTable_h_
#define _FBKernal_HashTable_h_

#include "FBKernal_String.h"
#include "FBKernal_Link.h"

class CFBKernal_HashTableNode : public CFBKernal_LinkNode<CFBKernal_HashTableNode>
{
protected:
	void Clear(void)
	{
		m_dwData = 0;
	}

public:
	CFBKernal_HashTableNode()
	{
		Clear();
	}
	~CFBKernal_HashTableNode()
	{
		Clear();
	}

	void Release(void)
	{
		m_String.Release();
	}

public:
	CFBKernal_String			m_String;
	DWORD						m_dwData;	
};

template<int nSize = 1024>
class CFBKernal_HashTable
{
protected:
	void Clear(void);

public:
	CFBKernal_HashTable();
	~CFBKernal_HashTable();

	void Release(void);

	static DWORD Hash(char* pString);

	void Push(char* pString, DWORD dwData, int nInHash = -1, int* pOutHash = 0);

	DWORD Pop(char* pString, int nInHash = -1, int* pOutHash = 0);
	DWORD Seek(char* pString, int nInHash = -1, int* pOutHash = 0);

public:
	typedef	CFBKernal_Link<CFBKernal_HashTableNode>		_List;
	_List*												m_pList[nSize];
};

template<int nSize>
void CFBKernal_HashTable<nSize>::Clear(void)
{
	ZeroMemory(m_pList, sizeof(CFBKernal_Link<CFBKernal_HashTableNode>*) * nSize);
}

template<int nSize>
CFBKernal_HashTable<nSize>::CFBKernal_HashTable()
{
	Clear();
}
template<int nSize>
CFBKernal_HashTable<nSize>::~CFBKernal_HashTable()
{
	Clear();
}

template<int nSize>
void CFBKernal_HashTable<nSize>::Release(void)
{
	for(int l = 0; l < nSize; l++)
	{
		if(!m_pList[l])
		{
			continue;
		}

		CFBKernal_HashTableNode* pNode;
		while(pNode = m_pList[l]->GetHead())
		{
			m_pList[l]->Delete(pNode);
			pNode->Release();
			FB_Delete(pNode);
		}
		FB_Delete(m_pList[l]);
	}
	Clear();
}

template<int nSize>
DWORD CFBKernal_HashTable<nSize>::Hash(char* pString)
{
	FBKernal_Assert(pString);

	CFBKernal_String Temp;
	Temp.Equal(pString);
	_strupr(Temp.Ptr());

	char* offset = Temp.Ptr();
	DWORD dwValue = 0;
	while(*offset)
	{
		dwValue = (dwValue << 5) + dwValue + *offset++;
	}

	Temp.Release();
	return dwValue % nSize;
}

template<int nSize>
void CFBKernal_HashTable<nSize>::Push(char* pString, DWORD dwData, int nInHash, int* pOutHash)
{
	FBKernal_Assert(pString);

	// debug �鿴�Ƿ��Ѿ�������
	FBKernal_Assert(!Seek(pString));

	if(nInHash == -1)
	{
		nInHash = Hash(pString);
	}

	// ����
	if(!m_pList[nInHash])
	{
		m_pList[nInHash] = FB_New(_List, 1);
	}

	CFBKernal_HashTableNode* pNode = FB_New(CFBKernal_HashTableNode, 1);
	pNode->m_String.Equal(pString);
	pNode->m_dwData = dwData;
	m_pList[nInHash]->InsertA(0, pNode);

	if(pOutHash)
	{
		*pOutHash = nInHash;
	}
}

template<int nSize>
DWORD CFBKernal_HashTable<nSize>::Pop(char* pString, int nInHash, int* pOutHash)
{
	FBKernal_Assert(pString);

	if(nInHash == -1)
	{
		nInHash = Hash(pString);
	}

	if(m_pList[nInHash])
	{
		CFBKernal_HashTableNode* pNode = m_pList[nInHash]->GetHead();
		while(pNode)
		{
			if(pNode->m_String.Icmp(pString) == 0)
			{
				DWORD dwData = pNode->m_dwData;
				m_pList[nInHash]->Delete(pNode);
				pNode->Release();
				FB_Delete(pNode);
				if(pOutHash)
				{
					*pOutHash = nInHash;
				}
				return dwData;
			}
			pNode = pNode->m_pNext;
		}
	}
	if(pOutHash)
	{
		*pOutHash = -1;
	}
	return 0;
}
template<int nSize>
DWORD CFBKernal_HashTable<nSize>::Seek(char* pString, int nInHash, int* pOutHash)
{
	FBKernal_Assert(pString);

	if(nInHash == -1)
	{
		nInHash = Hash(pString);
	}

	if(m_pList[nInHash])
	{
		CFBKernal_HashTableNode* pNode = m_pList[nInHash]->GetHead();
		while(pNode)
		{
			if(pNode->m_String.Icmp(pString) == 0)
			{
				if(pOutHash)
				{
					*pOutHash = nInHash;
				}
				return pNode->m_dwData;
			}
			pNode = pNode->m_pNext;
		}
	}
	if(pOutHash)
	{
		*pOutHash = -1;
	}
	return 0;
}

#endif