#ifndef _FBKernal_CallStack_h_
#define _FBKernal_CallStack_h_

#include <windows.h>
#include "dbghelp.h"
#include "FBKernal_Macro.h"
#include "FBKernal_List.h"
#include "FBKernal_Lock.h"

class CFBKernal_CallStack;

#define FBKERNAL_CALLSTACK_DUMP(CallStack)\
	__try\
	{\
	char *p = 0;\
	*p = 0;\
	}\
	__except(CallStack.Dump(GetExceptionInformation()))\
	{\
	}

class CFBKernal_CallStack_Node : public CFBKernal_ListNode<CFBKernal_CallStack_Node>
{
public:
	char					m_pFile[FBKERNAL_STRING_SMALL];
	char					m_pFunction[FBKERNAL_STRING_SMALL];
	DWORD					m_nLine;
};

class CFBKernal_CallStack_Global
{
public:
	IMAGEHLP_SYMBOL*							m_pSymbol;
	IMAGEHLP_LINE								m_LineInfo;
	CFBKernal_Lock								m_Lock;

public:
	CFBKernal_CallStack_Global()
	{
		SymInitialize(GetCurrentProcess(), 0, true);

		ZeroMemory(&m_LineInfo, sizeof(m_LineInfo));
		m_LineInfo.SizeOfStruct = sizeof(m_LineInfo);

		m_pSymbol = (IMAGEHLP_SYMBOL*)malloc(sizeof(IMAGEHLP_SYMBOL) + FBKERNAL_STRING_SMALL);
		m_pSymbol->SizeOfStruct = sizeof(IMAGEHLP_SYMBOL);
		m_pSymbol->MaxNameLength = FBKERNAL_STRING_SMALL - sizeof(IMAGEHLP_SYMBOL);
	}
	virtual ~CFBKernal_CallStack_Global()
	{
		free(m_pSymbol);
		SymCleanup(GetCurrentProcess());
	}

	CFBKernal_List<CFBKernal_CallStack_Node>* Dump(EXCEPTION_POINTERS* pException, CFBKernal_CallStack* pCallStack)
	{
		STACKFRAME Frame;
		ZeroMemory(&Frame, sizeof(Frame));
		
		Frame.AddrPC.Offset = (*(pException->ContextRecord)).Eip;
		Frame.AddrPC.Mode = AddrModeFlat;

		DWORD dwMachineType;
		#if defined(_M_IX86)
		dwMachineType = IMAGE_FILE_MACHINE_I386;
		Frame.AddrStack.Offset = (*(pException->ContextRecord)).Esp;
		Frame.AddrStack.Mode = AddrModeFlat;
		Frame.AddrFrame.Offset = (*(pException->ContextRecord)).Ebp;
		Frame.AddrFrame.Mode = AddrModeFlat;
		#else
		return false;
		#endif

		CFBKernal_List<CFBKernal_CallStack_Node>* pStack = new CFBKernal_List<CFBKernal_CallStack_Node>;

		while(1)
		{
			m_Lock.Lock();
			if(!StackWalk(
				dwMachineType,
				GetCurrentProcess(),
				GetCurrentThread(),
				&Frame,
				pException->ContextRecord,
                0,
				SymFunctionTableAccess,
				SymGetModuleBase,
				0))
			{
				m_Lock.Unlock();
				break;
			}
			m_Lock.Unlock();

			CFBKernal_CallStack_Node* pNode = (CFBKernal_CallStack_Node*)malloc(sizeof(CFBKernal_CallStack_Node));
			pNode->m_pPrev = 0;

			if(Frame.AddrPC.Offset == 0)
			{
				strcpy(pNode->m_pFile, "no symbols");
				strcpy(pNode->m_pFunction, "no symbols");
				pNode->m_nLine = -1;
			}
			else
			{
				DWORD dwOffset = 0;
				m_Lock.Lock();
				SymGetSymFromAddr(GetCurrentProcess(), Frame.AddrPC.Offset, &dwOffset, m_pSymbol);
				if(m_pSymbol->Name)
				{
					CopyMemory(pNode->m_pFunction, m_pSymbol->Name, FBKERNAL_STRING_SMALL);
					pNode->m_pFunction[FBKERNAL_STRING_SMALL - 1] = '\0';
				}
				SymGetLineFromAddr(GetCurrentProcess(), Frame.AddrPC.Offset, &dwOffset, &m_LineInfo);
				if(m_LineInfo.FileName)
				{
					CopyMemory(pNode->m_pFile, m_LineInfo.FileName, FBKERNAL_STRING_SMALL);
					pNode->m_pFile[FBKERNAL_STRING_SMALL - 1] = '\0';
				}
				pNode->m_nLine = m_LineInfo.LineNumber;
				m_Lock.Unlock();
			}
			pStack->Push_Back(pNode);
		}
		return pStack;
	}
};

class CFBKernal_CallStack
{
public:
	CFBKernal_List<CFBKernal_CallStack_Node>*	m_Stack;

public:
	CFBKernal_CallStack()
	{
		m_Stack = 0;
	}
	~CFBKernal_CallStack()
	{
		Release();
	}

	void Release(void)
	{
		if(m_Stack)
		{
			CFBKernal_CallStack_Node* pNext;
			CFBKernal_CallStack_Node* pNode = m_Stack->GetHead();
			while(pNode)
			{
				pNext = m_Stack->GetNext(pNode);
				free(pNode);
				pNode = pNext;
			}
			delete m_Stack;
			m_Stack = 0;
		}
	}

	static CFBKernal_CallStack_Global& Instance(void)
	{
		static CFBKernal_CallStack_Global CallStack_Global;
		return CallStack_Global;
	}
	DWORD Dump(EXCEPTION_POINTERS* pException)
	{
		m_Stack = Instance().Dump(pException, this);
		return EXCEPTION_EXECUTE_HANDLER;
	}
};

#endif