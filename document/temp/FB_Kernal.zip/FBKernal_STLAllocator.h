#ifndef _FBKernal_STLAllocator_h_
#define _FBKernal_STLAllocator_h_

#include "FBKernal_Allocator.h"

template<class Type>
class CFBKernal_STLAllocator
{
public:
	typedef size_t size_type;
	typedef ptrdiff_t difference_type;
	typedef Type* pointer;
	typedef const Type* const_pointer;
	typedef Type& reference;
	typedef const Type& const_reference;
	typedef Type value_type;

	template<class Other>
	struct rebind
	{
		typedef CFBKernal_STLAllocator<Other> other;
	};

	CFBKernal_Allocator			m_Allocator;

public:
	CFBKernal_STLAllocator()
	{
	}

	CFBKernal_STLAllocator(const CFBKernal_STLAllocator<Type>&)
	{
	}

	template<class Other>
	CFBKernal_STLAllocator(const CFBKernal_STLAllocator<Other>&)
	{
	}

	~CFBKernal_STLAllocator()
	{
	}

	Type* address(Type& Ref) const
	{
		return &Ref;
	}

	const Type* address(const Type& Ref) const
	{
		return &Ref;
	}

	DWORD max_size() const
	{
		DWORD dwCount = (DWORD)(-1) / sizeof (Type);
		return (0 < dwCount ? dwCount : 1);
	}

	void deallocate(Type* pPtr, size_t)
	{
		if(!pPtr)
		{
			return;
		}
		m_Allocator.Free(pPtr);
	}

	Type* allocate(size_t dwCount)
	{
		return (Type*)m_Allocator.Malloc(sizeof(Type), (DWORD)dwCount);
	}

	Type* allocate(size_t dwCount, const void*)
	{
		return (Type*)m_Allocator.Malloc(sizeof(Type), (DWORD)dwCount);
	}

	void construct(Type* pPtr, const Type& Ref)
	{
		if(!pPtr)
		{
			return;
		}
		new(pPtr) Type(Ref);
	}

	void destroy(Type* pPtr)
	{
		if(!pPtr)
		{
			return;
		}
		pPtr->~Type();
	}

	//CFBKernal_Allocator& Instance(void)
	//{
	//	static CFBKernal_Allocator Allocator;
	//	return Allocator;
	//}
};

template<class Type, class Other>
inline bool operator==(const CFBKernal_STLAllocator<Type>&, const CFBKernal_STLAllocator<Other>&)
{
	return true;
}

template<class Type, class Other>
inline bool operator!=(const CFBKernal_STLAllocator<Type>&, const CFBKernal_STLAllocator<Other>&)
{
	return false;
}

#endif
