/*
 * ��Ȩ���У�Bestvision
 * �ļ����ƣ�
 * ����������
 * �������ߣ�Sober.Peng
 * �汾���ƣ�Vision 0.1.0
 * �޸ļ�¼��
 */

#include "socket.h"

CMySocket::CMySocket(CSocketType type/*=SocketTypeTcp*/)
    : CActiveSocket(type)
{
}

CMySocket::~CMySocket()
{

}

int32 CMySocket::Send(const int8 *pData, int32 nLen)
{
    return CActiveSocket::Send((uint8 *)pData, nLen);
}

int32 CMySocket::fnRecvData()
{
    int32 rLen = Receive(DEF_TCP_PKG_MAX);
    CSocketError err = GetSocketError();
    if( CSocketError::SocketNotconnected == err)
    {
    }
    if(0 < rLen)
    {
        GetData();
    }
    return rLen;
}

void *CMySocket::fnRecvThread(void *p)
{
    return_val_if_fail(p != NULL, NULL);

    CMySocket *pThis = (CMySocket *)p;
    while (pThis->m_bRecvStart)
    {
        pThis->fnRecvData();
    }

    return NULL;
}