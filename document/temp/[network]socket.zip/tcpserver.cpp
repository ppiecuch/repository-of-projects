/*
 * ��Ȩ���У�Bestvision
 * �ļ����ƣ�
 * ����������
 * �������ߣ�Sober.Peng
 * �汾���ƣ�Vision 0.1.0
 * �޸ļ�¼��
 */

#include "tcpserver.h"

CTcpServer::CTcpServer(uint16 port)
    :m_tcpSvrPort(port)
{
    m_bAcceptStart = true;
    bvs_create_normal_thread(fnAcceptThread, (void *)this, &m_acceptPid);

    m_bCheckStart = true;
    bvs_create_normal_thread(fnCheckThread, (void *)this, &m_chechPid);
}

CTcpServer::~CTcpServer()
{

}

/*
* ������void *fnAcceptThread(void *p)
* ������Socket Accept�߳�
* ������p[IN] CTcpServerָ��
* ���أ�NULL
*/
void *CTcpServer::fnAcceptThread(void *p)
{
    return_val_if_fail(p != NULL, NULL);
    CTcpServer *pThis = (CTcpServer *)p;

    pThis->m_tcpServer.Initialize();
    pThis->m_tcpServer.Listen(NULL, pThis->m_tcpSvrPort);

    while(pThis->m_bAcceptStart)
    {
        CActiveSocket *pClient = pThis->m_tcpServer.Accept();
        if(NULL != pClient)
        {
            bvs_debug(7, "tcp socket is created. %#x\n", pClient);

            pThis->m_mutex.lock();
            pThis->m_lsClient.push_front((CMySocket *)pClient);
            pThis->m_mutex.unlock();
        }
    }
    bvs_debug(7, "fnAcceptThread return.\n");
    return NULL;
}

/*
* ������void *fnCheckThread(void *p)
* ���������ͻ����б��Ƿ���ڿ�ɾ����
* ������p[IN] CTcpServerָ��
* ���أ�NULL
*/
void *CTcpServer::fnCheckThread(void *p)
{
    return_val_if_fail(p != NULL, NULL);
    CTcpServer *pThis = (CTcpServer *)p;
    
    while(pThis->m_bCheckStart)
    {
        bvs_msleep(1000 * 5);

        pThis->m_mutex.lock();

//         list<CActiveSocket *>::iterator itl;
//         itl = pThis->m_lsClient.begin();
//         for(; itl!=pThis->m_lsClient.end(); )
//         {
//             CActiveSocket *pClient = *itl;
//             if(pClient->fnIsOnline())
//             {
//                 itl++;
//             }
//             else
//             {
//                 pThis->m_lsClient.erase( itl );
//                 if(pClient)
//                 {
//                     delete pClient;
//                     pClient = NULL;
//                 }
//                 itl = pThis->m_lsClient.begin();
//             }
//         }

        pThis->m_mutex.unlock();
    }
    return NULL;
}
