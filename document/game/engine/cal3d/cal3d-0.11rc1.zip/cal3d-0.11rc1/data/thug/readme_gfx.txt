This model come from the game "Dead Justice" and
has been release under GPL, see licence.txt

Dead Justice:
http://catmother.sourceforge.net

Dead Justice Game Prototype Credits
-----------------------------------
Graphic content... Olli Sorjonen, Sami Sorjonen

