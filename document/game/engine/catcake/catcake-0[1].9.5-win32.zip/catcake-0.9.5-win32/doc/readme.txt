Catcake is a cross-platform 3D graphics engine intended to be easy-to-use and high performance, which also supports the features for game development, such as animation, input device handling and sound playing.

Catcake runs on Windows, Linux for now.

Website: http://code.google.com/p/catcake/
Contact: Takashi Kitao (takashi.kitao@gmail.com)

Catcake uses following libraries:
 - zlib 1.2.3
 - libpng 1.2.40
 - FreeType 2.3.11
