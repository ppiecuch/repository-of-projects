To build:
Place AllBulletDemosOSX in bullet-<version>/Extras and build with Xcode.

Questions:
contact Shamyl Zakariya
shamyl@zakariya.net